// Garde de route : exige un utilisateur connecté avec le bon rôle
import { Navigate, useLocation } from 'react-router-dom'
import type { ReactNode } from 'react'
import { Loader2 } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import type { Role } from '@/types'

export function homeFor(role: Role): string {
  if (role === 'driver') return '/chauffeur'
  if (role === 'admin') return '/admin'
  return '/app'
}

export function RequireRole({ role, children }: { role: Role | Role[]; children: ReactNode }) {
  const { user, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-violet-600" />
      </div>
    )
  }
  if (!user) {
    return <Navigate to="/connexion" state={{ from: location.pathname }} replace />
  }
  const roles = Array.isArray(role) ? role : [role]
  if (!roles.includes(user.role)) {
    return <Navigate to={homeFor(user.role)} replace />
  }
  return <>{children}</>
}
