import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { User } from '@/types'
import { apiLogin, apiLogout, apiRegister, apiResetPassword } from '@/services/api'
import { currentUser, subscribe, type RegisterInput } from '@/services/demo'

interface AuthContextValue {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<User>
  register: (input: RegisterInput) => Promise<User>
  logout: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
  refresh: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(() => {
    setUser(currentUser())
  }, [])

  useEffect(() => {
    refresh()
    setLoading(false)
    const unsub = subscribe(refresh)
    return unsub
  }, [refresh])

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      loading,
      login: async (email, password) => {
        const u = await apiLogin(email, password)
        refresh()
        return u
      },
      register: async (input) => {
        const u = await apiRegister(input)
        refresh()
        return u
      },
      logout: async () => {
        await apiLogout()
        refresh()
      },
      resetPassword: apiResetPassword,
      refresh,
    }),
    [user, loading, refresh],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth doit être utilisé dans AuthProvider')
  return ctx
}
