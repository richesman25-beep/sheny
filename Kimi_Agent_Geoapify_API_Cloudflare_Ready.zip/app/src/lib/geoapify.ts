// Intégration Geoapify : tuiles cartographiques, géocodage, ipinfo,
// planificateur d'itinéraire et map matching.
import type { PlaceResult, RouteResult } from '@/types'

export const GEOAPIFY_KEY = '7bac71c8657e434ca4dcb3b1ce2b6a16'

// Tuiles (style clair "carto" pour le client, "dark-matter" pour le chauffeur)
export const tileUrl = (style: 'carto' | 'dark-matter' = 'carto') =>
  `https://maps.geoapify.com/v1/tile/${style}/{z}/{x}/{y}.png?&apiKey=${GEOAPIFY_KEY}`

export const TILE_ATTRIBUTION =
  'Powered by <a href="https://www.geoapify.com/" target="_blank">Geoapify</a> | © OpenStreetMap contributors'

// Centre par défaut : Port-au-Prince, Haïti
export const DEFAULT_CENTER: [number, number] = [18.5944, -72.3074]

async function getJson<T>(url: string): Promise<T | null> {
  try {
    const res = await fetch(url)
    if (!res.ok) return null
    return (await res.json()) as T
  } catch {
    return null
  }
}

interface GeoapifyFeature {
  properties: {
    formatted?: string
    address_line1?: string
    address_line2?: string
    lat?: number
    lon?: number
    distance?: number
    time?: number
  }
  geometry: { type: string; coordinates: unknown }
}

interface GeoapifyCollection {
  features?: GeoapifyFeature[]
}

function featureToPlace(f: GeoapifyFeature): PlaceResult | null {
  const p = f.properties
  if (typeof p.lat !== 'number' || typeof p.lon !== 'number') return null
  return {
    address: p.formatted || [p.address_line1, p.address_line2].filter(Boolean).join(', '),
    lat: p.lat,
    lng: p.lon,
  }
}

// Autocomplétion d'adresses (restreinte à Haïti, biaisée autour de la position)
export async function autocompletePlaces(
  text: string,
  near?: { lat: number; lng: number },
): Promise<PlaceResult[]> {
  if (!text || text.trim().length < 3) return []
  const bias = near ? `&bias=proximity:${near.lng},${near.lat}` : ''
  const url = `https://api.geoapify.com/v1/geocode/autocomplete?text=${encodeURIComponent(
    text,
  )}&filter=countrycode:ht${bias}&limit=6&lang=fr&apiKey=${GEOAPIFY_KEY}`
  const data = await getJson<GeoapifyCollection>(url)
  return (data?.features ?? []).map(featureToPlace).filter((p): p is PlaceResult => p !== null)
}

// Géocodage simple (endpoint fourni : /v1/geocode/search)
export async function geocodeSearch(text: string): Promise<PlaceResult | null> {
  const url = `https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(
    text,
  )}&apiKey=${GEOAPIFY_KEY}`
  const data = await getJson<GeoapifyCollection>(url)
  const first = data?.features?.[0]
  return first ? featureToPlace(first) : null
}

// Géolocalisation approximative par IP (endpoint fourni : /v1/ipinfo)
export async function ipInfo(): Promise<{ lat: number; lng: number; city?: string } | null> {
  const data = await getJson<{
    location?: { latitude?: number; longitude?: number }
    city?: { name?: string }
  }>(`https://api.geoapify.com/v1/ipinfo?&apiKey=${GEOAPIFY_KEY}`)
  const lat = data?.location?.latitude
  const lng = data?.location?.longitude
  if (typeof lat !== 'number' || typeof lng !== 'number') return null
  return { lat, lng, city: data?.city?.name }
}

// Extraction de la géométrie (LineString / MultiLineString) en [lat, lng][]
function extractGeometry(f: GeoapifyFeature): [number, number][] {
  const g = f.geometry
  const out: [number, number][] = []
  const pushLine = (coords: unknown) => {
    if (!Array.isArray(coords)) return
    for (const c of coords) {
      if (Array.isArray(c) && typeof c[0] === 'number' && typeof c[1] === 'number') {
        out.push([c[1], c[0]]) // GeoJSON = [lon, lat]
      }
    }
  }
  if (g.type === 'LineString') pushLine(g.coordinates)
  if (g.type === 'MultiLineString' && Array.isArray(g.coordinates)) {
    for (const line of g.coordinates as unknown[]) pushLine(line)
  }
  return out
}

// Planificateur d'itinéraire (API Geoapify Routing : /v1/routing)
export async function planRoute(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  mode: 'drive' | 'motorcycle' = 'drive',
): Promise<RouteResult | null> {
  const url = `https://api.geoapify.com/v1/routing?waypoints=${from.lat},${from.lng}|${to.lat},${to.lng}&mode=${mode === 'motorcycle' ? 'drive' : mode}&apiKey=${GEOAPIFY_KEY}`
  const data = await getJson<GeoapifyCollection>(url)
  const f = data?.features?.[0]
  if (!f) return null
  const distanceKm = (f.properties.distance ?? 0) / 1000
  const durationMin = (f.properties.time ?? 0) / 60
  const geometry = extractGeometry(f)
  return { distanceKm, durationMin, geometry }
}

// Map matching (endpoint fourni : /v1/mapmatching) — recale un trajet sur les routes
export async function matchToRoads(points: [number, number][]): Promise<[number, number][]> {
  if (points.length < 2) return points
  try {
    const res = await fetch(`https://api.geoapify.com/v1/mapmatching?apiKey=${GEOAPIFY_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mode: 'drive',
        waypoints: points.map(([lat, lng], i) => ({
          timestamp: new Date(Date.now() + i * 60000).toISOString(),
          location: [lat, lng],
        })),
      }),
    })
    if (!res.ok) return []
    const data = (await res.json()) as GeoapifyCollection
    const f = data.features?.[0]
    if (!f) return []
    const geometry = extractGeometry(f)
    return geometry.length >= 2 ? geometry : []
  } catch {
    return []
  }
}

// Distance à vol d'oiseau (km) — utile pour les chauffeurs proches
export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371
  const dLat = ((b.lat - a.lat) * Math.PI) / 180
  const dLng = ((b.lng - a.lng) * Math.PI) / 180
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(s))
}
