import { Navigate, Route, Routes } from 'react-router'
import { AuthProvider } from '@/contexts/AuthContext'
import { Toaster } from '@/components/ui/sonner'

// Layouts
import PublicLayout from '@/layouts/PublicLayout'
import ClientLayout from '@/layouts/ClientLayout'
import DriverLayout from '@/layouts/DriverLayout'
import AdminLayout from '@/layouts/AdminLayout'

// Pages publiques
import Landing from '@/pages/Landing'
import About from '@/pages/About'
import Security from '@/pages/Security'
import PricingPage from '@/pages/PricingPage'
import Contact from '@/pages/Contact'

// Authentification
import Login from '@/pages/auth/Login'
import Register from '@/pages/auth/Register'

// Espace client
import ClientHome from '@/pages/client/ClientHome'
import RideTracking from '@/pages/client/RideTracking'
import MyRides from '@/pages/client/MyRides'
import Favorites from '@/pages/client/Favorites'
import Payments from '@/pages/client/Payments'
import Messages from '@/pages/client/Messages'
import Profile from '@/pages/client/Profile'
import Settings from '@/pages/client/Settings'

// Espace chauffeur
import DriverHome from '@/pages/driver/DriverHome'
import DriverRides from '@/pages/driver/DriverRides'
import DriverEarnings from '@/pages/driver/DriverEarnings'
import DriverHistory from '@/pages/driver/DriverHistory'
import DriverMessages from '@/pages/driver/DriverMessages'
import DriverProfile from '@/pages/driver/DriverProfile'
import DriverSettings from '@/pages/driver/DriverSettings'

// Administration
import AdminDashboard from '@/pages/admin/AdminDashboard'
import AdminUsers from '@/pages/admin/AdminUsers'
import AdminDrivers from '@/pages/admin/AdminDrivers'
import AdminRides from '@/pages/admin/AdminRides'
import AdminPayments from '@/pages/admin/AdminPayments'
import AdminPromotions from '@/pages/admin/AdminPromotions'
import AdminNotifications from '@/pages/admin/AdminNotifications'
import AdminSettings from '@/pages/admin/AdminSettings'

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        {/* Public */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Landing />} />
          <Route path="/a-propos" element={<About />} />
          <Route path="/securite" element={<Security />} />
          <Route path="/tarifs" element={<PricingPage />} />
          <Route path="/contact" element={<Contact />} />
        </Route>

        {/* Authentification */}
        <Route path="/connexion" element={<Login />} />
        <Route path="/inscription" element={<Register />} />

        {/* Client */}
        <Route path="/app" element={<ClientLayout />}>
          <Route index element={<ClientHome />} />
          <Route path="course/:rideId" element={<RideTracking />} />
          <Route path="courses" element={<MyRides />} />
          <Route path="favoris" element={<Favorites />} />
          <Route path="paiements" element={<Payments />} />
          <Route path="messages" element={<Messages />} />
          <Route path="profil" element={<Profile />} />
          <Route path="parametres" element={<Settings />} />
        </Route>

        {/* Chauffeur */}
        <Route path="/chauffeur" element={<DriverLayout />}>
          <Route index element={<DriverHome />} />
          <Route path="courses" element={<DriverRides />} />
          <Route path="revenus" element={<DriverEarnings />} />
          <Route path="historique" element={<DriverHistory />} />
          <Route path="messages" element={<DriverMessages />} />
          <Route path="profil" element={<DriverProfile />} />
          <Route path="parametres" element={<DriverSettings />} />
        </Route>

        {/* Administration */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="utilisateurs" element={<AdminUsers />} />
          <Route path="chauffeurs" element={<AdminDrivers />} />
          <Route path="courses" element={<AdminRides />} />
          <Route path="paiements" element={<AdminPayments />} />
          <Route path="promotions" element={<AdminPromotions />} />
          <Route path="notifications" element={<AdminNotifications />} />
          <Route path="parametres" element={<AdminSettings />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toaster position="top-center" richColors />
    </AuthProvider>
  )
}
