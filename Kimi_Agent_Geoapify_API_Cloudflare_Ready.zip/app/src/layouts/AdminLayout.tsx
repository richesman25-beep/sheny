import { Outlet } from 'react-router-dom'
import {
  Bell,
  CreditCard,
  LayoutDashboard,
  Map,
  Settings,
  ShieldCheck,
  Tag,
  Users,
  CarFront,
} from 'lucide-react'
import { DashboardShell } from '@/components/DashboardShell'
import { NotificationsBell } from '@/components/NotificationsBell'
import { Avatar } from '@/components/Avatar'
import { RequireRole } from '@/routes/RequireRole'
import { useAuth } from '@/contexts/AuthContext'

const ITEMS = [
  { to: '/admin', label: 'Tableau de bord', icon: LayoutDashboard, end: true },
  { to: '/admin/utilisateurs', label: 'Utilisateurs', icon: Users },
  { to: '/admin/chauffeurs', label: 'Chauffeurs', icon: CarFront },
  { to: '/admin/courses', label: 'Courses', icon: Map },
  { to: '/admin/paiements', label: 'Paiements', icon: CreditCard },
  { to: '/admin/promotions', label: 'Promotions', icon: Tag },
  { to: '/admin/notifications', label: 'Notifications', icon: Bell },
  { to: '/admin/parametres', label: 'Paramètres', icon: Settings },
]

export default function AdminLayout() {
  const { user } = useAuth()
  return (
    <RequireRole role="admin">
      <DashboardShell
        items={ITEMS}
        dark
        topRight={
          user && (
            <>
              <span className="hidden items-center gap-1.5 rounded-full bg-violet-100 px-3 py-1.5 text-xs font-semibold text-violet-700 md:flex">
                <ShieldCheck className="h-3.5 w-3.5" /> Admin
              </span>
              <NotificationsBell userId={user.id} />
              <Avatar name={user.fullname} />
            </>
          )
        }
      >
        <Outlet />
      </DashboardShell>
    </RequireRole>
  )
}
