import { Outlet } from 'react-router-dom'
import {
  CreditCard,
  Heart,
  Home,
  Map,
  MessageSquare,
  Settings,
  User,
} from 'lucide-react'
import { DashboardShell } from '@/components/DashboardShell'
import { NotificationsBell } from '@/components/NotificationsBell'
import { Avatar } from '@/components/Avatar'
import { RequireRole } from '@/routes/RequireRole'
import { useAuth } from '@/contexts/AuthContext'

const ITEMS = [
  { to: '/app', label: 'Accueil', icon: Home, end: true },
  { to: '/app/courses', label: 'Mes courses', icon: Map },
  { to: '/app/favoris', label: 'Favoris', icon: Heart },
  { to: '/app/paiements', label: 'Paiements', icon: CreditCard },
  { to: '/app/messages', label: 'Messages', icon: MessageSquare },
  { to: '/app/profil', label: 'Profil', icon: User },
  { to: '/app/parametres', label: 'Paramètres', icon: Settings },
]

export default function ClientLayout() {
  const { user } = useAuth()
  return (
    <RequireRole role="client">
      <DashboardShell
        items={ITEMS}
        topRight={
          user && (
            <>
              <NotificationsBell userId={user.id} />
              <Avatar name={user.fullname} />
            </>
          )
        }
      >
        <Outlet />
      </DashboardShell>
    </RequireRole>
  )
}
