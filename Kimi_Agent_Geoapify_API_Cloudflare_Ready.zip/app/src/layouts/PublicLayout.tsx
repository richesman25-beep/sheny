// Layout des pages publiques : en-tête + pied de page communs
import { useState } from 'react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { Menu, Moon, Sun, X } from 'lucide-react'
import { Logo } from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { useTheme } from '@/hooks/useTheme'
import { useAuth } from '@/contexts/AuthContext'
import { homeFor } from '@/routes/RequireRole'
import { cn } from '@/lib/utils'

const NAV = [
  { to: '/', label: 'Accueil', end: true },
  { to: '/a-propos', label: 'À propos' },
  { to: '/securite', label: 'Sécurité' },
  { to: '/tarifs', label: 'Tarifs' },
  { to: '/contact', label: 'Contact' },
]

export default function PublicLayout() {
  const { dark, toggle } = useTheme()
  const { user } = useAuth()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  return (
    <div className="min-h-screen bg-white text-slate-900 dark:bg-[#0d0b16] dark:text-slate-100">
      <header className="sticky top-0 z-50 border-b border-slate-100 bg-white/85 backdrop-blur-lg dark:border-white/5 dark:bg-[#0d0b16]/85">
        <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-4 sm:px-6">
          <Logo dark={dark} />
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cn(
                    'rounded-lg px-4 py-2 text-sm font-medium transition-colors',
                    isActive
                      ? 'text-violet-600 dark:text-violet-400'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white',
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button
              onClick={toggle}
              aria-label="Changer de thème"
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-500 transition-colors hover:bg-slate-50 dark:border-white/10 dark:text-slate-400 dark:hover:bg-white/5"
            >
              {dark ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
            </button>
            <Button
              onClick={() => navigate(user ? homeFor(user.role) : '/connexion')}
              className="hidden rounded-xl bg-violet-600 px-5 font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700 md:flex"
            >
              {user ? 'Mon espace' : 'Se connecter'}
            </Button>
            <button
              onClick={() => setOpen(!open)}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-600 dark:border-white/10 dark:text-slate-300 md:hidden"
              aria-label="Menu"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="border-t border-slate-100 bg-white px-4 py-3 dark:border-white/5 dark:bg-[#0d0b16] md:hidden">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cn(
                    'block rounded-lg px-4 py-2.5 text-sm font-medium',
                    isActive
                      ? 'bg-violet-50 text-violet-700 dark:bg-violet-500/10 dark:text-violet-300'
                      : 'text-slate-600 dark:text-slate-400',
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
            <Button
              onClick={() => navigate(user ? homeFor(user.role) : '/connexion')}
              className="mt-2 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              {user ? 'Mon espace' : 'Se connecter'}
            </Button>
          </div>
        )}
      </header>

      <Outlet />

      <footer className="border-t border-slate-100 bg-slate-50 dark:border-white/5 dark:bg-[#0a0912]">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
          <div className="space-y-3">
            <Logo dark={dark} />
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Le taxi et la moto en un clic, partout en Haïti.
            </p>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold">Navigation</h4>
            <ul className="space-y-2 text-sm text-slate-500 dark:text-slate-400">
              {NAV.map((n) => (
                <li key={n.to}>
                  <Link to={n.to} className="hover:text-violet-600">
                    {n.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold">Espaces</h4>
            <ul className="space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li>
                <Link to="/connexion" className="hover:text-violet-600">
                  Espace client
                </Link>
              </li>
              <li>
                <Link to="/inscription?role=chauffeur" className="hover:text-violet-600">
                  Devenir chauffeur
                </Link>
              </li>
              <li>
                <Link to="/connexion" className="hover:text-violet-600">
                  Administration
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-sm font-semibold">Contact</h4>
            <ul className="space-y-2 text-sm text-slate-500 dark:text-slate-400">
              <li>Port-au-Prince, Haïti</li>
              <li>+509 34 00 0000</li>
              <li>support@taxipaw.ht</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-100 py-5 text-center text-xs text-slate-400 dark:border-white/5">
          © {new Date().getFullYear()} TaxiPa’w — Tous droits réservés.
        </div>
      </footer>
    </div>
  )
}
