import { Outlet } from 'react-router-dom'
import {
  Clock,
  Home,
  Map,
  MessageSquare,
  Settings,
  User,
  Wallet,
} from 'lucide-react'
import { DashboardShell } from '@/components/DashboardShell'
import { NotificationsBell } from '@/components/NotificationsBell'
import { Avatar } from '@/components/Avatar'
import { RequireRole } from '@/routes/RequireRole'
import { useAuth } from '@/contexts/AuthContext'

const ITEMS = [
  { to: '/chauffeur', label: 'Accueil', icon: Home, end: true },
  { to: '/chauffeur/courses', label: 'Courses', icon: Map },
  { to: '/chauffeur/revenus', label: 'Revenus', icon: Wallet },
  { to: '/chauffeur/historique', label: 'Historique', icon: Clock },
  { to: '/chauffeur/messages', label: 'Messages', icon: MessageSquare },
  { to: '/chauffeur/profil', label: 'Profil', icon: User },
  { to: '/chauffeur/parametres', label: 'Paramètres', icon: Settings },
]

export default function DriverLayout() {
  const { user } = useAuth()
  return (
    <RequireRole role="driver">
      <DashboardShell
        items={ITEMS}
        dark
        contentDark
        topRight={
          user && (
            <>
              <NotificationsBell userId={user.id} dark />
              <Avatar name={user.fullname} />
            </>
          )
        }
      >
        <Outlet />
      </DashboardShell>
    </RequireRole>
  )
}
