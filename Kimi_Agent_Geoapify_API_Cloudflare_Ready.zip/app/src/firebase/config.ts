// Configuration Firebase TaxiPa'w
// ---------------------------------------------------------------
// Collez ici la configuration de votre projet Firebase
// (console Firebase → Paramètres du projet → Vos applications).
// Tant que les valeurs ne sont pas renseignées, l'application
// fonctionne en MODE DÉMO (données simulées en local, temps réel
// simulé) — toutes les pages et tous les boutons restent utilisables.
// ---------------------------------------------------------------

export const firebaseConfig = {
  apiKey: 'A_REMPLACER',
  authDomain: 'A_REMPLACER',
  projectId: 'A_REMPLACER',
  storageBucket: 'A_REMPLACER',
  messagingSenderId: 'A_REMPLACER',
  appId: 'A_REMPLACER',
}

export const isFirebaseConfigured =
  !firebaseConfig.apiKey.includes('A_REMPLACER') &&
  !firebaseConfig.projectId.includes('A_REMPLACER')
