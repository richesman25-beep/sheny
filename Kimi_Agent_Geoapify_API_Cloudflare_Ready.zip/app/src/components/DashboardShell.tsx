// Coquille commune des tableaux de bord : barre latérale + navigation mobile
import { useState } from 'react'
import type { ReactNode } from 'react'
import { LogOut, Menu } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { NavLink, useNavigate } from 'react-router-dom'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Logo } from '@/components/Logo'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'

export interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  end?: boolean
}

interface ShellProps {
  items: NavItem[]
  dark?: boolean // barre latérale sombre
  contentDark?: boolean // contenu sombre
  topRight?: ReactNode
  children: ReactNode
}

export function DashboardShell({ items, dark = false, contentDark = false, topRight, children }: ShellProps) {
  const { logout } = useAuth()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  const nav = (onNavigate?: () => void) => (
    <nav className="flex flex-1 flex-col gap-1 px-3">
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          onClick={onNavigate}
          className={({ isActive }) =>
            cn(
              'flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors',
              isActive
                ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/25'
                : dark
                  ? 'text-slate-400 hover:bg-white/5 hover:text-white'
                  : 'text-slate-600 hover:bg-violet-50 hover:text-violet-700',
            )
          }
        >
          <item.icon className="h-[18px] w-[18px]" />
          {item.label}
        </NavLink>
      ))}
    </nav>
  )

  const logoutBtn = (
    <button
      onClick={handleLogout}
      className={cn(
        'mx-3 mb-5 flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors',
        dark ? 'text-rose-400 hover:bg-rose-500/10' : 'text-rose-500 hover:bg-rose-50',
      )}
    >
      <LogOut className="h-[18px] w-[18px]" />
      Se déconnecter
    </button>
  )

  return (
    <div className={cn('flex min-h-screen', contentDark ? 'bg-[#0d0b16]' : 'bg-slate-50')}>
      {/* Barre latérale — bureau */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r py-5 lg:flex',
          dark ? 'border-white/5 bg-[#131022]' : 'border-slate-100 bg-white',
        )}
      >
        <div className="mb-6 px-5">
          <Logo dark={dark} />
        </div>
        {nav()}
        {logoutBtn}
      </aside>

      {/* En-tête mobile */}
      <div
        className={cn(
          'fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b px-4 py-3 lg:hidden',
          dark ? 'border-white/5 bg-[#131022]' : 'border-slate-100 bg-white',
        )}
      >
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <button
              className={cn(
                'flex h-10 w-10 items-center justify-center rounded-xl border',
                dark ? 'border-white/10 text-slate-300' : 'border-slate-200 text-slate-600',
              )}
            >
              <Menu className="h-5 w-5" />
            </button>
          </SheetTrigger>
          <SheetContent
            side="left"
            className={cn('flex w-72 flex-col p-0 py-5', dark && 'border-white/10 bg-[#131022]')}
          >
            <div className="mb-6 px-5">
              <Logo dark={dark} />
            </div>
            {nav(() => setOpen(false))}
            {logoutBtn}
          </SheetContent>
        </Sheet>
        <Logo dark={dark} />
        <div className="flex items-center gap-2">{topRight}</div>
      </div>

      {/* Contenu */}
      <div className="flex min-h-screen flex-1 flex-col pt-[68px] lg:pl-64 lg:pt-0">
        {/* Barre supérieure — bureau */}
        {topRight && (
          <div
            className={cn(
              'sticky top-0 z-30 hidden items-center justify-end gap-3 border-b px-6 py-3 backdrop-blur lg:flex',
              contentDark
                ? 'border-white/5 bg-[#0d0b16]/80'
                : 'border-slate-100 bg-white/80',
            )}
          >
            {topRight}
          </div>
        )}
        <main className="flex-1">{children}</main>
      </div>
    </div>
  )
}
