import { Car } from 'lucide-react'
import { Link } from 'react-router-dom'
import { cn } from '@/lib/utils'

export function Logo({
  to = '/',
  dark = false,
  className,
}: {
  to?: string
  dark?: boolean
  className?: string
}) {
  return (
    <Link to={to} className={cn('flex items-center gap-2.5', className)}>
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-purple-500 shadow-lg shadow-violet-600/25">
        <Car className="h-5 w-5 text-white" strokeWidth={2.4} />
      </span>
      <span
        className={cn(
          'text-xl font-bold tracking-tight',
          dark ? 'text-white' : 'text-slate-900',
        )}
      >
        TaxiPa’w
      </span>
    </Link>
  )
}
