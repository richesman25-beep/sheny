// Messagerie de démonstration (echo + réponse automatique)
import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import { Send } from 'lucide-react'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Msg {
  from: 'me' | 'them'
  text: string
  at: number
}

const REPLIES = [
  'Bien reçu, merci !',
  'D’accord, j’arrive dans quelques minutes.',
  'Pas de problème.',
  'Je suis en route, à tout de suite.',
]

export function ChatDemo({
  contactName,
  contactRole,
  dark = false,
}: {
  contactName: string
  contactRole: string
  dark?: boolean
}) {
  const [messages, setMessages] = useState<Msg[]>([
    { from: 'them', text: 'Bonjour ! Comment puis-je vous aider ?', at: Date.now() - 60000 },
  ])
  const [text, setText] = useState('')
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = (e: FormEvent) => {
    e.preventDefault()
    const t = text.trim()
    if (!t) return
    setMessages((m) => [...m, { from: 'me', text: t, at: Date.now() }])
    setText('')
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        { from: 'them', text: REPLIES[Math.floor(Math.random() * REPLIES.length)], at: Date.now() },
      ])
    }, 1400)
  }

  return (
    <div
      className={cn(
        'flex h-[calc(100dvh-220px)] flex-col rounded-2xl border lg:h-[calc(100dvh-170px)]',
        dark ? 'border-white/5 bg-[#161325]' : 'border-slate-100 bg-white',
      )}
    >
      <div
        className={cn(
          'flex items-center gap-3 border-b p-4',
          dark ? 'border-white/5' : 'border-slate-100',
        )}
      >
        <Avatar name={contactName} />
        <div>
          <p className={cn('text-sm font-bold', dark && 'text-white')}>{contactName}</p>
          <p className="flex items-center gap-1.5 text-xs text-emerald-500">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> {contactRole} — en ligne
          </p>
        </div>
      </div>
      <div className="flex-1 space-y-3 overflow-auto p-4">
        {messages.map((m, i) => (
          <div key={i} className={cn('flex', m.from === 'me' ? 'justify-end' : 'justify-start')}>
            <div
              className={cn(
                'max-w-[75%] rounded-2xl px-4 py-2.5 text-sm',
                m.from === 'me'
                  ? 'rounded-br-md bg-violet-600 text-white'
                  : dark
                    ? 'rounded-bl-md bg-white/5 text-slate-200'
                    : 'rounded-bl-md bg-slate-100 text-slate-700',
              )}
            >
              {m.text}
              <span
                className={cn(
                  'mt-1 block text-right text-[10px]',
                  m.from === 'me' ? 'text-violet-200' : 'text-slate-400',
                )}
              >
                {new Date(m.at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <form
        onSubmit={send}
        className={cn('flex gap-2 border-t p-3', dark ? 'border-white/5' : 'border-slate-100')}
      >
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Écrivez votre message…"
          className={cn(
            'h-11 flex-1 rounded-xl border bg-transparent px-4 text-sm outline-none',
            dark
              ? 'border-white/10 text-white placeholder:text-slate-500'
              : 'border-slate-200 text-slate-800 placeholder:text-slate-400',
          )}
        />
        <Button
          type="submit"
          className="h-11 w-11 rounded-xl bg-violet-600 p-0 text-white hover:bg-violet-700"
        >
          <Send className="h-4.5 w-4.5" />
        </Button>
      </form>
    </div>
  )
}
