// Champ de recherche d'adresse avec autocomplétion Geoapify (Haïti)
import { useEffect, useRef, useState } from 'react'
import { Loader2, MapPin } from 'lucide-react'
import { autocompletePlaces } from '@/lib/geoapify'
import type { PlaceResult } from '@/types'
import { cn } from '@/lib/utils'

interface Props {
  placeholder: string
  value: string
  onChange: (text: string) => void
  onSelect: (place: PlaceResult) => void
  near?: { lat: number; lng: number }
  dotColor?: string
  dark?: boolean
}

export function AddressAutocomplete({
  placeholder,
  value,
  onChange,
  onSelect,
  near,
  dotColor = '#7c3aed',
  dark = false,
}: Props) {
  const [results, setResults] = useState<PlaceResult[]>([])
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const boxRef = useRef<HTMLDivElement>(null)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  const handleInput = (text: string) => {
    onChange(text)
    if (timerRef.current) clearTimeout(timerRef.current)
    if (text.trim().length < 3) {
      setResults([])
      setOpen(false)
      return
    }
    setLoading(true)
    timerRef.current = setTimeout(async () => {
      const places = await autocompletePlaces(text, near)
      setResults(places)
      setOpen(places.length > 0)
      setLoading(false)
    }, 350)
  }

  return (
    <div ref={boxRef} className="relative">
      <div className="flex items-center gap-2.5">
        <span
          className="h-2.5 w-2.5 shrink-0 rounded-full ring-2 ring-offset-1"
          style={{ backgroundColor: dotColor, ['--tw-ring-color' as string]: dotColor }}
        />
        <input
          value={value}
          onChange={(e) => handleInput(e.target.value)}
          onFocus={() => results.length > 0 && setOpen(true)}
          placeholder={placeholder}
          className={cn(
            'w-full bg-transparent text-sm font-medium outline-none placeholder:font-normal',
            dark
              ? 'text-slate-100 placeholder:text-slate-500'
              : 'text-slate-800 placeholder:text-slate-400',
          )}
        />
        {loading && <Loader2 className="h-4 w-4 animate-spin text-violet-500" />}
      </div>
      {open && (
        <div
          className={cn(
            'absolute left-0 right-0 top-full z-[1000] mt-2 max-h-64 overflow-auto rounded-xl border p-1.5 shadow-xl',
            dark ? 'border-slate-700 bg-[#1b1830]' : 'border-slate-100 bg-white',
          )}
        >
          {results.map((r, i) => (
            <button
              key={`${r.lat}-${r.lng}-${i}`}
              onClick={() => {
                onSelect(r)
                setOpen(false)
                setResults([])
              }}
              className={cn(
                'flex w-full items-start gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm transition-colors',
                dark ? 'hover:bg-white/5' : 'hover:bg-violet-50',
              )}
            >
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-violet-500" />
              <span className={cn('line-clamp-2', dark ? 'text-slate-200' : 'text-slate-700')}>
                {r.address}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
