// Carte Leaflet réutilisable propulsée par les tuiles Geoapify
import { useEffect, useRef } from 'react'
import L from 'leaflet'
import { DEFAULT_CENTER, TILE_ATTRIBUTION, tileUrl } from '@/lib/geoapify'
import { cn } from '@/lib/utils'

export type MarkerKind = 'car' | 'moto' | 'pickup' | 'dropoff' | 'me'

export interface MapMarker {
  id: string
  lat: number
  lng: number
  kind: MarkerKind
  rotation?: number
  label?: string
  dark?: boolean
}

interface MapProps {
  center?: [number, number]
  zoom?: number
  dark?: boolean
  markers?: MapMarker[]
  polyline?: [number, number][]
  fitToContent?: boolean
  onMapClick?: (lat: number, lng: number) => void
  className?: string
}

const CAR_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H8c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 3 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>`

const MOTO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><path d="M15 6a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-3 11.5V14l-3-3 4-3 2 3h2"/></svg>`

function markerIcon(m: MapMarker, darkMap: boolean): L.DivIcon {
  if (m.kind === 'me') {
    return L.divIcon({
      className: '',
      html: `<div style="position:relative;width:22px;height:22px">
        <span style="position:absolute;inset:0;border-radius:9999px;background:#3b82f6;opacity:.35;animation:tp-pulse 1.8s ease-out infinite"></span>
        <span style="position:absolute;inset:4px;border-radius:9999px;background:#3b82f6;border:2.5px solid white;box-shadow:0 1px 4px rgba(0,0,0,.35)"></span>
      </div>`,
      iconSize: [22, 22],
      iconAnchor: [11, 11],
    })
  }
  if (m.kind === 'pickup' || m.kind === 'dropoff') {
    const color = m.kind === 'pickup' ? '#10b981' : '#7c3aed'
    return L.divIcon({
      className: '',
      html: `<div style="width:18px;height:18px;border-radius:9999px;background:${color};border:3px solid white;box-shadow:0 1px 6px rgba(0,0,0,.4)"></div>`,
      iconSize: [18, 18],
      iconAnchor: [9, 9],
    })
  }
  // Véhicules : pastille avec icône orientée
  const isCar = m.kind === 'car'
  const bg = darkMap ? '#1e1b2e' : '#ffffff'
  const fg = darkMap ? '#e5e3ef' : '#1e293b'
  const rot = m.rotation ?? 0
  return L.divIcon({
    className: '',
    html: `<div style="width:30px;height:30px;border-radius:9999px;background:${bg};color:${fg};display:flex;align-items:center;justify-content:center;border:2px solid ${isCar ? '#7c3aed' : '#10b981'};box-shadow:0 2px 8px rgba(0,0,0,.35);transform:rotate(${rot}deg)">${
      isCar ? CAR_SVG : MOTO_SVG
    }</div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  })
}

export function Map({
  center = DEFAULT_CENTER,
  zoom = 14,
  dark = false,
  markers = [],
  polyline,
  fitToContent = false,
  onMapClick,
  className,
}: MapProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<L.Map | null>(null)
  const tileRef = useRef<L.TileLayer | null>(null)
  const markerLayerRef = useRef<L.LayerGroup | null>(null)
  const lineRef = useRef<L.Polyline | null>(null)
  const clickRef = useRef(onMapClick)
  clickRef.current = onMapClick

  // Initialisation unique
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return
    const map = L.map(containerRef.current, {
      center,
      zoom,
      zoomControl: false,
      attributionControl: true,
    })
    L.control.zoom({ position: 'bottomright' }).addTo(map)
    tileRef.current = L.tileLayer(tileUrl(dark ? 'dark-matter' : 'carto'), {
      attribution: TILE_ATTRIBUTION,
      maxZoom: 20,
    }).addTo(map)
    markerLayerRef.current = L.layerGroup().addTo(map)
    map.on('click', (e: L.LeafletMouseEvent) => {
      clickRef.current?.(e.latlng.lat, e.latlng.lng)
    })
    mapRef.current = map

    const ro = new ResizeObserver(() => map.invalidateSize())
    ro.observe(containerRef.current)
    return () => {
      ro.disconnect()
      map.remove()
      mapRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Thème clair / sombre
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    tileRef.current?.remove()
    tileRef.current = L.tileLayer(tileUrl(dark ? 'dark-matter' : 'carto'), {
      attribution: TILE_ATTRIBUTION,
      maxZoom: 20,
    }).addTo(map)
  }, [dark])

  // Recentrage doux quand le centre change explicitement
  const centerKey = center.join(',')
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    map.setView(center, map.getZoom(), { animate: true })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [centerKey])

  // Marqueurs
  useEffect(() => {
    const layer = markerLayerRef.current
    if (!layer) return
    layer.clearLayers()
    for (const m of markers) {
      L.marker([m.lat, m.lng], { icon: markerIcon(m, dark) })
        .addTo(layer)
        .bindTooltip(m.label ?? '', { permanent: false, direction: 'top' })
    }
  }, [markers, dark])

  // Itinéraire
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    lineRef.current?.remove()
    lineRef.current = null
    if (polyline && polyline.length >= 2) {
      lineRef.current = L.polyline(polyline, {
        color: '#7c3aed',
        weight: 5,
        opacity: 0.9,
        lineJoin: 'round',
      }).addTo(map)
      if (fitToContent) {
        map.fitBounds(lineRef.current.getBounds().pad(0.18), { animate: true })
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [polyline, fitToContent])

  return <div ref={containerRef} className={cn('h-full w-full', className)} />
}
