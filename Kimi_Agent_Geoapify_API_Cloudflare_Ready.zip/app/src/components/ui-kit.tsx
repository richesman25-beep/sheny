// Petits composants partagés (pages de tableaux de bord)
import type { ReactNode } from 'react'
import type { LucideIcon } from 'lucide-react'
import { RIDE_STATUS_LABELS } from '@/types'
import type { RideStatus } from '@/types'
import { cn } from '@/lib/utils'

export function PageHeader({
  title,
  subtitle,
  dark = false,
  action,
}: {
  title: string
  subtitle?: string
  dark?: boolean
  action?: ReactNode
}) {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1
          className={cn(
            'text-2xl font-extrabold tracking-tight',
            dark ? 'text-white' : 'text-slate-900',
          )}
        >
          {title}
        </h1>
        {subtitle && (
          <p className={cn('mt-1 text-sm', dark ? 'text-slate-400' : 'text-slate-500')}>
            {subtitle}
          </p>
        )}
      </div>
      {action}
    </div>
  )
}

export function StatCard({
  icon: Icon,
  label,
  value,
  trend,
  dark = false,
  accent = 'violet',
}: {
  icon: LucideIcon
  label: string
  value: string
  trend?: string
  dark?: boolean
  accent?: 'violet' | 'emerald' | 'amber' | 'sky' | 'rose'
}) {
  const accents: Record<string, string> = {
    violet: 'bg-violet-100 text-violet-600 dark:bg-violet-500/15 dark:text-violet-300',
    emerald: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300',
    amber: 'bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300',
    sky: 'bg-sky-100 text-sky-600 dark:bg-sky-500/15 dark:text-sky-300',
    rose: 'bg-rose-100 text-rose-600 dark:bg-rose-500/15 dark:text-rose-300',
  }
  return (
    <div
      className={cn(
        'rounded-2xl border p-5',
        dark ? 'border-white/5 bg-[#161325]' : 'border-slate-100 bg-white',
      )}
    >
      <div className="flex items-center justify-between">
        <span className={cn('flex h-10 w-10 items-center justify-center rounded-xl', accents[accent])}>
          <Icon className="h-5 w-5" />
        </span>
        {trend && (
          <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-bold text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300">
            {trend}
          </span>
        )}
      </div>
      <p className={cn('mt-3 text-2xl font-extrabold tracking-tight', dark && 'text-white')}>
        {value}
      </p>
      <p className={cn('mt-0.5 text-xs', dark ? 'text-slate-400' : 'text-slate-500')}>{label}</p>
    </div>
  )
}

const STATUS_STYLES: Record<RideStatus, string> = {
  pending: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  driver_found: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  driver_en_route: 'bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300',
  driver_arrived: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300',
  started: 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300',
  completed: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  cancelled: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
}

export function StatusBadge({ status }: { status: RideStatus }) {
  return (
    <span
      className={cn(
        'inline-flex rounded-full px-2.5 py-1 text-xs font-bold',
        STATUS_STYLES[status],
      )}
    >
      {RIDE_STATUS_LABELS[status]}
    </span>
  )
}

export function EmptyState({
  icon: Icon,
  title,
  text,
  dark = false,
  action,
}: {
  icon: LucideIcon
  title: string
  text: string
  dark?: boolean
  action?: ReactNode
}) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center rounded-2xl border border-dashed px-6 py-14 text-center',
        dark ? 'border-white/10 text-slate-400' : 'border-slate-200 text-slate-500',
      )}
    >
      <span
        className={cn(
          'flex h-14 w-14 items-center justify-center rounded-2xl',
          dark ? 'bg-white/5 text-slate-400' : 'bg-slate-100 text-slate-400',
        )}
      >
        <Icon className="h-7 w-7" />
      </span>
      <p className={cn('mt-4 font-bold', dark ? 'text-slate-200' : 'text-slate-700')}>{title}</p>
      <p className="mt-1 max-w-sm text-sm">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  )
}

export function Card({
  children,
  dark = false,
  className,
}: {
  children: ReactNode
  dark?: boolean
  className?: string
}) {
  return (
    <div
      className={cn(
        'rounded-2xl border p-5',
        dark ? 'border-white/5 bg-[#161325]' : 'border-slate-100 bg-white',
        className,
      )}
    >
      {children}
    </div>
  )
}

export function formatDateTime(ts: number): string {
  return new Date(ts).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  })
}
