// Panneau de paramètres partagé (client / chauffeur / admin)
import { useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Bell, Globe, KeyRound, Moon, RefreshCcw, Sun } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card } from '@/components/ui-kit'
import { useAuth } from '@/contexts/AuthContext'
import { useTheme } from '@/hooks/useTheme'
import { changePassword, resetDemo } from '@/services/demo'
import { cn } from '@/lib/utils'

export function SettingsPanel({ dark = false }: { dark?: boolean }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const theme = useTheme()
  const [notifRides, setNotifRides] = useState(
    () => localStorage.getItem('taxipaw_notif_rides') !== '0',
  )
  const [notifPromos, setNotifPromos] = useState(
    () => localStorage.getItem('taxipaw_notif_promos') !== '0',
  )
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [pwError, setPwError] = useState('')

  const text = dark ? 'text-white' : 'text-slate-900'
  const sub = dark ? 'text-slate-400' : 'text-slate-500'

  const submitPassword = (e: FormEvent) => {
    e.preventDefault()
    setPwError('')
    if (next.length < 6) {
      setPwError('Le nouveau mot de passe doit contenir au moins 6 caractères.')
      return
    }
    if (next !== confirm) {
      setPwError('La confirmation ne correspond pas.')
      return
    }
    if (!user || !changePassword(user.id, current, next)) {
      setPwError('Mot de passe actuel incorrect.')
      return
    }
    setCurrent('')
    setNext('')
    setConfirm('')
    toast.success('Mot de passe mis à jour !')
  }

  return (
    <div className="grid max-w-3xl gap-5">
      {/* Apparence & langue */}
      <Card dark={dark}>
        <h3 className={cn('mb-4 font-extrabold', text)}>Préférences</h3>
        <div className="space-y-4">
          {!dark && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-100 text-violet-600">
                  {theme.dark ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                </span>
                <div>
                  <p className={cn('text-sm font-bold', text)}>Mode sombre</p>
                  <p className={cn('text-xs', sub)}>Thème de l’interface publique</p>
                </div>
              </div>
              <Switch checked={theme.dark} onCheckedChange={theme.toggle} />
            </div>
          )}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-100 text-sky-600 dark:bg-sky-500/15 dark:text-sky-300">
                <Globe className="h-5 w-5" />
              </span>
              <div>
                <p className={cn('text-sm font-bold', text)}>Langue</p>
                <p className={cn('text-xs', sub)}>Langue de l’application</p>
              </div>
            </div>
            <select
              defaultValue="fr"
              className={cn(
                'h-10 rounded-xl border px-3 text-sm font-semibold outline-none',
                dark ? 'border-white/10 bg-[#1b1830] text-white' : 'border-slate-200 bg-white',
              )}
            >
              <option value="fr">Français</option>
              <option value="ht">Kreyòl ayisyen</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Notifications */}
      <Card dark={dark}>
        <h3 className={cn('mb-4 font-extrabold', text)}>Notifications</h3>
        <div className="space-y-4">
          {[
            {
              label: 'Statut des courses',
              desc: 'Chauffeur trouvé, arrivée, fin de course',
              value: notifRides,
              set: (v: boolean) => {
                setNotifRides(v)
                localStorage.setItem('taxipaw_notif_rides', v ? '1' : '0')
              },
            },
            {
              label: 'Promotions',
              desc: 'Codes promo et offres spéciales',
              value: notifPromos,
              set: (v: boolean) => {
                setNotifPromos(v)
                localStorage.setItem('taxipaw_notif_promos', v ? '1' : '0')
              },
            },
          ].map((n) => (
            <div key={n.label} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300">
                  <Bell className="h-5 w-5" />
                </span>
                <div>
                  <p className={cn('text-sm font-bold', text)}>{n.label}</p>
                  <p className={cn('text-xs', sub)}>{n.desc}</p>
                </div>
              </div>
              <Switch checked={n.value} onCheckedChange={n.set} />
            </div>
          ))}
        </div>
      </Card>

      {/* Mot de passe */}
      <Card dark={dark}>
        <h3 className={cn('mb-4 flex items-center gap-2 font-extrabold', text)}>
          <KeyRound className="h-4.5 w-4.5" /> Changer le mot de passe
        </h3>
        <form onSubmit={submitPassword} className="grid gap-3">
          <div className="space-y-1.5">
            <Label className={sub}>Mot de passe actuel</Label>
            <Input
              type="password"
              required
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              className="h-11 rounded-xl"
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label className={sub}>Nouveau mot de passe</Label>
              <Input
                type="password"
                required
                value={next}
                onChange={(e) => setNext(e.target.value)}
                className="h-11 rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className={sub}>Confirmation</Label>
              <Input
                type="password"
                required
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="h-11 rounded-xl"
              />
            </div>
          </div>
          {pwError && (
            <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-sm font-medium text-rose-600 dark:bg-rose-500/10">
              {pwError}
            </p>
          )}
          <Button
            type="submit"
            className="h-11 rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
          >
            Mettre à jour
          </Button>
        </form>
      </Card>

      {/* Zone dangereuse */}
      <Card dark={dark} className="border-rose-200 dark:border-rose-500/20">
        <h3 className={cn('mb-2 font-extrabold text-rose-600 dark:text-rose-400')}>
          Données de démonstration
        </h3>
        <p className={cn('mb-4 text-sm', sub)}>
          Réinitialise toutes les données locales (comptes, courses, chauffeurs) à leur état
          initial. Vous serez déconnecté.
        </p>
        <Button
          variant="outline"
          onClick={async () => {
            resetDemo()
            await logout()
            navigate('/')
            toast.success('Données réinitialisées.')
          }}
          className="h-11 rounded-xl border-rose-200 font-semibold text-rose-600 hover:bg-rose-50"
        >
          <RefreshCcw className="mr-2 h-4 w-4" /> Réinitialiser la démo
        </Button>
      </Card>
    </div>
  )
}
