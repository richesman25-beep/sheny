// Cloche de notifications temps réel
import { Bell, CheckCheck } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import { useStore } from '@/hooks/useStore'
import { markAllNotificationsRead, markNotificationRead } from '@/services/demo'
import { cn } from '@/lib/utils'

function timeAgo(ts: number): string {
  const diff = Date.now() - ts
  const min = Math.floor(diff / 60000)
  if (min < 1) return 'À l’instant'
  if (min < 60) return `Il y a ${min} min`
  const h = Math.floor(min / 60)
  if (h < 24) return `Il y a ${h} h`
  return `Il y a ${Math.floor(h / 24)} j`
}

export function NotificationsBell({ userId, dark = false }: { userId: string; dark?: boolean }) {
  const db = useStore()
  const notifs = db.notifications
    .filter((n) => n.userId === userId)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 12)
  const unread = notifs.filter((n) => !n.read).length

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            'relative flex h-10 w-10 items-center justify-center rounded-xl border transition-colors',
            dark
              ? 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
              : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50',
          )}
        >
          <Bell className="h-[18px] w-[18px]" />
          {unread > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
              {unread}
            </span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        className={cn(
          'w-80 rounded-xl p-0',
          dark && 'border-white/10 bg-[#1b1830] text-slate-200',
        )}
      >
        <div
          className={cn(
            'flex items-center justify-between border-b px-4 py-3',
            dark ? 'border-white/10' : 'border-slate-100',
          )}
        >
          <span className="text-sm font-semibold">Notifications</span>
          {unread > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 text-xs text-violet-500"
              onClick={() => markAllNotificationsRead(userId)}
            >
              <CheckCheck className="h-3.5 w-3.5" /> Tout lire
            </Button>
          )}
        </div>
        <div className="max-h-80 overflow-auto">
          {notifs.length === 0 && (
            <p className="px-4 py-8 text-center text-sm text-slate-400">Aucune notification</p>
          )}
          {notifs.map((n) => (
            <button
              key={n.id}
              onClick={() => markNotificationRead(n.id)}
              className={cn(
                'flex w-full flex-col gap-0.5 border-b px-4 py-3 text-left transition-colors last:border-0',
                dark ? 'border-white/5 hover:bg-white/5' : 'border-slate-50 hover:bg-slate-50',
                !n.read && (dark ? 'bg-violet-500/10' : 'bg-violet-50/60'),
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-semibold">{n.title}</span>
                {!n.read && <span className="h-2 w-2 shrink-0 rounded-full bg-violet-500" />}
              </div>
              <p className={cn('text-xs', dark ? 'text-slate-400' : 'text-slate-500')}>
                {n.message}
              </p>
              <span className="text-[10px] text-slate-400">{timeAgo(n.createdAt)}</span>
            </button>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
