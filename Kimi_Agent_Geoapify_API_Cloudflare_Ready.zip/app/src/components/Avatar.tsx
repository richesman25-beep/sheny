import { cn } from '@/lib/utils'

const GRADIENTS = [
  'from-violet-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-orange-500 to-rose-500',
  'from-sky-500 to-indigo-600',
  'from-fuchsia-500 to-pink-600',
]

export function Avatar({
  name,
  size = 'md',
  className,
}: {
  name: string
  size?: 'sm' | 'md' | 'lg'
  className?: string
}) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('')
  const hash = name.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
  const gradient = GRADIENTS[hash % GRADIENTS.length]
  const sizes = { sm: 'h-8 w-8 text-xs', md: 'h-10 w-10 text-sm', lg: 'h-14 w-14 text-lg' }
  return (
    <span
      className={cn(
        'flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br font-semibold text-white',
        gradient,
        sizes[size],
        className,
      )}
    >
      {initials || '?'}
    </span>
  )
}
