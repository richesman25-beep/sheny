// Page Tarifs publique avec simulateur
import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Bike, Calculator, CarFront, Info } from 'lucide-react'
import { AddressAutocomplete } from '@/components/AddressAutocomplete'
import { planRoute, DEFAULT_CENTER } from '@/lib/geoapify'
import { estimatePrice, formatGdes, TARIFFS } from '@/services/pricing'
import type { PlaceResult, VehicleType } from '@/types'
import { cn } from '@/lib/utils'

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.55 },
}

export default function PricingPage() {
  const [fromText, setFromText] = useState('')
  const [toText, setToText] = useState('')
  const [from, setFrom] = useState<PlaceResult | null>(null)
  const [to, setTo] = useState<PlaceResult | null>(null)
  const [result, setResult] = useState<{ taxi: number; moto: number; km: number; min: number } | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!from || !to) {
      setResult(null)
      return
    }
    setLoading(true)
    void planRoute(from, to).then((r) => {
      setLoading(false)
      if (!r) {
        setResult(null)
        return
      }
      setResult({
        taxi: estimatePrice('taxi', r.distanceKm, r.durationMin),
        moto: estimatePrice('moto', r.distanceKm, r.durationMin),
        km: r.distanceKm,
        min: r.durationMin,
      })
    })
  }, [from, to])

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <motion.div {...fadeUp} className="mx-auto max-w-3xl text-center">
        <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl">
          Des tarifs clairs,{' '}
          <span className="bg-gradient-to-r from-violet-600 to-purple-500 bg-clip-text text-transparent">
            en gourdes
          </span>
        </h1>
        <p className="mt-5 text-lg text-slate-500 dark:text-slate-400">
          Pas de surprise : le prix estimé est affiché avant chaque commande, et vous payez en
          espèces à l’arrivée.
        </p>
      </motion.div>

      {/* Grille tarifaire */}
      <div className="mx-auto mt-14 grid max-w-4xl gap-6 md:grid-cols-2">
        {(['taxi', 'moto'] as VehicleType[]).map((v, i) => {
          const t = TARIFFS[v]
          const Icon = v === 'taxi' ? CarFront : Bike
          return (
            <motion.div
              key={v}
              {...fadeUp}
              transition={{ duration: 0.55, delay: i * 0.12 }}
              className="rounded-3xl border border-slate-100 bg-white p-8 dark:border-white/5 dark:bg-white/[0.03]"
            >
              <div className="flex items-center justify-between">
                <span
                  className={cn(
                    'flex h-12 w-12 items-center justify-center rounded-2xl text-white shadow-lg',
                    v === 'taxi'
                      ? 'bg-gradient-to-br from-violet-600 to-purple-500 shadow-violet-600/25'
                      : 'bg-gradient-to-br from-emerald-500 to-teal-500 shadow-emerald-600/25',
                  )}
                >
                  <Icon className="h-6 w-6" />
                </span>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300">
                  dès {formatGdes(t.minimum)}
                </span>
              </div>
              <h3 className="mt-5 text-xl font-extrabold">{v === 'taxi' ? 'Taxi' : 'Moto'}</h3>
              <div className="mt-4 space-y-2.5 text-sm">
                {[
                  ['Prise en charge', formatGdes(t.base)],
                  ['Par kilomètre', `${t.perKm} Gdes`],
                  ['Par minute', `${t.perMin} Gdes`],
                  ['Course minimum', formatGdes(t.minimum)],
                ].map(([k, val]) => (
                  <div key={k} className="flex justify-between border-b border-slate-50 pb-2.5 dark:border-white/5">
                    <span className="text-slate-500 dark:text-slate-400">{k}</span>
                    <span className="font-bold">{val}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Simulateur */}
      <motion.div
        {...fadeUp}
        className="mx-auto mt-12 max-w-4xl rounded-3xl border border-violet-100 bg-gradient-to-br from-violet-50 to-white p-8 dark:border-violet-500/10 dark:from-violet-950/30 dark:to-transparent"
      >
        <h3 className="flex items-center gap-2 text-lg font-extrabold">
          <Calculator className="h-5 w-5 text-violet-600" /> Simulateur de prix
        </h3>
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-slate-100 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <AddressAutocomplete
              placeholder="Point de départ"
              value={fromText}
              onChange={(t) => {
                setFromText(t)
                setFrom(null)
              }}
              onSelect={(p) => {
                setFrom(p)
                setFromText(p.address)
              }}
              near={{ lat: DEFAULT_CENTER[0], lng: DEFAULT_CENTER[1] }}
              dotColor="#10b981"
            />
          </div>
          <div className="rounded-2xl border border-slate-100 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <AddressAutocomplete
              placeholder="Destination"
              value={toText}
              onChange={(t) => {
                setToText(t)
                setTo(null)
              }}
              onSelect={(p) => {
                setTo(p)
                setToText(p.address)
              }}
              near={{ lat: DEFAULT_CENTER[0], lng: DEFAULT_CENTER[1] }}
              dotColor="#f43f5e"
            />
          </div>
        </div>
        {loading && <p className="mt-4 text-sm text-slate-500">Calcul de l’itinéraire…</p>}
        {result && (
          <div className="mt-5 grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl bg-white p-5 text-center dark:bg-white/5">
              <p className="text-xs text-slate-400">Distance</p>
              <p className="mt-1 text-xl font-extrabold">
                {result.km.toFixed(1)} km • {Math.round(result.min)} min
              </p>
            </div>
            <div className="rounded-2xl bg-white p-5 text-center dark:bg-white/5">
              <p className="text-xs text-slate-400">Taxi</p>
              <p className="mt-1 text-xl font-extrabold text-violet-600">{formatGdes(result.taxi)}</p>
            </div>
            <div className="rounded-2xl bg-white p-5 text-center dark:bg-white/5">
              <p className="text-xs text-slate-400">Moto</p>
              <p className="mt-1 text-xl font-extrabold text-emerald-600">{formatGdes(result.moto)}</p>
            </div>
          </div>
        )}
        <p className="mt-5 flex items-start gap-2 text-xs text-slate-400">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          Estimation indicative : le prix final peut varier selon le trafic et le point de prise en
          charge exact.
        </p>
      </motion.div>
    </div>
  )
}
