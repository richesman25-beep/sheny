// Page Contact
import { useState } from 'react'
import type { FormEvent } from 'react'
import { motion } from 'framer-motion'
import { Mail, MapPin, Phone, Send } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.55 },
}

export default function Contact() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const submit = (e: FormEvent) => {
    e.preventDefault()
    toast.success('Message envoyé ! Notre équipe vous répondra sous 24 h.')
    setName('')
    setEmail('')
    setMessage('')
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <motion.div {...fadeUp} className="mx-auto max-w-3xl text-center">
        <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl">Contactez-nous</h1>
        <p className="mt-5 text-lg text-slate-500 dark:text-slate-400">
          Une question, un partenariat, un incident ? Notre équipe vous répond rapidement.
        </p>
      </motion.div>

      <div className="mx-auto mt-14 grid max-w-5xl gap-6 lg:grid-cols-[380px_1fr]">
        <motion.div {...fadeUp} className="space-y-4">
          {[
            {
              icon: MapPin,
              title: 'Adresse',
              lines: ['Delmas 33, Port-au-Prince', 'Haïti'],
            },
            { icon: Phone, title: 'Téléphone', lines: ['+509 34 00 0000', '7 j/7, 6 h – 22 h'] },
            { icon: Mail, title: 'Email', lines: ['support@taxipaw.ht', 'Réponse sous 24 h'] },
          ].map((c) => (
            <div
              key={c.title}
              className="flex items-start gap-4 rounded-3xl border border-slate-100 bg-white p-6 dark:border-white/5 dark:bg-white/[0.03]"
            >
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-violet-100 text-violet-600 dark:bg-violet-500/15 dark:text-violet-300">
                <c.icon className="h-6 w-6" />
              </span>
              <div>
                <p className="font-bold">{c.title}</p>
                {c.lines.map((l) => (
                  <p key={l} className="text-sm text-slate-500 dark:text-slate-400">
                    {l}
                  </p>
                ))}
              </div>
            </div>
          ))}
        </motion.div>

        <motion.form
          {...fadeUp}
          transition={{ duration: 0.55, delay: 0.12 }}
          onSubmit={submit}
          className="rounded-3xl border border-slate-100 bg-white p-8 dark:border-white/5 dark:bg-white/[0.03]"
        >
          <h3 className="text-lg font-extrabold">Envoyez-nous un message</h3>
          <div className="mt-6 grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Nom complet</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  placeholder="Votre nom"
                  className="h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="vous@exemple.ht"
                  className="h-12 rounded-xl"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Message</Label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                rows={5}
                placeholder="Comment pouvons-nous vous aider ?"
                className="w-full rounded-xl border border-slate-200 bg-transparent p-3.5 text-sm outline-none focus:border-violet-400 dark:border-white/10"
              />
            </div>
            <Button
              type="submit"
              className="h-12 rounded-xl bg-violet-600 font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700"
            >
              <Send className="mr-2 h-4.5 w-4.5" /> Envoyer le message
            </Button>
          </div>
        </motion.form>
      </div>
    </div>
  )
}
