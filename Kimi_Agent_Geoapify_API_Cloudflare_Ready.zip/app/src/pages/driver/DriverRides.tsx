// Courses du chauffeur (actives + à traiter)
import { Navigation } from 'lucide-react'
import { PageHeader, StatusBadge, EmptyState, formatDateTime } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { driverAcceptRide, driverRefuseRide, ridesForUser } from '@/services/demo'
import { formatGdes } from '@/services/pricing'
import { useNavigate } from 'react-router-dom'

export default function DriverRides() {
  const { user } = useAuth()
  useStore()
  const navigate = useNavigate()
  const rides = ridesForUser(user?.id ?? '')
  const pending = rides.filter((r) => r.status === 'pending')
  const active = rides.filter((r) =>
    ['driver_found', 'driver_en_route', 'driver_arrived', 'started'].includes(r.status),
  )

  return (
    <div className="p-4 sm:p-6">
      <PageHeader
        dark
        title="Courses"
        subtitle="Demandes en attente et courses en cours"
        action={
          <Button
            onClick={() => navigate('/chauffeur')}
            className="rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
          >
            Tableau de bord
          </Button>
        }
      />

      {pending.length === 0 && active.length === 0 ? (
        <EmptyState
          dark
          icon={Navigation}
          title="Aucune course en cours"
          text="Les demandes reçues pendant que vous êtes en ligne s’affichent ici."
        />
      ) : (
        <div className="grid gap-3">
          {[...pending, ...active].map((r) => (
            <div key={r.id} className="rounded-2xl border border-white/5 bg-[#161325] p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-white">
                    {r.pickup.address} → {r.dropoff.address}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    {formatDateTime(r.createdAt)} • {r.distanceKm.toFixed(1)} km •{' '}
                    {r.clientName ?? 'Client'}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <p className="font-extrabold text-emerald-400">{formatGdes(r.price)}</p>
                  <StatusBadge status={r.status} />
                </div>
              </div>
              {r.status === 'pending' && (
                <div className="mt-3 grid grid-cols-2 gap-2.5">
                  <Button
                    variant="outline"
                    onClick={() => driverRefuseRide(r.id)}
                    className="h-10 rounded-xl border-white/10 bg-transparent font-semibold text-slate-300 hover:bg-white/5"
                  >
                    Refuser
                  </Button>
                  <Button
                    onClick={() => driverAcceptRide(r.id)}
                    className="h-10 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                  >
                    Accepter
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
