// Revenus du chauffeur
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { CalendarDays, TrendingUp, Wallet } from 'lucide-react'
import { PageHeader, StatCard, Card, formatDateTime } from '@/components/ui-kit'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { getDriver, ridesForUser } from '@/services/demo'
import { COMMISSION_RATE, formatGdes } from '@/services/pricing'

const day = 24 * 60 * 60 * 1000

export default function DriverEarnings() {
  const { user } = useAuth()
  useStore()
  const driver = user ? getDriver(user.id) : undefined
  const completed = ridesForUser(user?.id ?? '').filter((r) => r.status === 'completed')
  const net = (price: number) => Math.round(price * (1 - COMMISSION_RATE))

  const today = new Date().setHours(0, 0, 0, 0)
  const todayTotal = completed
    .filter((r) => r.createdAt >= today)
    .reduce((s, r) => s + net(r.price), 0)
  const weekTotal = completed
    .filter((r) => r.createdAt >= today - 6 * day)
    .reduce((s, r) => s + net(r.price), 0)

  const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
  const series = Array.from({ length: 7 }, (_, i) => {
    const start = today - (6 - i) * day
    const total = completed
      .filter((r) => r.createdAt >= start && r.createdAt < start + day)
      .reduce((s, r) => s + net(r.price), 0)
    return { day: dayNames[new Date(start).getDay()], amount: total }
  })

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <PageHeader dark title="Revenus" subtitle="Vos gains après commission de la plateforme (15 %)" />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard dark icon={CalendarDays} label="Aujourd’hui" value={formatGdes(todayTotal)} accent="emerald" />
        <StatCard dark icon={TrendingUp} label="7 derniers jours" value={formatGdes(weekTotal)} accent="violet" />
        <StatCard dark icon={Wallet} label="Total cumulé" value={formatGdes(driver?.earnings ?? 0)} accent="amber" />
      </div>

      <Card dark>
        <h3 className="mb-4 font-extrabold text-white">Revenus (7 derniers jours)</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={series} margin={{ left: -16, right: 8, top: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip
                cursor={{ fill: 'rgba(124,58,237,0.08)' }}
                contentStyle={{
                  borderRadius: 12,
                  border: '1px solid rgba(255,255,255,0.1)',
                  background: '#1b1830',
                  color: '#fff',
                  fontSize: 13,
                  fontWeight: 600,
                }}
                formatter={(v) => [formatGdes(Number(v)), 'Revenus']}
              />
              <Bar dataKey="amount" fill="#7c3aed" radius={[8, 8, 0, 0]} maxBarSize={42} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card dark>
        <h3 className="mb-4 font-extrabold text-white">Détail des courses</h3>
        {completed.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500">Aucun revenu pour le moment.</p>
        ) : (
          <div className="divide-y divide-white/5">
            {completed.slice(0, 12).map((r) => (
              <div key={r.id} className="flex items-center justify-between py-3 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-semibold text-slate-200">
                    {r.pickup.address.split(',')[0]} → {r.dropoff.address.split(',')[0]}
                  </p>
                  <p className="text-xs text-slate-500">
                    {formatDateTime(r.createdAt)} • course {formatGdes(r.price)}
                  </p>
                </div>
                <p className="font-extrabold text-emerald-400">+{formatGdes(net(r.price))}</p>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  )
}
