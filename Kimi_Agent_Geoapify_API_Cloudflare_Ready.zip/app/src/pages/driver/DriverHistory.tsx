// Historique complet du chauffeur
import { Clock } from 'lucide-react'
import { PageHeader, StatusBadge, EmptyState, formatDateTime } from '@/components/ui-kit'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { ridesForUser } from '@/services/demo'
import { formatGdes } from '@/services/pricing'

export default function DriverHistory() {
  const { user } = useAuth()
  useStore()
  const rides = ridesForUser(user?.id ?? '').filter((r) => r.status !== 'pending')

  return (
    <div className="p-4 sm:p-6">
      <PageHeader dark title="Historique" subtitle={`${rides.length} courses au total`} />
      {rides.length === 0 ? (
        <EmptyState
          dark
          icon={Clock}
          title="Aucune course"
          text="Votre historique de courses apparaîtra ici."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-white/5 bg-[#161325]">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-white/5 text-left text-xs uppercase tracking-wide text-slate-500">
                <th className="p-4 font-semibold">Course</th>
                <th className="p-4 font-semibold">Trajet</th>
                <th className="p-4 font-semibold">Client</th>
                <th className="p-4 font-semibold">Date</th>
                <th className="p-4 font-semibold">Prix</th>
                <th className="p-4 font-semibold">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {rides.map((r) => (
                <tr key={r.id} className="text-slate-300 hover:bg-white/[0.03]">
                  <td className="p-4 font-bold text-white">#{r.id}</td>
                  <td className="max-w-[260px] truncate p-4">
                    {r.pickup.address.split(',')[0]} → {r.dropoff.address.split(',')[0]}
                  </td>
                  <td className="p-4">{r.clientName ?? 'Client'}</td>
                  <td className="p-4 text-slate-500">{formatDateTime(r.createdAt)}</td>
                  <td className="p-4 font-bold text-emerald-400">{formatGdes(r.price)}</td>
                  <td className="p-4">
                    <StatusBadge status={r.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
