// Accueil chauffeur (thème sombre) : statut, demandes, course active, stats
import { useEffect, useMemo, useState } from 'react'
import {
  BadgeCheck,
  CarFront,
  Clock,
  Hourglass,
  MapPin,
  Navigation,
  Star,
  Wallet,
} from 'lucide-react'
import { Map } from '@/components/Map'
import type { MapMarker } from '@/components/Map'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Card, EmptyState, formatDateTime } from '@/components/ui-kit'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { haversineKm, planRoute } from '@/lib/geoapify'
import {
  activeRideFor,
  completeRide,
  driverAcceptRide,
  driverMarkArrived,
  driverPendingRide,
  driverRefuseRide,
  driverStartRide,
  getDriver,
  setDriverOnline,
} from '@/services/demo'
import { COMMISSION_RATE, formatGdes } from '@/services/pricing'
import { cn } from '@/lib/utils'

export default function DriverHome() {
  const { user } = useAuth()
  const db = useStore()
  const driver = user ? getDriver(user.id) : undefined
  const pending = user ? driverPendingRide(user.id) : undefined
  const active = user ? activeRideFor(user.id) : undefined

  const [countdown, setCountdown] = useState(20)
  const [geometry, setGeometry] = useState<[number, number][]>([])

  // Chauffeur déjà en ligne à l'ouverture → programme une demande simulée
  useEffect(() => {
    if (user && driver?.approved && driver.online) {
      setDriverOnline(user.id, true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Compte à rebours de la demande
  useEffect(() => {
    if (!pending) return
    const iv = setInterval(() => {
      const left = Math.max(0, 20 - Math.floor((Date.now() - pending.createdAt) / 1000))
      setCountdown(left)
      if (left <= 0) {
        clearInterval(iv)
        driverRefuseRide(pending.id)
      }
    }, 500)
    return () => clearInterval(iv)
  }, [pending])

  // Tracé pour la course active
  useEffect(() => {
    if (!active || !driver) {
      setGeometry([])
      return
    }
    const target = ['driver_en_route', 'driver_arrived'].includes(active.status)
      ? active.pickup
      : active.dropoff
    const from = { lat: driver.latitude, lng: driver.longitude }
    let cancelled = false
    void planRoute(from, target).then((r) => {
      if (!cancelled && r) setGeometry(r.geometry)
    })
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active?.id, active?.status])

  const today = new Date().setHours(0, 0, 0, 0)
  const todayRides = useMemo(
    () =>
      db.rides.filter(
        (r) => r.driverId === user?.id && r.status === 'completed' && r.createdAt >= today,
      ),
    [db.rides, user?.id, today],
  )
  const todayEarnings = todayRides.reduce(
    (s, r) => s + Math.round(r.price * (1 - COMMISSION_RATE)),
    0,
  )

  if (!user || !driver) return null

  const markers: MapMarker[] = [
    {
      id: 'me',
      lat: driver.latitude,
      lng: driver.longitude,
      kind: driver.vehicleType === 'taxi' ? 'car' : 'moto',
      label: 'Vous',
    },
  ]
  if (active) {
    markers.push(
      { id: 'pickup', lat: active.pickup.lat, lng: active.pickup.lng, kind: 'pickup', label: 'Client' },
      { id: 'dropoff', lat: active.dropoff.lat, lng: active.dropoff.lng, kind: 'dropoff', label: 'Destination' },
    )
  }
  if (pending) {
    markers.push({
      id: 'request',
      lat: pending.pickup.lat,
      lng: pending.pickup.lng,
      kind: 'pickup',
      label: 'Demande',
    })
  }

  const navUrl = active
    ? `https://www.google.com/maps/dir/?api=1&destination=${
        ['driver_en_route', 'driver_arrived'].includes(active.status)
          ? `${active.pickup.lat},${active.pickup.lng}`
          : `${active.dropoff.lat},${active.dropoff.lng}`
      }`
    : null

  return (
    <div className="space-y-5 p-4 sm:p-6">
      {/* En-tête statut */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-white">Statut</h1>
          <p className="mt-0.5 text-sm text-slate-400">
            {driver.online ? 'Vous recevez des demandes de course' : 'Vous êtes invisible pour les clients'}
          </p>
        </div>
        <div
          className={cn(
            'flex items-center gap-3 rounded-2xl border px-5 py-3',
            driver.online ? 'border-emerald-500/20 bg-emerald-500/10' : 'border-white/10 bg-white/5',
          )}
        >
          <span
            className={cn(
              'text-sm font-bold',
              driver.online ? 'text-emerald-400' : 'text-slate-400',
            )}
          >
            {driver.online ? 'En ligne' : 'Hors ligne'}
          </span>
          <Switch
            checked={driver.online}
            disabled={!driver.approved}
            onCheckedChange={(v) => setDriverOnline(user.id, v)}
            className="data-[state=checked]:bg-emerald-500"
          />
        </div>
      </div>

      {/* Validation en attente */}
      {!driver.approved && (
        <Card dark className="border-amber-500/20 bg-amber-500/5">
          <div className="flex items-start gap-4">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-500/15 text-amber-400">
              <Hourglass className="h-6 w-6" />
            </span>
            <div>
              <p className="font-bold text-amber-300">Compte en attente de validation</p>
              <p className="mt-1 text-sm leading-relaxed text-slate-400">
                Votre dossier ({driver.brand} {driver.model} — {driver.plate}) est en cours de
                vérification par notre équipe. Vous pourrez vous mettre en ligne dès l’approbation.
              </p>
            </div>
          </div>
        </Card>
      )}

      <div className="grid gap-5 xl:grid-cols-[400px_1fr]">
        <div className="space-y-5">
          {/* Nouvelle demande */}
          {pending && (
            <Card dark className="border-violet-500/30 bg-gradient-to-b from-violet-950/60 to-[#161325]">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-extrabold text-white">Nouvelle demande</h2>
                <span
                  className={cn(
                    'flex h-10 w-10 items-center justify-center rounded-full border-2 text-sm font-extrabold',
                    countdown <= 5
                      ? 'border-rose-500 text-rose-400'
                      : 'border-violet-500 text-violet-300',
                  )}
                >
                  {countdown}s
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {haversineKm(
                  { lat: driver.latitude, lng: driver.longitude },
                  pending.pickup,
                ).toFixed(1)}{' '}
                km de vous
              </p>
              <div className="mt-3 space-y-2.5">
                <p className="flex items-center gap-2.5 text-sm text-slate-200">
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-emerald-400" />
                  {pending.pickup.address}
                </p>
                <p className="flex items-center gap-2.5 text-sm text-slate-200">
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-rose-400" />
                  {pending.dropoff.address}
                </p>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 border-t border-white/5 pt-4">
                <div>
                  <p className="text-[11px] text-slate-500">Type de service</p>
                  <p className="flex items-center gap-1.5 text-sm font-bold text-white">
                    <CarFront className="h-4 w-4 text-violet-400" />
                    {pending.vehicleType === 'taxi' ? 'Taxi' : 'Moto'}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-slate-500">Estimation du prix</p>
                  <p className="text-lg font-extrabold text-emerald-400">
                    {formatGdes(pending.price)}
                  </p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => driverRefuseRide(pending.id)}
                  className="h-11 rounded-xl border-white/10 bg-transparent font-semibold text-slate-300 hover:bg-white/5"
                >
                  Refuser
                </Button>
                <Button
                  onClick={() => driverAcceptRide(pending.id)}
                  className="h-11 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                >
                  Accepter
                </Button>
              </div>
            </Card>
          )}

          {/* Course active */}
          {active && active.status !== 'pending' && (
            <Card dark>
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-extrabold text-white">Course en cours</h2>
                <span className="rounded-full bg-violet-500/15 px-3 py-1 text-xs font-bold text-violet-300">
                  #{active.id}
                </span>
              </div>
              <div className="space-y-2.5 text-sm">
                <p className="flex items-center gap-2.5 text-slate-300">
                  <MapPin className="h-4 w-4 shrink-0 text-emerald-400" />
                  {active.pickup.address}
                </p>
                <p className="flex items-center gap-2.5 text-slate-300">
                  <Navigation className="h-4 w-4 shrink-0 text-violet-400" />
                  {active.dropoff.address}
                </p>
                <p className="text-xs text-slate-500">
                  Client : {active.clientName ?? 'Client'} • {formatGdes(active.price)} (dont{' '}
                  {formatGdes(Math.round(active.price * (1 - COMMISSION_RATE)))} pour vous)
                </p>
              </div>
              <div className="mt-4 space-y-2.5">
                {active.status === 'driver_en_route' && (
                  <Button
                    onClick={() => driverMarkArrived(active.id)}
                    className="h-11 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
                  >
                    Je suis arrivé
                  </Button>
                )}
                {active.status === 'driver_arrived' && (
                  <Button
                    onClick={() => driverStartRide(active.id)}
                    className="h-11 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
                  >
                    Commencer la course
                  </Button>
                )}
                {active.status === 'started' && (
                  <Button
                    onClick={() => completeRide(active.id)}
                    className="h-11 w-full rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                  >
                    Terminer la course
                  </Button>
                )}
                {navUrl && (
                  <a href={navUrl} target="_blank" rel="noreferrer">
                    <Button
                      variant="outline"
                      className="h-11 w-full rounded-xl border-white/10 bg-transparent font-semibold text-slate-300 hover:bg-white/5"
                    >
                      <Navigation className="mr-2 h-4 w-4" /> Navigation GPS
                    </Button>
                  </a>
                )}
              </div>
            </Card>
          )}

          {/* Aucune demande */}
          {!pending && !active && driver.online && driver.approved && (
            <EmptyState
              dark
              icon={Clock}
              title="En attente de demandes…"
              text="Restez en ligne : les demandes de course à proximité apparaîtront ici automatiquement."
            />
          )}
          {!driver.online && driver.approved && (
            <EmptyState
              dark
              icon={CarFront}
              title="Vous êtes hors ligne"
              text="Activez le statut « En ligne » pour commencer à recevoir des courses."
            />
          )}
        </div>

        {/* Carte sombre */}
        <div className="min-h-[380px] overflow-hidden rounded-2xl border border-white/5">
          <Map
            dark
            center={[driver.latitude, driver.longitude]}
            zoom={14}
            markers={markers}
            polyline={geometry.length >= 2 ? geometry : undefined}
            fitToContent={!!active}
          />
        </div>
      </div>

      {/* Statistiques du jour */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card dark>
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-500/15 text-violet-300">
              <BadgeCheck className="h-5.5 w-5.5" />
            </span>
            <div>
              <p className="text-xs text-slate-500">Courses aujourd’hui</p>
              <p className="text-2xl font-extrabold text-white">{todayRides.length}</p>
            </div>
          </div>
        </Card>
        <Card dark>
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-300">
              <Wallet className="h-5.5 w-5.5" />
            </span>
            <div>
              <p className="text-xs text-slate-500">Revenus aujourd’hui</p>
              <p className="text-2xl font-extrabold text-white">{formatGdes(todayEarnings)}</p>
            </div>
          </div>
        </Card>
        <Card dark>
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/15 text-amber-300">
              <Star className="h-5.5 w-5.5" />
            </span>
            <div>
              <p className="text-xs text-slate-500">Note moyenne</p>
              <p className="flex items-center gap-1.5 text-2xl font-extrabold text-white">
                {driver.rating.toFixed(1)}
                <Star className="h-4.5 w-4.5 fill-amber-400 text-amber-400" />
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Dernières courses */}
      <Card dark>
        <h3 className="mb-4 font-extrabold text-white">Courses récentes</h3>
        {todayRides.length === 0 ? (
          <p className="py-4 text-center text-sm text-slate-500">
            Aucune course terminée aujourd’hui — {formatDateTime(Date.now())}
          </p>
        ) : (
          <div className="divide-y divide-white/5">
            {todayRides.slice(0, 5).map((r) => (
              <div key={r.id} className="flex items-center justify-between py-3 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-semibold text-slate-200">
                    {r.pickup.address} → {r.dropoff.address}
                  </p>
                  <p className="text-xs text-slate-500">{formatDateTime(r.createdAt)}</p>
                </div>
                <p className="font-extrabold text-emerald-400">
                  +{formatGdes(Math.round(r.price * (1 - COMMISSION_RATE)))}
                </p>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  )
}
