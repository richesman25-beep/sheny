// Profil chauffeur : infos personnelles + véhicule
import { useState } from 'react'
import type { FormEvent } from 'react'
import { BadgeCheck, CarFront, Hourglass, Mail, Phone, Save, Star } from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader, Card } from '@/components/ui-kit'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { getDriver, updateDriver, updateUser } from '@/services/demo'
import { formatGdes } from '@/services/pricing'
import { cn } from '@/lib/utils'

export default function DriverProfile() {
  const { user, refresh } = useAuth()
  useStore()
  const driver = user ? getDriver(user.id) : undefined
  const [fullname, setFullname] = useState(user?.fullname ?? '')
  const [phone, setPhone] = useState(user?.phone ?? '')
  const [color, setColor] = useState(driver?.color ?? '')
  const [plate, setPlate] = useState(driver?.plate ?? '')

  if (!user || !driver) return null

  const save = (e: FormEvent) => {
    e.preventDefault()
    updateUser(user.id, { fullname: fullname.trim(), phone: phone.trim() })
    updateDriver(user.id, { color: color.trim(), plate: plate.trim() })
    refresh()
    toast.success('Profil mis à jour !')
  }

  const sub = 'text-slate-400'

  return (
    <div className="p-4 sm:p-6">
      <PageHeader dark title="Profil" subtitle="Vos informations et votre véhicule" />
      <div className="grid max-w-3xl gap-5">
        <Card dark>
          <div className="flex flex-wrap items-center gap-5">
            <Avatar name={user.fullname} size="lg" className="h-20 w-20 text-2xl" />
            <div className="min-w-0 flex-1">
              <p className="text-xl font-extrabold text-white">{user.fullname}</p>
              <p className={cn('mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm', sub)}>
                <span className="flex items-center gap-1.5">
                  <Mail className="h-4 w-4" /> {user.email}
                </span>
                <span className="flex items-center gap-1.5">
                  <Phone className="h-4 w-4" /> {user.phone}
                </span>
              </p>
            </div>
            {driver.approved ? (
              <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-3.5 py-1.5 text-xs font-bold text-emerald-400">
                <BadgeCheck className="h-4 w-4" /> Chauffeur vérifié
              </span>
            ) : (
              <span className="flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3.5 py-1.5 text-xs font-bold text-amber-400">
                <Hourglass className="h-4 w-4" /> En attente de validation
              </span>
            )}
          </div>
          <div className="mt-5 grid grid-cols-3 gap-3 border-t border-white/5 pt-5 text-center">
            <div>
              <p className="text-xl font-extrabold text-white">{driver.totalRides}</p>
              <p className="text-xs text-slate-500">Courses</p>
            </div>
            <div>
              <p className="flex items-center justify-center gap-1 text-xl font-extrabold text-white">
                {driver.rating.toFixed(1)} <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
              </p>
              <p className="text-xs text-slate-500">Note moyenne</p>
            </div>
            <div>
              <p className="text-xl font-extrabold text-white">{formatGdes(driver.earnings)}</p>
              <p className="text-xs text-slate-500">Gains cumulés</p>
            </div>
          </div>
        </Card>

        <Card dark>
          <h3 className="mb-4 flex items-center gap-2 font-extrabold text-white">
            <CarFront className="h-5 w-5 text-violet-400" /> Véhicule
          </h3>
          <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            {[
              ['Type', driver.vehicleType === 'taxi' ? 'Taxi' : 'Moto'],
              ['Marque', driver.brand],
              ['Modèle', driver.model],
              ['CIN', driver.cin ?? '—'],
            ].map(([k, v]) => (
              <div key={k} className="rounded-xl border border-white/5 p-3">
                <p className="text-[11px] text-slate-500">{k}</p>
                <p className="font-semibold text-slate-200">{v}</p>
              </div>
            ))}
          </div>
          <form onSubmit={save} className="mt-5 grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label className={sub}>Couleur</Label>
                <Input
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  required
                  className="h-12 rounded-xl border-white/10 bg-white/5 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className={sub}>Plaque</Label>
                <Input
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  required
                  className="h-12 rounded-xl border-white/10 bg-white/5 text-white"
                />
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label className={sub}>Nom complet</Label>
                <Input
                  value={fullname}
                  onChange={(e) => setFullname(e.target.value)}
                  required
                  className="h-12 rounded-xl border-white/10 bg-white/5 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className={sub}>Téléphone</Label>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="h-12 rounded-xl border-white/10 bg-white/5 text-white"
                />
              </div>
            </div>
            <Button
              type="submit"
              className="h-12 rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              <Save className="mr-2 h-4.5 w-4.5" /> Enregistrer
            </Button>
          </form>
        </Card>
      </div>
    </div>
  )
}
