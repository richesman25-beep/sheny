import { PageHeader } from '@/components/ui-kit'
import { SettingsPanel } from '@/components/SettingsPanel'

export default function DriverSettings() {
  return (
    <div className="p-4 sm:p-6">
      <PageHeader dark title="Paramètres" subtitle="Personnalisez votre espace chauffeur" />
      <SettingsPanel dark />
    </div>
  )
}
