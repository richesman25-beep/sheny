import { PageHeader } from '@/components/ui-kit'
import { ChatDemo } from '@/components/ChatDemo'

export default function DriverMessages() {
  return (
    <div className="p-4 sm:p-6">
      <PageHeader dark title="Messages" subtitle="Échangez avec vos clients ou le support" />
      <div className="max-w-2xl">
        <ChatDemo dark contactName="Support TaxiPa’w" contactRole="Assistance chauffeurs" />
      </div>
    </div>
  )
}
