// Tableau de bord administrateur
import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import {
  CarFront,
  CircleDollarSign,
  Map,
  Percent,
  Users,
} from 'lucide-react'
import { PageHeader, StatCard, StatusBadge, Card, formatDateTime } from '@/components/ui-kit'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useStore } from '@/hooks/useStore'
import { adminStats, approveDriver } from '@/services/demo'
import { formatGdes } from '@/services/pricing'
import type { Driver } from '@/types'
import { toast } from 'sonner'

export default function AdminDashboard() {
  const db = useStore()
  const stats = adminStats()
  const pendingDrivers = db.drivers.filter((d) => !d.approved)
  const recentRides = [...db.rides]
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 6)
  const [selected, setSelected] = useState<Driver | null>(null)

  const driverName = (userId: string) =>
    db.users.find((u) => u.id === userId)?.fullname ?? 'Inconnu'

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <PageHeader
        title="Tableau de bord"
        subtitle={new Date().toLocaleDateString('fr-FR', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })}
      />

      {/* Statistiques */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard icon={Map} label="Courses aujourd’hui" value={String(stats.ridesToday)} trend="+12%" accent="violet" />
        <StatCard icon={CarFront} label="Chauffeurs actifs" value={String(stats.driversActive)} trend="+8%" accent="emerald" />
        <StatCard icon={Users} label="Clients actifs" value={String(stats.clientsActive)} trend="+15%" accent="sky" />
        <StatCard icon={CircleDollarSign} label="Revenus aujourd’hui" value={formatGdes(stats.revenueToday)} trend="+18%" accent="amber" />
        <StatCard icon={Percent} label="Commissions" value={formatGdes(stats.commissionToday)} trend="+18%" accent="rose" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
        {/* Graphique */}
        <Card>
          <h3 className="mb-4 font-extrabold">Courses (7 derniers jours)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.weeklySeries} margin={{ left: -20, right: 8, top: 4 }}>
                <defs>
                  <linearGradient id="rides" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#7c3aed" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#7c3aed" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    borderRadius: 12,
                    border: '1px solid #e2e8f0',
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                  formatter={(v) => [`${v} courses`, 'Total']}
                />
                <Area type="monotone" dataKey="rides" stroke="#7c3aed" strokeWidth={2.5} fill="url(#rides)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Demandes de chauffeurs */}
        <Card>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-extrabold">Demandes de chauffeurs</h3>
            <Link to="/admin/chauffeurs" className="text-xs font-bold text-violet-600 hover:underline">
              Voir tout
            </Link>
          </div>
          {pendingDrivers.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-400">Aucune demande en attente 🎉</p>
          ) : (
            <div className="space-y-3">
              {pendingDrivers.slice(0, 4).map((d) => (
                <div key={d.userId} className="flex items-center gap-3 rounded-xl border border-slate-100 p-3">
                  <Avatar name={driverName(d.userId)} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{driverName(d.userId)}</p>
                    <p className="truncate text-xs text-slate-500">
                      {d.brand} {d.model} — {d.plate}
                    </p>
                  </div>
                  <span className="rounded-full bg-amber-100 px-2.5 py-1 text-[10px] font-bold text-amber-700">
                    En attente
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setSelected(d)}
                    className="h-8 rounded-lg text-xs font-semibold"
                  >
                    Voir
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Courses récentes */}
      <Card>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-extrabold">Courses récentes</h3>
          <Link to="/admin/courses" className="text-xs font-bold text-violet-600 hover:underline">
            Voir tout
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="pb-3 font-semibold">Course</th>
                <th className="pb-3 font-semibold">Trajet</th>
                <th className="pb-3 font-semibold">Date</th>
                <th className="pb-3 font-semibold">Prix</th>
                <th className="pb-3 font-semibold">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {recentRides.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50/60">
                  <td className="py-3 font-bold text-slate-700">#{r.id}</td>
                  <td className="max-w-[280px] truncate py-3 text-slate-600">
                    {r.pickup.address.split(',')[0]} → {r.dropoff.address.split(',')[0]}
                  </td>
                  <td className="py-3 text-slate-500">{formatDateTime(r.createdAt)}</td>
                  <td className="py-3 font-bold text-slate-800">{formatGdes(r.price)}</td>
                  <td className="py-3">
                    <StatusBadge status={r.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Détail chauffeur */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="rounded-2xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>Dossier chauffeur</DialogTitle>
                <DialogDescription>Vérifiez les informations avant validation.</DialogDescription>
              </DialogHeader>
              <div className="flex items-center gap-4 rounded-xl bg-slate-50 p-4">
                <Avatar name={driverName(selected.userId)} size="lg" />
                <div>
                  <p className="font-bold">{driverName(selected.userId)}</p>
                  <p className="text-xs text-slate-500">
                    {db.users.find((u) => u.id === selected.userId)?.phone}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {[
                  ['Type', selected.vehicleType === 'taxi' ? 'Taxi' : 'Moto'],
                  ['Véhicule', `${selected.brand} ${selected.model}`],
                  ['Couleur', selected.color],
                  ['Plaque', selected.plate],
                  ['CIN', selected.cin ?? '—'],
                  ['Permis', selected.license ?? '—'],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-xl border border-slate-100 p-3">
                    <p className="text-[11px] text-slate-400">{k}</p>
                    <p className="font-semibold">{v}</p>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    approveDriver(selected.userId, false)
                    setSelected(null)
                    toast.info('Dossier refusé.')
                  }}
                  className="h-11 rounded-xl border-rose-200 font-semibold text-rose-600 hover:bg-rose-50"
                >
                  Refuser
                </Button>
                <Button
                  onClick={() => {
                    approveDriver(selected.userId, true)
                    setSelected(null)
                    toast.success('Chauffeur approuvé !')
                  }}
                  className="h-11 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                >
                  Approuver
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
