// Gestion des promotions (admin)
import { useState } from 'react'
import type { FormEvent } from 'react'
import { Plus, Tag, Trash2 } from 'lucide-react'
import { PageHeader, EmptyState, formatDateTime } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { useStore } from '@/hooks/useStore'
import { deletePromotion, savePromotion } from '@/services/demo'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export default function AdminPromotions() {
  const db = useStore()
  const [open, setOpen] = useState(false)
  const [code, setCode] = useState('')
  const [description, setDescription] = useState('')
  const [discount, setDiscount] = useState('10')

  const create = (e: FormEvent) => {
    e.preventDefault()
    const pct = Number(discount)
    if (!code.trim() || !description.trim() || !(pct > 0 && pct <= 100)) return
    savePromotion({
      code: code.trim().toUpperCase(),
      description: description.trim(),
      discountPct: pct,
      active: true,
    })
    setCode('')
    setDescription('')
    setDiscount('10')
    setOpen(false)
    toast.success('Promotion créée !')
  }

  return (
    <div className="p-4 sm:p-6">
      <PageHeader
        title="Promotions"
        subtitle={`${db.promotions.length} codes promotionnels`}
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700">
                <Plus className="mr-2 h-4 w-4" /> Nouvelle promotion
              </Button>
            </DialogTrigger>
            <DialogContent className="rounded-2xl">
              <DialogHeader>
                <DialogTitle>Créer une promotion</DialogTitle>
                <DialogDescription>Le code sera utilisable par tous les clients.</DialogDescription>
              </DialogHeader>
              <form onSubmit={create} className="grid gap-4">
                <div className="space-y-2">
                  <Label>Code promo</Label>
                  <Input
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="Ex : FETE25"
                    required
                    className="h-11 rounded-xl uppercase"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Input
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Ex : 25 % sur les courses du week-end"
                    required
                    className="h-11 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Réduction (%)</Label>
                  <Input
                    type="number"
                    min={1}
                    max={100}
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    required
                    className="h-11 rounded-xl"
                  />
                </div>
                <Button
                  type="submit"
                  className="h-11 rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
                >
                  Créer la promotion
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      {db.promotions.length === 0 ? (
        <EmptyState icon={Tag} title="Aucune promotion" text="Créez votre premier code promo." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {db.promotions.map((p) => (
            <div key={p.id} className="rounded-2xl border border-slate-100 bg-white p-5">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 rounded-xl bg-violet-100 px-3.5 py-2 font-mono text-sm font-extrabold tracking-wide text-violet-700">
                  <Tag className="h-4 w-4" /> {p.code}
                </span>
                <span
                  className={cn(
                    'rounded-full px-2.5 py-1 text-xs font-bold',
                    p.active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500',
                  )}
                >
                  {p.active ? 'Active' : 'Inactive'}
                </span>
              </div>
              <p className="mt-3 text-sm text-slate-600">{p.description}</p>
              <p className="mt-1 text-xs text-slate-400">
                -{p.discountPct} % • {p.uses} utilisations • créée le {formatDateTime(p.createdAt)}
              </p>
              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
                <Switch
                  checked={p.active}
                  onCheckedChange={(v) => savePromotion({ ...p, active: v })}
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    deletePromotion(p.id)
                    toast.info('Promotion supprimée.')
                  }}
                  className="h-9 rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-500"
                >
                  <Trash2 className="mr-1.5 h-4 w-4" /> Supprimer
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
