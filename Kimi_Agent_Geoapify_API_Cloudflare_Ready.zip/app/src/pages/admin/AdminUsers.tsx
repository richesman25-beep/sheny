// Gestion des utilisateurs (admin)
import { useState } from 'react'
import { Search, ShieldBan, ShieldCheck, Users } from 'lucide-react'
import { PageHeader, EmptyState, formatDateTime } from '@/components/ui-kit'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useStore } from '@/hooks/useStore'
import { updateUser } from '@/services/demo'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

const ROLE_LABELS: Record<string, string> = {
  client: 'Client',
  driver: 'Chauffeur',
  admin: 'Admin',
}

export default function AdminUsers() {
  const db = useStore()
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState<'all' | 'client' | 'driver' | 'admin'>('all')

  const users = db.users
    .filter((u) => roleFilter === 'all' || u.role === roleFilter)
    .filter(
      (u) =>
        u.fullname.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase()),
    )

  return (
    <div className="p-4 sm:p-6">
      <PageHeader title="Utilisateurs" subtitle={`${db.users.length} comptes enregistrés`} />

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un utilisateur…"
            className="h-11 w-72 rounded-xl pl-10"
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'client', 'driver', 'admin'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRoleFilter(r)}
              className={cn(
                'rounded-full px-4 py-2 text-sm font-semibold transition-colors',
                roleFilter === r
                  ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/25'
                  : 'bg-white text-slate-500 hover:bg-slate-100',
              )}
            >
              {r === 'all' ? 'Tous' : ROLE_LABELS[r]}
            </button>
          ))}
        </div>
      </div>

      {users.length === 0 ? (
        <EmptyState icon={Users} title="Aucun utilisateur" text="Modifiez votre recherche ou vos filtres." />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-100 bg-white">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="p-4 font-semibold">Utilisateur</th>
                <th className="p-4 font-semibold">Téléphone</th>
                <th className="p-4 font-semibold">Rôle</th>
                <th className="p-4 font-semibold">Inscription</th>
                <th className="p-4 font-semibold">Statut</th>
                <th className="p-4 font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/60">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar name={u.fullname} size="sm" />
                      <div>
                        <p className="font-bold">{u.fullname}</p>
                        <p className="text-xs text-slate-400">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-slate-500">{u.phone}</td>
                  <td className="p-4">
                    <span
                      className={cn(
                        'rounded-full px-2.5 py-1 text-xs font-bold',
                        u.role === 'admin'
                          ? 'bg-violet-100 text-violet-700'
                          : u.role === 'driver'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-sky-100 text-sky-700',
                      )}
                    >
                      {ROLE_LABELS[u.role]}
                    </span>
                  </td>
                  <td className="p-4 text-slate-500">{formatDateTime(u.createdAt)}</td>
                  <td className="p-4">
                    <span
                      className={cn(
                        'rounded-full px-2.5 py-1 text-xs font-bold',
                        u.status === 'active'
                          ? 'bg-emerald-100 text-emerald-700'
                          : u.status === 'pending'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-rose-100 text-rose-700',
                      )}
                    >
                      {u.status === 'active' ? 'Actif' : u.status === 'pending' ? 'En attente' : 'Suspendu'}
                    </span>
                  </td>
                  <td className="p-4">
                    {u.role !== 'admin' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const next = u.status === 'suspended' ? 'active' : 'suspended'
                          updateUser(u.id, { status: next })
                          toast.success(
                            next === 'active' ? 'Compte réactivé.' : 'Compte suspendu.',
                          )
                        }}
                        className={cn(
                          'h-9 rounded-lg text-xs font-semibold',
                          u.status === 'suspended'
                            ? 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                            : 'border-rose-200 text-rose-600 hover:bg-rose-50',
                        )}
                      >
                        {u.status === 'suspended' ? (
                          <>
                            <ShieldCheck className="mr-1.5 h-3.5 w-3.5" /> Réactiver
                          </>
                        ) : (
                          <>
                            <ShieldBan className="mr-1.5 h-3.5 w-3.5" /> Suspendre
                          </>
                        )}
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
