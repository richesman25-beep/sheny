// Paiements et commissions (admin)
import { Banknote, CircleDollarSign, Percent, TrendingUp } from 'lucide-react'
import { PageHeader, StatCard, Card, formatDateTime } from '@/components/ui-kit'
import { useStore } from '@/hooks/useStore'
import { COMMISSION_RATE, formatGdes } from '@/services/pricing'

export default function AdminPayments() {
  const db = useStore()
  const completed = db.rides.filter((r) => r.status === 'completed')
  const totalRevenue = completed.reduce((s, r) => s + r.price, 0)
  const totalCommission = Math.round(totalRevenue * COMMISSION_RATE)
  const driversShare = totalRevenue - totalCommission

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <PageHeader title="Paiements" subtitle="Revenus, commissions et règlements chauffeurs" />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard icon={CircleDollarSign} label="Chiffre d’affaires total" value={formatGdes(totalRevenue)} trend="+18%" accent="violet" />
        <StatCard icon={Percent} label={`Commissions (${Math.round(COMMISSION_RATE * 100)} %)`} value={formatGdes(totalCommission)} trend="+18%" accent="rose" />
        <StatCard icon={TrendingUp} label="Reversé aux chauffeurs" value={formatGdes(driversShare)} trend="+15%" accent="emerald" />
      </div>

      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { icon: Banknote, name: 'Espèces', share: '100 %', desc: 'Méthode active au lancement' },
          { icon: Banknote, name: 'MonCash', share: '—', desc: 'Intégration prévue (phase 2)' },
          { icon: Banknote, name: 'NatCash', share: '—', desc: 'Intégration prévue (phase 2)' },
          { icon: Banknote, name: 'Carte bancaire', share: '—', desc: 'Intégration prévue (phase 3)' },
        ].map((m, i) => (
          <Card key={m.name} className={i > 0 ? 'opacity-70' : 'border-violet-200 bg-violet-50/40'}>
            <p className="font-bold">{m.name}</p>
            <p className="mt-1 text-2xl font-extrabold">{m.share}</p>
            <p className="mt-1 text-xs text-slate-500">{m.desc}</p>
          </Card>
        ))}
      </div>

      <Card>
        <h3 className="mb-4 font-extrabold">Dernières courses réglées</h3>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="pb-3 font-semibold">Course</th>
                <th className="pb-3 font-semibold">Date</th>
                <th className="pb-3 font-semibold">Montant</th>
                <th className="pb-3 font-semibold">Commission</th>
                <th className="pb-3 font-semibold">Chauffeur</th>
                <th className="pb-3 font-semibold">Méthode</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {completed
                .sort((a, b) => b.createdAt - a.createdAt)
                .slice(0, 12)
                .map((r) => (
                  <tr key={`${r.id}-${r.createdAt}`} className="hover:bg-slate-50/60">
                    <td className="py-3 font-bold text-slate-700">#{r.id}</td>
                    <td className="py-3 text-slate-500">{formatDateTime(r.createdAt)}</td>
                    <td className="py-3 font-bold">{formatGdes(r.price)}</td>
                    <td className="py-3 font-semibold text-rose-600">
                      {formatGdes(Math.round(r.price * COMMISSION_RATE))}
                    </td>
                    <td className="py-3 font-semibold text-emerald-600">
                      {formatGdes(Math.round(r.price * (1 - COMMISSION_RATE)))}
                    </td>
                    <td className="py-3">
                      <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-700">
                        Espèces
                      </span>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
