// Gestion et validation des chauffeurs (admin)
import { BadgeCheck, CarFront, Star, XCircle } from 'lucide-react'
import { PageHeader, EmptyState } from '@/components/ui-kit'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import { useStore } from '@/hooks/useStore'
import { approveDriver } from '@/services/demo'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export default function AdminDrivers() {
  const db = useStore()
  const name = (id: string) => db.users.find((u) => u.id === id)?.fullname ?? 'Inconnu'
  const pending = db.drivers.filter((d) => !d.approved)
  const approved = db.drivers.filter((d) => d.approved)

  return (
    <div className="space-y-8 p-4 sm:p-6">
      <PageHeader
        title="Chauffeurs"
        subtitle={`${approved.length} approuvés • ${pending.length} en attente de validation`}
      />

      {/* En attente */}
      <section>
        <h2 className="mb-4 text-lg font-extrabold">Demandes de validation</h2>
        {pending.length === 0 ? (
          <EmptyState
            icon={BadgeCheck}
            title="Aucune demande en attente"
            text="Tous les dossiers chauffeurs ont été traités."
          />
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {pending.map((d) => (
              <div key={d.userId} className="rounded-2xl border border-amber-200 bg-amber-50/40 p-5">
                <div className="flex items-center gap-4">
                  <Avatar name={name(d.userId)} size="lg" />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold">{name(d.userId)}</p>
                    <p className="text-xs text-slate-500">
                      {d.vehicleType === 'taxi' ? 'Taxi' : 'Moto'} • {d.brand} {d.model} •{' '}
                      {d.color}
                    </p>
                  </div>
                  <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
                    En attente
                  </span>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
                  {[
                    ['Plaque', d.plate],
                    ['CIN', d.cin ?? '—'],
                    ['Permis', d.license ?? '—'],
                  ].map(([k, v]) => (
                    <div key={k} className="rounded-xl border border-amber-100 bg-white p-2.5">
                      <p className="text-[10px] text-slate-400">{k}</p>
                      <p className="font-bold">{v}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      approveDriver(d.userId, false)
                      toast.info('Dossier refusé.')
                    }}
                    className="h-10 rounded-xl border-rose-200 font-semibold text-rose-600 hover:bg-rose-50"
                  >
                    <XCircle className="mr-2 h-4 w-4" /> Refuser
                  </Button>
                  <Button
                    onClick={() => {
                      approveDriver(d.userId, true)
                      toast.success(`${name(d.userId)} approuvé !`)
                    }}
                    className="h-10 rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                  >
                    <BadgeCheck className="mr-2 h-4 w-4" /> Approuver
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Approuvés */}
      <section>
        <h2 className="mb-4 text-lg font-extrabold">Chauffeurs actifs</h2>
        <div className="overflow-x-auto rounded-2xl border border-slate-100 bg-white">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="p-4 font-semibold">Chauffeur</th>
                <th className="p-4 font-semibold">Véhicule</th>
                <th className="p-4 font-semibold">Plaque</th>
                <th className="p-4 font-semibold">Note</th>
                <th className="p-4 font-semibold">Courses</th>
                <th className="p-4 font-semibold">Statut</th>
                <th className="p-4 font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {approved.map((d) => (
                <tr key={d.userId} className="hover:bg-slate-50/60">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar name={name(d.userId)} size="sm" />
                      <p className="font-bold">{name(d.userId)}</p>
                    </div>
                  </td>
                  <td className="p-4 text-slate-600">
                    <span className="flex items-center gap-1.5">
                      <CarFront className="h-4 w-4 text-violet-500" />
                      {d.brand} {d.model}
                    </span>
                  </td>
                  <td className="p-4 font-semibold">{d.plate}</td>
                  <td className="p-4">
                    <span className="flex items-center gap-1 font-semibold">
                      <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                      {d.rating.toFixed(1)}
                    </span>
                  </td>
                  <td className="p-4 text-slate-500">{d.totalRides}</td>
                  <td className="p-4">
                    <span
                      className={cn(
                        'rounded-full px-2.5 py-1 text-xs font-bold',
                        d.online ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500',
                      )}
                    >
                      {d.online ? 'En ligne' : 'Hors ligne'}
                    </span>
                  </td>
                  <td className="p-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        approveDriver(d.userId, false)
                        toast.info('Approbation retirée.')
                      }}
                      className="h-9 rounded-lg border-rose-200 text-xs font-semibold text-rose-600 hover:bg-rose-50"
                    >
                      Révoquer
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
