// Paramètres de la plateforme (admin)
import { Bike, CarFront, Percent } from 'lucide-react'
import { PageHeader, Card } from '@/components/ui-kit'
import { SettingsPanel } from '@/components/SettingsPanel'
import { COMMISSION_RATE, TARIFFS, formatGdes } from '@/services/pricing'

export default function AdminSettings() {
  return (
    <div className="space-y-6 p-4 sm:p-6">
      <PageHeader title="Paramètres" subtitle="Configuration de la plateforme" />

      <div className="grid max-w-3xl gap-5">
        <Card>
          <h3 className="mb-4 font-extrabold">Commission de la plateforme</h3>
          <div className="flex items-center gap-4 rounded-2xl bg-violet-50 p-5">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-600 text-white">
              <Percent className="h-6 w-6" />
            </span>
            <div>
              <p className="text-2xl font-extrabold text-violet-700">
                {Math.round(COMMISSION_RATE * 100)} %
              </p>
              <p className="text-xs text-slate-500">
                Prélevée sur chaque course — le reste revient au chauffeur.
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <h3 className="mb-4 font-extrabold">Grille tarifaire (gourdes)</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { icon: CarFront, name: 'Taxi', t: TARIFFS.taxi },
              { icon: Bike, name: 'Moto', t: TARIFFS.moto },
            ].map((s) => (
              <div key={s.name} className="rounded-2xl border border-slate-100 p-5">
                <p className="flex items-center gap-2 font-bold">
                  <s.icon className="h-5 w-5 text-violet-600" /> {s.name}
                </p>
                <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <p className="rounded-xl bg-slate-50 p-2.5">
                    <span className="block text-[10px] text-slate-400">Prise en charge</span>
                    <span className="font-bold">{formatGdes(s.t.base)}</span>
                  </p>
                  <p className="rounded-xl bg-slate-50 p-2.5">
                    <span className="block text-[10px] text-slate-400">Par km</span>
                    <span className="font-bold">{s.t.perKm} G</span>
                  </p>
                  <p className="rounded-xl bg-slate-50 p-2.5">
                    <span className="block text-[10px] text-slate-400">Par minute</span>
                    <span className="font-bold">{s.t.perMin} G</span>
                  </p>
                  <p className="rounded-xl bg-slate-50 p-2.5">
                    <span className="block text-[10px] text-slate-400">Minimum</span>
                    <span className="font-bold">{formatGdes(s.t.minimum)}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <SettingsPanel />
    </div>
  )
}
