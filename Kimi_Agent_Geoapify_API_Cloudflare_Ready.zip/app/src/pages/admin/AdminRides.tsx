// Toutes les courses (admin)
import { useState } from 'react'
import { Map } from 'lucide-react'
import { PageHeader, StatusBadge, EmptyState, formatDateTime } from '@/components/ui-kit'
import { Input } from '@/components/ui/input'
import { useStore } from '@/hooks/useStore'
import { formatGdes } from '@/services/pricing'
import type { RideStatus } from '@/types'
import { cn } from '@/lib/utils'

const TABS: { value: 'all' | RideStatus; label: string }[] = [
  { value: 'all', label: 'Toutes' },
  { value: 'completed', label: 'Terminées' },
  { value: 'cancelled', label: 'Annulées' },
  { value: 'started', label: 'En cours' },
  { value: 'pending', label: 'En attente' },
]

export default function AdminRides() {
  const db = useStore()
  const [tab, setTab] = useState<'all' | RideStatus>('all')
  const [search, setSearch] = useState('')

  const name = (id?: string) =>
    id ? (db.users.find((u) => u.id === id)?.fullname ?? '—') : '—'

  const rides = [...db.rides]
    .sort((a, b) => b.createdAt - a.createdAt)
    .filter((r) => {
      if (tab === 'all') return true
      if (tab === 'started')
        return ['driver_found', 'driver_en_route', 'driver_arrived', 'started'].includes(r.status)
      return r.status === tab
    })
    .filter(
      (r) =>
        r.pickup.address.toLowerCase().includes(search.toLowerCase()) ||
        r.dropoff.address.toLowerCase().includes(search.toLowerCase()) ||
        r.id.toLowerCase().includes(search.toLowerCase()),
    )
    .slice(0, 60)

  return (
    <div className="p-4 sm:p-6">
      <PageHeader title="Courses" subtitle={`${db.rides.length} courses enregistrées`} />

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher par trajet ou numéro…"
          className="h-11 w-72 rounded-xl"
        />
        <div className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.value}
              onClick={() => setTab(t.value)}
              className={cn(
                'rounded-full px-4 py-2 text-sm font-semibold transition-colors',
                tab === t.value
                  ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/25'
                  : 'bg-white text-slate-500 hover:bg-slate-100',
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {rides.length === 0 ? (
        <EmptyState icon={Map} title="Aucune course" text="Aucune course ne correspond aux filtres." />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-100 bg-white">
          <table className="w-full min-w-[820px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="p-4 font-semibold">N°</th>
                <th className="p-4 font-semibold">Trajet</th>
                <th className="p-4 font-semibold">Client</th>
                <th className="p-4 font-semibold">Chauffeur</th>
                <th className="p-4 font-semibold">Date</th>
                <th className="p-4 font-semibold">Prix</th>
                <th className="p-4 font-semibold">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {rides.map((r) => (
                <tr key={`${r.id}-${r.createdAt}`} className="hover:bg-slate-50/60">
                  <td className="p-4 font-bold text-slate-700">#{r.id}</td>
                  <td className="max-w-[240px] truncate p-4 text-slate-600">
                    {r.pickup.address.split(',')[0]} → {r.dropoff.address.split(',')[0]}
                  </td>
                  <td className="p-4 text-slate-600">{name(r.clientId)}</td>
                  <td className="p-4 text-slate-600">{name(r.driverId)}</td>
                  <td className="p-4 text-slate-500">{formatDateTime(r.createdAt)}</td>
                  <td className="p-4 font-bold">{formatGdes(r.price)}</td>
                  <td className="p-4">
                    <StatusBadge status={r.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
