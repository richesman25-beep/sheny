// Envoi de notifications (admin)
import { useState } from 'react'
import type { FormEvent } from 'react'
import { Bell, Send } from 'lucide-react'
import { PageHeader, Card, EmptyState, formatDateTime } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useStore } from '@/hooks/useStore'
import { notify } from '@/services/demo'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export default function AdminNotifications() {
  const db = useStore()
  const [title, setTitle] = useState('')
  const [message, setMessage] = useState('')
  const [audience, setAudience] = useState<'clients' | 'drivers' | 'all'>('all')

  const send = (e: FormEvent) => {
    e.preventDefault()
    if (!title.trim() || !message.trim()) return
    const targets = db.users.filter(
      (u) =>
        u.role !== 'admin' &&
        (audience === 'all' ||
          (audience === 'clients' && u.role === 'client') ||
          (audience === 'drivers' && u.role === 'driver')),
    )
    targets.forEach((u) => notify(u.id, title.trim(), message.trim()))
    setTitle('')
    setMessage('')
    toast.success(`Notification envoyée à ${targets.length} utilisateurs.`)
  }

  const recent = [...db.notifications].sort((a, b) => b.createdAt - a.createdAt).slice(0, 10)
  const userName = (id: string) => db.users.find((u) => u.id === id)?.fullname ?? 'Utilisateur'

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <PageHeader title="Notifications" subtitle="Communiquez avec vos clients et chauffeurs" />

      <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
        <Card>
          <h3 className="mb-4 font-extrabold">Nouvelle notification</h3>
          <form onSubmit={send} className="grid gap-4">
            <div className="space-y-2">
              <Label>Destinataires</Label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { value: 'all' as const, label: 'Tous' },
                  { value: 'clients' as const, label: 'Clients' },
                  { value: 'drivers' as const, label: 'Chauffeurs' },
                ].map((a) => (
                  <button
                    key={a.value}
                    type="button"
                    onClick={() => setAudience(a.value)}
                    className={cn(
                      'rounded-xl border-2 py-2.5 text-sm font-semibold transition-colors',
                      audience === a.value
                        ? 'border-violet-500 bg-violet-50 text-violet-700'
                        : 'border-slate-200 text-slate-500',
                    )}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Titre</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex : Promotion ce week-end"
                required
                className="h-11 rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label>Message</Label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Votre message…"
                required
                rows={4}
                className="w-full rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-violet-400"
              />
            </div>
            <Button
              type="submit"
              className="h-11 rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              <Send className="mr-2 h-4 w-4" /> Envoyer
            </Button>
          </form>
        </Card>

        <Card>
          <h3 className="mb-4 font-extrabold">Notifications récentes</h3>
          {recent.length === 0 ? (
            <EmptyState icon={Bell} title="Aucune notification" text="Les notifications envoyées apparaîtront ici." />
          ) : (
            <div className="divide-y divide-slate-50">
              {recent.map((n) => (
                <div key={n.id} className="py-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-bold">{n.title}</p>
                    <p className="text-xs text-slate-400">{formatDateTime(n.createdAt)}</p>
                  </div>
                  <p className="mt-0.5 text-sm text-slate-500">{n.message}</p>
                  <p className="mt-0.5 text-xs text-slate-400">→ {userName(n.userId)}</p>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
