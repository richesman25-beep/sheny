// Connexion TaxiPa'w
import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { ArrowLeft, Loader2, Lock, Mail } from 'lucide-react'
import { Logo } from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useAuth } from '@/contexts/AuthContext'
import { homeFor } from '@/routes/RequireRole'

export default function Login() {
  const { login, resetPassword } = useAuth()
  const navigate = useNavigate()
  const location = useLocation() as { state?: { from?: string } }
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [resetOpen, setResetOpen] = useState(false)
  const [resetEmail, setResetEmail] = useState('')
  const [resetSent, setResetSent] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const user = await login(email, password)
      const target = location.state?.from
      navigate(target && target !== '/connexion' ? target : homeFor(user.role), { replace: true })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Connexion impossible.')
    } finally {
      setLoading(false)
    }
  }

  const quickLogin = async (mail: string, pwd: string) => {
    setEmail(mail)
    setPassword(pwd)
    setError('')
    setLoading(true)
    try {
      const user = await login(mail, pwd)
      navigate(homeFor(user.role), { replace: true })
    } catch {
      setError('Compte démo indisponible.')
    } finally {
      setLoading(false)
    }
  }

  const submitReset = async (e: FormEvent) => {
    e.preventDefault()
    await resetPassword(resetEmail)
    setResetSent(true)
  }

  return (
    <div className="flex min-h-screen">
      {/* Panneau gauche */}
      <div className="relative hidden w-[42%] flex-col justify-between overflow-hidden bg-gradient-to-br from-violet-700 via-violet-600 to-purple-700 p-12 text-white lg:flex">
        <div className="pointer-events-none absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
        <Logo to="/" dark />
        <div className="relative space-y-5">
          <h2 className="text-3xl font-extrabold leading-tight">
            Bon retour sur
            <br />
            TaxiPa’w
          </h2>
          <p className="max-w-sm text-violet-100">
            Connectez-vous pour commander une course, suivre vos chauffeurs en temps réel ou
            gérer votre activité.
          </p>
          <img
            src="/hero-taxi-moto.png"
            alt=""
            className="mt-4 w-72 opacity-95 drop-shadow-2xl"
            onError={(e) => {
              ;(e.target as HTMLImageElement).style.display = 'none'
            }}
          />
        </div>
        <p className="relative text-xs text-violet-200">Port-au-Prince • Pétion-Ville • Delmas</p>
      </div>

      {/* Formulaire */}
      <div className="flex flex-1 flex-col px-6 py-8 sm:px-12">
        <div className="flex items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-violet-600"
          >
            <ArrowLeft className="h-4 w-4" /> Retour
          </Link>
          <Logo to="/" className="lg:hidden" />
        </div>
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-10">
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">Se connecter</h1>
          <p className="mt-2 text-sm text-slate-500">
            Pas encore de compte ?{' '}
            <Link to="/inscription" className="font-semibold text-violet-600 hover:underline">
              Créer un compte
            </Link>
          </p>

          <form onSubmit={submit} className="mt-8 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-400" />
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="vous@exemple.ht"
                  className="h-12 rounded-xl pl-11"
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Mot de passe</Label>
                <button
                  type="button"
                  onClick={() => {
                    setResetOpen(true)
                    setResetEmail(email)
                    setResetSent(false)
                  }}
                  className="text-xs font-semibold text-violet-600 hover:underline"
                >
                  Mot de passe oublié ?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-400" />
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-12 rounded-xl pl-11"
                />
              </div>
            </div>
            {error && (
              <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-600">
                {error}
              </p>
            )}
            <Button
              type="submit"
              disabled={loading}
              className="h-12 w-full rounded-xl bg-violet-600 text-base font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Se connecter'}
            </Button>
          </form>

          <div className="mt-8">
            <p className="mb-3 text-center text-xs font-medium uppercase tracking-wide text-slate-400">
              Comptes de démonstration
            </p>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={loading}
                onClick={() => quickLogin('client@taxipaw.ht', 'demo1234')}
                className="rounded-xl"
              >
                Client
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={loading}
                onClick={() => quickLogin('chauffeur@taxipaw.ht', 'demo1234')}
                className="rounded-xl"
              >
                Chauffeur
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={loading}
                onClick={() => quickLogin('admin@taxipaw.ht', 'admin123')}
                className="rounded-xl"
              >
                Admin
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Réinitialisation du mot de passe */}
      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent className="rounded-2xl">
          <DialogHeader>
            <DialogTitle>Réinitialiser le mot de passe</DialogTitle>
            <DialogDescription>
              Entrez votre email : nous vous enverrons un lien de réinitialisation.
            </DialogDescription>
          </DialogHeader>
          {resetSent ? (
            <p className="rounded-xl bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700">
              Si un compte existe pour {resetEmail}, un lien de réinitialisation a été envoyé.
            </p>
          ) : (
            <form onSubmit={submitReset} className="space-y-4">
              <Input
                type="email"
                required
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                placeholder="vous@exemple.ht"
                className="h-12 rounded-xl"
              />
              <Button
                type="submit"
                className="h-11 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
              >
                Envoyer le lien
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
