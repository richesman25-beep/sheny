// Inscription en 3 étapes : informations → rôle → (véhicule si chauffeur)
import { useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Bike,
  CarFront,
  Check,
  CheckCircle2,
  Loader2,
  UserRound,
} from 'lucide-react'
import { Logo } from '@/components/Logo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/contexts/AuthContext'
import { homeFor } from '@/routes/RequireRole'
import type { VehicleType } from '@/types'
import { cn } from '@/lib/utils'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const initialRole = params.get('role') === 'chauffeur' ? 'driver' : null

  const [step, setStep] = useState(1)
  const [fullname, setFullname] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [role, setRole] = useState<'client' | 'driver' | null>(initialRole)
  const [vehicleType, setVehicleType] = useState<VehicleType>('taxi')
  const [brand, setBrand] = useState('')
  const [model, setModel] = useState('')
  const [color, setColor] = useState('')
  const [plate, setPlate] = useState('')
  const [cin, setCin] = useState('')
  const [license, setLicense] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)

  const totalSteps = useMemo(() => (role === 'driver' ? 3 : 3), [role])

  const step1Valid =
    fullname.trim().length >= 3 &&
    phone.trim().length >= 8 &&
    /.+@.+\..+/.test(email) &&
    password.length >= 6 &&
    password === confirm

  const nextFromStep1 = (e: FormEvent) => {
    e.preventDefault()
    setError('')
    if (password !== confirm) {
      setError('Les mots de passe ne correspondent pas.')
      return
    }
    if (password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères.')
      return
    }
    setStep(2)
  }

  const finish = async () => {
    if (!role) return
    setError('')
    setLoading(true)
    try {
      const user = await register({
        fullname,
        phone,
        email,
        password,
        role,
        driver:
          role === 'driver'
            ? { vehicleType, brand, model, color, plate, cin, license: license || undefined }
            : undefined,
      })
      if (role === 'driver') {
        setDone(true)
      } else {
        navigate(homeFor(user.role), { replace: true })
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Inscription impossible.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 px-6 py-8 sm:px-12">
      <div className="mx-auto flex w-full max-w-xl items-center justify-between">
        <button
          onClick={() => (step > 1 ? setStep(step - 1) : navigate('/'))}
          className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-violet-600"
        >
          <ArrowLeft className="h-4 w-4" /> Retour
        </button>
        <Logo to="/" />
        <span className="text-sm font-medium text-slate-400">
          Étape {step} sur {totalSteps}
        </span>
      </div>

      {/* Barre de progression */}
      <div className="mx-auto mt-6 w-full max-w-xl">
        <div className="h-1.5 overflow-hidden rounded-full bg-slate-200">
          <div
            className="h-full rounded-full bg-violet-600 transition-all duration-500"
            style={{ width: `${(step / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-xl flex-1 flex-col justify-center py-10">
        {done ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="rounded-3xl border border-slate-100 bg-white p-10 text-center shadow-sm"
          >
            <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
              <CheckCircle2 className="h-8 w-8 text-emerald-600" />
            </span>
            <h2 className="mt-5 text-2xl font-extrabold">Dossier envoyé !</h2>
            <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-slate-500">
              Votre demande chauffeur est <strong>en attente de validation</strong> par notre
              équipe. Vous recevrez une notification dès l’approbation — généralement sous 24 h.
            </p>
            <Button
              onClick={() => navigate('/chauffeur', { replace: true })}
              className="mt-7 h-12 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              Accéder à mon espace chauffeur
            </Button>
          </motion.div>
        ) : step === 1 ? (
          <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }}>
            <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
              Créez votre compte
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              Déjà inscrit ?{' '}
              <Link to="/connexion" className="font-semibold text-violet-600 hover:underline">
                Se connecter
              </Link>
            </p>
            <form onSubmit={nextFromStep1} className="mt-8 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullname">Nom complet</Label>
                <Input
                  id="fullname"
                  required
                  value={fullname}
                  onChange={(e) => setFullname(e.target.value)}
                  placeholder="Ex : Marie Jean"
                  className="h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Téléphone</Label>
                <Input
                  id="phone"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+509 37 00 0000"
                  className="h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="vous@exemple.ht"
                  className="h-12 rounded-xl"
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="6 caractères min."
                    className="h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm">Confirmation</Label>
                  <Input
                    id="confirm"
                    type="password"
                    required
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="Répétez le mot de passe"
                    className="h-12 rounded-xl"
                  />
                </div>
              </div>
              {error && (
                <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-600">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                disabled={!step1Valid}
                className="h-12 w-full rounded-xl bg-violet-600 text-base font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700"
              >
                Continuer
              </Button>
            </form>
          </motion.div>
        ) : step === 2 ? (
          <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }}>
            <h1 className="text-center text-2xl font-extrabold tracking-tight sm:text-3xl">
              Quel type de compte
              <br />
              souhaitez-vous créer ?
            </h1>
            <p className="mt-3 text-center text-sm text-slate-500">
              Choisissez le profil qui correspond à votre activité
            </p>
            <div className="mt-9 grid gap-4 sm:grid-cols-2">
              {[
                {
                  value: 'client' as const,
                  icon: UserRound,
                  title: 'Client',
                  text: 'Je veux commander un taxi ou une moto',
                  accent: 'violet',
                },
                {
                  value: 'driver' as const,
                  icon: CarFront,
                  title: 'Chauffeur',
                  text: 'Je veux conduire et gagner de l’argent',
                  accent: 'emerald',
                },
              ].map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setRole(c.value)}
                  className={cn(
                    'group relative flex flex-col items-center rounded-3xl border-2 bg-white p-8 text-center transition-all',
                    role === c.value
                      ? c.accent === 'violet'
                        ? 'border-violet-500 shadow-xl shadow-violet-100'
                        : 'border-emerald-500 shadow-xl shadow-emerald-100'
                      : 'border-slate-100 hover:border-slate-200',
                  )}
                >
                  <span
                    className={cn(
                      'flex h-16 w-16 items-center justify-center rounded-full transition-colors',
                      role === c.value
                        ? c.accent === 'violet'
                          ? 'bg-violet-100 text-violet-600'
                          : 'bg-emerald-100 text-emerald-600'
                        : 'bg-slate-100 text-slate-400 group-hover:bg-slate-200',
                    )}
                  >
                    <c.icon className="h-8 w-8" />
                  </span>
                  <span className="mt-4 text-lg font-bold">{c.title}</span>
                  <span className="mt-1.5 text-xs leading-relaxed text-slate-500">{c.text}</span>
                  <span
                    className={cn(
                      'mt-5 flex h-6 w-6 items-center justify-center rounded-full border-2 transition-colors',
                      role === c.value
                        ? c.accent === 'violet'
                          ? 'border-violet-600 bg-violet-600 text-white'
                          : 'border-emerald-600 bg-emerald-600 text-white'
                        : 'border-slate-200',
                    )}
                  >
                    {role === c.value && <Check className="h-4 w-4" />}
                  </span>
                </button>
              ))}
            </div>
            <Button
              onClick={() => (role === 'driver' ? setStep(3) : finish())}
              disabled={!role || loading}
              className="mt-8 h-13 w-full rounded-xl bg-violet-600 text-base font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Continuer'}
            </Button>
            {error && (
              <p className="mt-4 rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-600">
                {error}
              </p>
            )}
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }}>
            <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
              Informations du véhicule
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              Ces informations seront vérifiées avant l’activation de votre compte chauffeur.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                finish()
              }}
              className="mt-8 space-y-4"
            >
              <div className="space-y-2">
                <Label>Type de véhicule</Label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { value: 'taxi' as VehicleType, label: 'Taxi (voiture)', icon: CarFront },
                    { value: 'moto' as VehicleType, label: 'Moto', icon: Bike },
                  ].map((v) => (
                    <button
                      key={v.value}
                      type="button"
                      onClick={() => setVehicleType(v.value)}
                      className={cn(
                        'flex items-center justify-center gap-2 rounded-xl border-2 py-3.5 text-sm font-semibold transition-colors',
                        vehicleType === v.value
                          ? 'border-violet-500 bg-violet-50 text-violet-700'
                          : 'border-slate-200 text-slate-500 hover:border-slate-300',
                      )}
                    >
                      <v.icon className="h-5 w-5" />
                      {v.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Marque</Label>
                  <Input
                    required
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder="Ex : Toyota"
                    className="h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Modèle</Label>
                  <Input
                    required
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="Ex : Corolla"
                    className="h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Couleur</Label>
                  <Input
                    required
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                    placeholder="Ex : Noir"
                    className="h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Plaque d’immatriculation</Label>
                  <Input
                    required
                    value={plate}
                    onChange={(e) => setPlate(e.target.value)}
                    placeholder="Ex : AA-12345"
                    className="h-12 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Numéro CIN</Label>
                  <Input
                    required
                    value={cin}
                    onChange={(e) => setCin(e.target.value)}
                    placeholder="0000-0000-0000-0"
                    className="h-12 rounded-xl"
                  />
                </div>
                {vehicleType === 'taxi' && (
                  <div className="space-y-2">
                    <Label>Numéro de permis de conduire</Label>
                    <Input
                      required
                      value={license}
                      onChange={(e) => setLicense(e.target.value)}
                      placeholder="Ex : PERMIS-7000"
                      className="h-12 rounded-xl"
                    />
                  </div>
                )}
              </div>
              {error && (
                <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-600">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                disabled={
                  loading ||
                  !brand ||
                  !model ||
                  !color ||
                  !plate ||
                  !cin ||
                  (vehicleType === 'taxi' && !license)
                }
                className="h-13 w-full rounded-xl bg-violet-600 text-base font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700"
              >
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Envoyer mon dossier'}
              </Button>
              <p className="text-center text-xs text-slate-400">
                En continuant, vous acceptez les conditions d’utilisation de TaxiPa’w.
              </p>
            </form>
          </motion.div>
        )}
      </div>
    </div>
  )
}
