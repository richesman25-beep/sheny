// Page d'accueil publique — conforme à la maquette de référence
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowRight,
  CarFront,
  Clock,
  MapPin,
  ShieldCheck,
  Star,
  Zap,
  Bike,
  CircleDollarSign,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { homeFor } from '@/routes/RequireRole'
import { formatGdes, TARIFFS } from '@/services/pricing'

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.55 },
}

export default function Landing() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const go = (path: string) => navigate(user ? homeFor(user.role) : path)

  return (
    <div>
      {/* ---------------------------------------------------------------- */}
      {/* Héros                                                             */}
      {/* ---------------------------------------------------------------- */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -right-40 -top-40 h-[560px] w-[560px] rounded-full bg-violet-200/50 blur-3xl dark:bg-violet-900/30" />
        <div className="pointer-events-none absolute -left-40 top-1/2 h-[400px] w-[400px] rounded-full bg-purple-100/60 blur-3xl dark:bg-purple-900/20" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 pb-16 pt-14 sm:px-6 lg:grid-cols-2 lg:pb-24 lg:pt-20">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-7"
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-violet-50 px-4 py-1.5 text-xs font-semibold text-violet-700 dark:border-violet-500/20 dark:bg-violet-500/10 dark:text-violet-300">
              <Zap className="h-3.5 w-3.5" />
              Taxi et Moto en un clic
            </span>
            <h1 className="text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl lg:text-[3.4rem]">
              Déplacez-vous facilement partout{' '}
              <span className="bg-gradient-to-r from-violet-600 to-purple-500 bg-clip-text text-transparent">
                en Haïti
              </span>
            </h1>
            <p className="max-w-lg text-lg text-slate-500 dark:text-slate-400">
              Commandez un taxi ou une moto en quelques secondes et arrivez à destination en
              toute sécurité.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <Button
                size="lg"
                onClick={() => go('/inscription')}
                className="h-13 rounded-xl bg-violet-600 px-7 text-base font-semibold text-white shadow-xl shadow-violet-600/30 hover:bg-violet-700"
              >
                Commander maintenant
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => go('/inscription?role=chauffeur')}
                className="h-13 rounded-xl border-slate-300 px-7 text-base font-semibold dark:border-white/15"
              >
                Devenir chauffeur
              </Button>
            </div>
            <div className="grid max-w-md grid-cols-3 gap-4 pt-4">
              {[
                { icon: Zap, title: 'Rapide', text: 'Chauffeurs proches de vous' },
                { icon: ShieldCheck, title: 'Sécurisé', text: 'Vos trajets sont suivis en temps réel' },
                { icon: Clock, title: 'Disponible', text: '24/7 pour tous vos déplacements' },
              ].map((f) => (
                <div key={f.title} className="space-y-2">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-100 text-violet-600 dark:bg-violet-500/15 dark:text-violet-300">
                    <f.icon className="h-5 w-5" />
                  </span>
                  <p className="text-sm font-bold">{f.title}</p>
                  <p className="text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                    {f.text}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-[2rem] border border-violet-100 bg-gradient-to-br from-violet-50 via-purple-50 to-white p-8 shadow-2xl shadow-violet-200/50 dark:border-violet-500/10 dark:from-violet-950/40 dark:via-purple-950/30 dark:to-transparent dark:shadow-none">
              {/* Silhouette de skyline stylisée */}
              <svg
                className="absolute inset-x-0 top-6 h-40 w-full text-violet-200/70 dark:text-violet-800/30"
                viewBox="0 0 600 160"
                fill="currentColor"
                preserveAspectRatio="none"
              >
                <path d="M0 160V120h30v-25l15-15 15 15v25h40V90h25V60l20-20 20 20v30h25v30h50V80h20V45l18-18 18 18v35h20v40h55V95h30l12-25 12 25h28v25h40V70h22l10-20 10 20h20v50z" />
              </svg>
              <img
                src="/hero-taxi-moto.png"
                alt="Taxi et moto TaxiPa'w"
                className="relative z-10 mx-auto w-full max-w-lg drop-shadow-2xl"
                onError={(e) => {
                  ;(e.target as HTMLImageElement).style.display = 'none'
                }}
              />
              <div className="relative z-10 mt-4 flex items-center justify-between rounded-2xl border border-white/60 bg-white/80 px-5 py-3.5 backdrop-blur dark:border-white/10 dark:bg-white/5">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15">
                    <MapPin className="h-4.5 w-4.5" />
                  </span>
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Course vers</p>
                    <p className="text-sm font-bold">Pétion-Ville</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-500 dark:text-slate-400">dès</p>
                  <p className="text-sm font-extrabold text-violet-600 dark:text-violet-400">
                    120 Gdes
                  </p>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-5 -left-5 z-20 hidden items-center gap-3 rounded-2xl border border-slate-100 bg-white px-5 py-3.5 shadow-xl dark:border-white/10 dark:bg-[#1b1830] sm:flex">
              <div className="flex -space-x-2">
                {['MJ', 'JB', 'WL'].map((i, idx) => (
                  <span
                    key={i}
                    className={`flex h-8 w-8 items-center justify-center rounded-full border-2 border-white text-[10px] font-bold text-white dark:border-[#1b1830] ${
                      ['bg-violet-500', 'bg-emerald-500', 'bg-orange-500'][idx]
                    }`}
                  >
                    {i}
                  </span>
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1 text-xs font-bold">
                  4,9 <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">+2 000 courses/jour</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* Comment ça marche                                                 */}
      {/* ---------------------------------------------------------------- */}
      <section className="border-y border-slate-100 bg-slate-50/70 py-20 dark:border-white/5 dark:bg-white/[0.02]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <motion.div {...fadeUp} className="mx-auto mb-14 max-w-2xl text-center">
            <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
              Comment ça marche ?
            </h2>
            <p className="mt-3 text-slate-500 dark:text-slate-400">
              Trois étapes simples pour votre prochain trajet.
            </p>
          </motion.div>
          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                icon: MapPin,
                step: '01',
                title: 'Indiquez votre destination',
                text: 'Votre position est détectée automatiquement. Saisissez simplement où vous allez.',
              },
              {
                icon: CarFront,
                step: '02',
                title: 'Choisissez taxi ou moto',
                text: 'Comparez le prix estimé en gourdes avant de confirmer votre course.',
              },
              {
                icon: ShieldCheck,
                step: '03',
                title: 'Suivez votre chauffeur',
                text: 'Suivi en temps réel sur la carte, de la prise en charge à l’arrivée.',
              },
            ].map((s, i) => (
              <motion.div
                key={s.step}
                {...fadeUp}
                transition={{ duration: 0.55, delay: i * 0.12 }}
                className="group relative rounded-3xl border border-slate-100 bg-white p-8 transition-shadow hover:shadow-xl hover:shadow-violet-100 dark:border-white/5 dark:bg-white/[0.03] dark:hover:shadow-none"
              >
                <span className="absolute right-7 top-6 text-4xl font-black text-violet-100 transition-colors group-hover:text-violet-200 dark:text-violet-500/10">
                  {s.step}
                </span>
                <span className="flex h-13 w-13 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-purple-500 p-3.5 text-white shadow-lg shadow-violet-600/25">
                  <s.icon className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-lg font-bold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">
                  {s.text}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* Services & tarifs                                                 */}
      {/* ---------------------------------------------------------------- */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <motion.div {...fadeUp} className="mx-auto mb-14 max-w-2xl text-center">
            <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
              Taxi ou moto, à vous de choisir
            </h2>
            <p className="mt-3 text-slate-500 dark:text-slate-400">
              Des tarifs clairs en gourdes, sans surprise.
            </p>
          </motion.div>
          <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-2">
            {[
              {
                icon: CarFront,
                name: 'Taxi',
                desc: 'Berline confortable, jusqu’à 4 places',
                tariff: TARIFFS.taxi,
                accent: 'violet',
              },
              {
                icon: Bike,
                name: 'Moto',
                desc: 'Rapide dans le trafic, 1 passager',
                tariff: TARIFFS.moto,
                accent: 'emerald',
              },
            ].map((s, i) => (
              <motion.div
                key={s.name}
                {...fadeUp}
                transition={{ duration: 0.55, delay: i * 0.12 }}
                className="rounded-3xl border border-slate-100 bg-white p-8 dark:border-white/5 dark:bg-white/[0.03]"
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`flex h-13 w-13 items-center justify-center rounded-2xl p-3.5 text-white shadow-lg ${
                      s.accent === 'violet'
                        ? 'bg-gradient-to-br from-violet-600 to-purple-500 shadow-violet-600/25'
                        : 'bg-gradient-to-br from-emerald-500 to-teal-500 shadow-emerald-600/25'
                    }`}
                  >
                    <s.icon className="h-6 w-6" />
                  </span>
                  <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 dark:bg-white/10 dark:text-slate-300">
                    dès {formatGdes(s.tariff.minimum)}
                  </span>
                </div>
                <h3 className="mt-5 text-xl font-bold">{s.name}</h3>
                <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">{s.desc}</p>
                <div className="mt-5 grid grid-cols-3 gap-3 border-t border-slate-100 pt-5 text-center dark:border-white/5">
                  <div>
                    <p className="text-base font-extrabold">{formatGdes(s.tariff.base)}</p>
                    <p className="text-[11px] text-slate-400">Prise en charge</p>
                  </div>
                  <div>
                    <p className="text-base font-extrabold">{s.tariff.perKm} G</p>
                    <p className="text-[11px] text-slate-400">par km</p>
                  </div>
                  <div>
                    <p className="text-base font-extrabold">{s.tariff.perMin} G</p>
                    <p className="text-[11px] text-slate-400">par minute</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------------- */}
      {/* Bandeau chauffeur + CTA                                           */}
      {/* ---------------------------------------------------------------- */}
      <section className="px-4 pb-20 sm:px-6">
        <motion.div
          {...fadeUp}
          className="relative mx-auto max-w-7xl overflow-hidden rounded-[2rem] bg-gradient-to-br from-violet-700 via-violet-600 to-purple-600 px-8 py-14 text-white sm:px-14"
        >
          <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/10 blur-2xl" />
          <div className="grid items-center gap-10 md:grid-cols-2">
            <div>
              <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
                Gagnez de l’argent au volant
              </h2>
              <p className="mt-4 max-w-md text-violet-100">
                Rejoignez les chauffeurs TaxiPa’w : courses régulières, revenus suivis en temps
                réel et paiement de vos gains chaque semaine.
              </p>
              <Button
                size="lg"
                onClick={() => go('/inscription?role=chauffeur')}
                className="mt-7 h-13 rounded-xl bg-white px-7 text-base font-bold text-violet-700 hover:bg-violet-50"
              >
                Devenir chauffeur partenaire
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-4 text-center">
              {[
                { icon: CircleDollarSign, value: '85 %', label: 'reversés au chauffeur' },
                { icon: Clock, value: '24/7', label: 'demande continue' },
                { icon: ShieldCheck, value: '100 %', label: 'chauffeurs vérifiés' },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl bg-white/10 p-5 backdrop-blur">
                  <s.icon className="mx-auto h-6 w-6" />
                  <p className="mt-2 text-xl font-extrabold">{s.value}</p>
                  <p className="mt-1 text-[11px] leading-tight text-violet-100">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>
    </div>
  )
}
