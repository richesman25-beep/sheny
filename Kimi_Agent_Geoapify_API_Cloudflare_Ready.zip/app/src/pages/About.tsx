// Page À propos
import { motion } from 'framer-motion'
import { Bike, CarFront, HeartHandshake, MapPin, Target, Users } from 'lucide-react'

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.55 },
}

export default function About() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <motion.div {...fadeUp} className="mx-auto max-w-3xl text-center">
        <span className="rounded-full bg-violet-100 px-4 py-1.5 text-xs font-bold text-violet-700 dark:bg-violet-500/15 dark:text-violet-300">
          À propos de TaxiPa’w
        </span>
        <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-5xl">
          La mobilité haïtienne,{' '}
          <span className="bg-gradient-to-r from-violet-600 to-purple-500 bg-clip-text text-transparent">
            réinventée
          </span>
        </h1>
        <p className="mt-5 text-lg leading-relaxed text-slate-500 dark:text-slate-400">
          TaxiPa’w est née d’un constat simple : se déplacer à Port-au-Prince et dans les
          villes de province doit être aussi simple que d’envoyer un message. Nous connectons
          passagers et chauffeurs de taxi et de moto en quelques secondes, avec des prix
          transparents en gourdes.
        </p>
      </motion.div>

      <div className="mt-16 grid gap-6 md:grid-cols-3">
        {[
          {
            icon: Target,
            title: 'Notre mission',
            text: 'Rendre chaque trajet en Haïti plus sûr, plus rapide et plus juste — pour les passagers comme pour les chauffeurs.',
          },
          {
            icon: HeartHandshake,
            title: 'Nos valeurs',
            text: 'Transparence des prix, respect des chauffeurs partenaires et sécurité de chaque course, jour et nuit.',
          },
          {
            icon: Users,
            title: 'Notre équipe',
            text: 'Une équipe haïtienne, basée à Port-au-Prince, qui connaît le terrain et construit pour sa communauté.',
          },
        ].map((c, i) => (
          <motion.div
            key={c.title}
            {...fadeUp}
            transition={{ duration: 0.55, delay: i * 0.12 }}
            className="rounded-3xl border border-slate-100 bg-white p-8 dark:border-white/5 dark:bg-white/[0.03]"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-purple-500 text-white shadow-lg shadow-violet-600/25">
              <c.icon className="h-6 w-6" />
            </span>
            <h3 className="mt-5 text-lg font-bold">{c.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{c.text}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        {...fadeUp}
        className="mt-16 grid gap-6 rounded-[2rem] bg-slate-50 p-10 dark:bg-white/[0.03] sm:grid-cols-4"
      >
        {[
          { icon: MapPin, value: '3+', label: 'zones couvertes (PaP, Pétion-Ville, Delmas)' },
          { icon: CarFront, value: '100+', label: 'chauffeurs partenaires' },
          { icon: Bike, value: '2 000+', label: 'courses par jour' },
          { icon: Users, value: '5 000+', label: 'utilisateurs inscrits' },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <s.icon className="mx-auto h-6 w-6 text-violet-600" />
            <p className="mt-2 text-3xl font-extrabold">{s.value}</p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{s.label}</p>
          </div>
        ))}
      </motion.div>
    </div>
  )
}
