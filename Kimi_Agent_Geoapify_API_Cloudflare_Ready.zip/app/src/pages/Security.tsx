// Page Sécurité
import { motion } from 'framer-motion'
import {
  BadgeCheck,
  FileCheck,
  MapPin,
  PhoneCall,
  Share2,
  ShieldCheck,
  Star,
  UserCheck,
} from 'lucide-react'

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.55 },
}

const ITEMS = [
  {
    icon: FileCheck,
    title: 'Chauffeurs vérifiés',
    text: 'Chaque chauffeur fournit sa CIN, son permis (pour les voitures) et les informations complètes de son véhicule. Rien n’est activé sans validation par notre équipe.',
  },
  {
    icon: MapPin,
    title: 'Suivi en temps réel',
    text: 'Votre course est suivie sur la carte du début à la fin : position du chauffeur, itinéraire et heure d’arrivée estimée.',
  },
  {
    icon: Share2,
    title: 'Partage de course',
    text: 'Partagez le lien de suivi de votre course avec un proche pour qu’il sache où vous êtes à tout moment.',
  },
  {
    icon: BadgeCheck,
    title: 'Véhicule identifié',
    text: 'Avant de monter, vérifiez la marque, le modèle, la couleur et la plaque affichés dans l’application.',
  },
  {
    icon: Star,
    title: 'Notation après chaque course',
    text: 'Notez votre chauffeur : les comptes mal notés sont revus et peuvent être suspendus.',
  },
  {
    icon: PhoneCall,
    title: 'Support réactif',
    text: 'Notre équipe basée à Port-au-Prince répond 7 jours sur 7 pour toute question ou incident.',
  },
]

export default function Security() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-24">
      <motion.div {...fadeUp} className="mx-auto max-w-3xl text-center">
        <span className="flex mx-auto w-fit items-center gap-2 rounded-full bg-emerald-100 px-4 py-1.5 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
          <ShieldCheck className="h-3.5 w-3.5" /> Votre sécurité d’abord
        </span>
        <h1 className="mt-5 text-4xl font-extrabold tracking-tight sm:text-5xl">
          Voyagez l’esprit tranquille
        </h1>
        <p className="mt-5 text-lg leading-relaxed text-slate-500 dark:text-slate-400">
          Chaque détail de TaxiPa’w est pensé pour que vous vous déplaciez en confiance, de la
          vérification des chauffeurs au suivi temps réel de vos trajets.
        </p>
      </motion.div>

      <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {ITEMS.map((c, i) => (
          <motion.div
            key={c.title}
            {...fadeUp}
            transition={{ duration: 0.55, delay: (i % 3) * 0.12 }}
            className="rounded-3xl border border-slate-100 bg-white p-8 transition-shadow hover:shadow-xl hover:shadow-violet-100 dark:border-white/5 dark:bg-white/[0.03] dark:hover:shadow-none"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300">
              <c.icon className="h-6 w-6" />
            </span>
            <h3 className="mt-5 text-lg font-bold">{c.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{c.text}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        {...fadeUp}
        className="mt-16 flex flex-col items-center gap-4 rounded-[2rem] bg-gradient-to-br from-violet-700 to-purple-600 p-10 text-center text-white"
      >
        <UserCheck className="h-10 w-10" />
        <h2 className="text-2xl font-extrabold">Un incident pendant une course ?</h2>
        <p className="max-w-xl text-violet-100">
          Contactez immédiatement notre support au +509 34 00 0000 ou par email à
          support@taxipaw.ht — chaque signalement est traité en priorité.
        </p>
      </motion.div>
    </div>
  )
}
