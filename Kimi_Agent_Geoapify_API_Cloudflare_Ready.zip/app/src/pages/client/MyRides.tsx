// Historique des courses du client
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { MapPin, Navigation, Plus, Star } from 'lucide-react'
import { PageHeader, StatusBadge, EmptyState, formatDateTime } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { ridesForUser } from '@/services/demo'
import { formatGdes } from '@/services/pricing'
import { cn } from '@/lib/utils'

const FILTERS = [
  { value: 'all', label: 'Toutes' },
  { value: 'active', label: 'En cours' },
  { value: 'completed', label: 'Terminées' },
  { value: 'cancelled', label: 'Annulées' },
] as const

export default function MyRides() {
  const { user } = useAuth()
  useStore()
  const navigate = useNavigate()
  const [filter, setFilter] = useState<(typeof FILTERS)[number]['value']>('all')

  const rides = ridesForUser(user?.id ?? '')
  const filtered = rides.filter((r) => {
    if (filter === 'all') return true
    if (filter === 'active') return !['completed', 'cancelled'].includes(r.status)
    return r.status === filter
  })

  return (
    <div className="p-4 sm:p-6">
      <PageHeader
        title="Mes courses"
        subtitle={`${rides.length} course${rides.length > 1 ? 's' : ''} au total`}
        action={
          <Button
            onClick={() => navigate('/app')}
            className="rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
          >
            <Plus className="mr-2 h-4 w-4" /> Nouvelle course
          </Button>
        }
      />

      <div className="mb-5 flex gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={cn(
              'rounded-full px-4 py-2 text-sm font-semibold transition-colors',
              filter === f.value
                ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/25'
                : 'bg-white text-slate-500 hover:bg-slate-100',
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={MapPin}
          title="Aucune course"
          text="Vos courses passées et en cours apparaîtront ici."
          action={
            <Button
              onClick={() => navigate('/app')}
              className="rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              Commander maintenant
            </Button>
          }
        />
      ) : (
        <div className="grid gap-3">
          {filtered.map((r) => {
            const active = !['completed', 'cancelled'].includes(r.status)
            return (
              <button
                key={r.id}
                onClick={() => active && navigate(`/app/course/${r.id}`)}
                className={cn(
                  'flex items-center gap-4 rounded-2xl border border-slate-100 bg-white p-4 text-left transition-shadow hover:shadow-md',
                  active && 'border-violet-200 bg-violet-50/40',
                )}
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-100 text-violet-600">
                  <Navigation className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold">
                    {r.pickup.address.split(',')[0]} → {r.dropoff.address.split(',')[0]}
                  </p>
                  <p className="mt-0.5 flex flex-wrap items-center gap-x-3 text-xs text-slate-500">
                    <span>{formatDateTime(r.createdAt)}</span>
                    <span>{r.vehicleType === 'taxi' ? 'Taxi' : 'Moto'}</span>
                    <span>{r.distanceKm.toFixed(1)} km</span>
                    {r.rating && (
                      <span className="flex items-center gap-0.5 text-amber-500">
                        <Star className="h-3 w-3 fill-amber-400" /> {r.rating}
                      </span>
                    )}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-extrabold text-slate-800">{formatGdes(r.price)}</p>
                  <StatusBadge status={r.status} />
                </div>
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
