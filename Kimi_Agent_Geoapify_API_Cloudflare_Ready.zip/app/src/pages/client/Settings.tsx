import { PageHeader } from '@/components/ui-kit'
import { SettingsPanel } from '@/components/SettingsPanel'

export default function Settings() {
  return (
    <div className="p-4 sm:p-6">
      <PageHeader title="Paramètres" subtitle="Personnalisez votre expérience TaxiPa’w" />
      <SettingsPanel />
    </div>
  )
}
