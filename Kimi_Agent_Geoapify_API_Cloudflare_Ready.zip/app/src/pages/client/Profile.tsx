// Profil client
import { useState } from 'react'
import type { FormEvent } from 'react'
import { Mail, Phone, Save, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import { PageHeader, Card } from '@/components/ui-kit'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { ridesForUser, updateUser } from '@/services/demo'
import { formatGdes } from '@/services/pricing'

export default function Profile() {
  const { user, refresh } = useAuth()
  useStore()
  const [fullname, setFullname] = useState(user?.fullname ?? '')
  const [phone, setPhone] = useState(user?.phone ?? '')

  if (!user) return null
  const rides = ridesForUser(user.id).filter((r) => r.status === 'completed')
  const spent = rides.reduce((s, r) => s + r.price, 0)

  const save = (e: FormEvent) => {
    e.preventDefault()
    updateUser(user.id, { fullname: fullname.trim(), phone: phone.trim() })
    refresh()
    toast.success('Profil mis à jour !')
  }

  return (
    <div className="p-4 sm:p-6">
      <PageHeader title="Profil" subtitle="Vos informations personnelles" />
      <div className="grid max-w-3xl gap-5">
        <Card>
          <div className="flex flex-wrap items-center gap-5">
            <Avatar name={user.fullname} size="lg" className="h-20 w-20 text-2xl" />
            <div className="min-w-0 flex-1">
              <p className="text-xl font-extrabold">{user.fullname}</p>
              <p className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Mail className="h-4 w-4" /> {user.email}
                </span>
                <span className="flex items-center gap-1.5">
                  <Phone className="h-4 w-4" /> {user.phone}
                </span>
              </p>
            </div>
            <span className="flex items-center gap-1.5 rounded-full bg-violet-100 px-3.5 py-1.5 text-xs font-bold text-violet-700">
              <ShieldCheck className="h-4 w-4" /> Client vérifié
            </span>
          </div>
          <div className="mt-5 grid grid-cols-3 gap-3 border-t border-slate-100 pt-5 text-center">
            <div>
              <p className="text-xl font-extrabold">{rides.length}</p>
              <p className="text-xs text-slate-400">Courses</p>
            </div>
            <div>
              <p className="text-xl font-extrabold">{formatGdes(spent)}</p>
              <p className="text-xs text-slate-400">Dépensés</p>
            </div>
            <div>
              <p className="text-xl font-extrabold">
                {new Date(user.createdAt).toLocaleDateString('fr-FR', { month: 'short', year: 'numeric' })}
              </p>
              <p className="text-xs text-slate-400">Membre depuis</p>
            </div>
          </div>
        </Card>

        <Card>
          <h3 className="mb-4 font-extrabold">Modifier mes informations</h3>
          <form onSubmit={save} className="grid gap-4">
            <div className="space-y-2">
              <Label>Nom complet</Label>
              <Input
                value={fullname}
                onChange={(e) => setFullname(e.target.value)}
                required
                className="h-12 rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label>Téléphone</Label>
              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="h-12 rounded-xl"
              />
            </div>
            <Button
              type="submit"
              className="h-12 rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              <Save className="mr-2 h-4.5 w-4.5" /> Enregistrer
            </Button>
          </form>
        </Card>
      </div>
    </div>
  )
}
