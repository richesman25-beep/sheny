// Messages client (support + dernier chauffeur)
import { PageHeader } from '@/components/ui-kit'
import { ChatDemo } from '@/components/ChatDemo'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { ridesForUser } from '@/services/demo'

export default function Messages() {
  const { user } = useAuth()
  const db = useStore()
  const lastRide = ridesForUser(user?.id ?? '')[0]
  const driverName = lastRide?.driverId
    ? db.users.find((u) => u.id === lastRide.driverId)?.fullname
    : undefined

  return (
    <div className="p-4 sm:p-6">
      <PageHeader title="Messages" subtitle="Échangez avec votre chauffeur ou le support" />
      <div className="max-w-2xl">
        <ChatDemo
          contactName={driverName ?? 'Support TaxiPa’w'}
          contactRole={driverName ? 'Votre chauffeur' : 'Assistance'}
        />
      </div>
    </div>
  )
}
