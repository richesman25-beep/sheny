// Accueil client : carte + recherche de destination + estimation + commande
import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowUpDown, Bike, CarFront, Crosshair, Loader2 } from 'lucide-react'
import { Map } from '@/components/Map'
import type { MapMarker } from '@/components/Map'
import { AddressAutocomplete } from '@/components/AddressAutocomplete'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { DEFAULT_CENTER, ipInfo, planRoute } from '@/lib/geoapify'
import { estimatePrice, formatGdes, formatKm, formatMin } from '@/services/pricing'
import { nearbyDrivers, requestRide } from '@/services/demo'
import type { GeoPoint, PlaceResult, RouteResult, VehicleType } from '@/types'
import { cn } from '@/lib/utils'

export default function ClientHome() {
  const { user } = useAuth()
  const navigate = useNavigate()
  useStore() // réactivité sur les chauffeurs en ligne

  const [pickup, setPickup] = useState<GeoPoint>({
    address: 'Port-au-Prince, Haïti',
    lat: DEFAULT_CENTER[0],
    lng: DEFAULT_CENTER[1],
  })
  const [locating, setLocating] = useState(true)
  const [destText, setDestText] = useState('')
  const [dest, setDest] = useState<PlaceResult | null>(null)
  const [service, setService] = useState<VehicleType>('taxi')
  const [route, setRoute] = useState<RouteResult | null>(null)
  const [routeLoading, setRouteLoading] = useState(false)
  const [ordering, setOrdering] = useState(false)
  const routeKeyRef = useRef('')

  // Détection de la position : navigateur → IP → Port-au-Prince
  // La position détectée n'est retenue que si elle se situe en Haïti
  // (zone de service TaxiPa'w) ; sinon, repli sur Port-au-Prince.
  const locate = () => {
    setLocating(true)
    const inHaiti = (lat: number, lng: number) =>
      lat >= 17.7 && lat <= 20.3 && lng >= -74.7 && lng <= -71.5
    const useDefault = () => {
      setPickup({ address: 'Port-au-Prince, Haïti', lat: DEFAULT_CENTER[0], lng: DEFAULT_CENTER[1] })
      setLocating(false)
    }
    const fallback = async () => {
      const ip = await ipInfo()
      if (ip && inHaiti(ip.lat, ip.lng)) {
        setPickup({ address: 'Ma position actuelle', lat: ip.lat, lng: ip.lng })
        setLocating(false)
      } else {
        useDefault()
      }
    }
    if (!navigator.geolocation) {
      void fallback()
      return
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords
        if (inHaiti(latitude, longitude)) {
          setPickup({ address: 'Ma position actuelle', lat: latitude, lng: longitude })
          setLocating(false)
        } else {
          void fallback()
        }
      },
      () => void fallback(),
      { timeout: 6000 },
    )
  }

  useEffect(() => {
    locate()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Calcul de l'itinéraire quand la destination change
  useEffect(() => {
    if (!dest) {
      setRoute(null)
      return
    }
    const key = `${pickup.lat},${pickup.lng}|${dest.lat},${dest.lng}`
    if (routeKeyRef.current === key) return
    routeKeyRef.current = key
    setRouteLoading(true)
    void planRoute(pickup, dest).then((r) => {
      setRoute(r)
      setRouteLoading(false)
    })
  }, [dest, pickup])

  const price = useMemo(
    () => (route ? estimatePrice(service, route.distanceKm, route.durationMin) : null),
    [route, service],
  )

  const drivers = nearbyDrivers(pickup).slice(0, 8)

  const markers: MapMarker[] = useMemo(() => {
    const list: MapMarker[] = [
      { id: 'me', lat: pickup.lat, lng: pickup.lng, kind: 'me', label: 'Vous êtes ici' },
    ]
    for (const d of drivers) {
      const hash = d.userId.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
      list.push({
        id: d.userId,
        lat: d.latitude,
        lng: d.longitude,
        kind: d.vehicleType === 'taxi' ? 'car' : 'moto',
        rotation: hash % 360,
        label: `${d.brand} ${d.model}`,
      })
    }
    if (dest) list.push({ id: 'dest', lat: dest.lat, lng: dest.lng, kind: 'dropoff', label: 'Destination' })
    return list
  }, [pickup, drivers, dest])

  const order = () => {
    if (!user || !dest || !route || price === null) return
    setOrdering(true)
    const ride = requestRide({
      clientId: user.id,
      vehicleType: service,
      pickup,
      dropoff: { address: dest.address, lat: dest.lat, lng: dest.lng },
      distanceKm: Math.round(route.distanceKm * 10) / 10,
      durationMin: Math.round(route.durationMin),
      price,
    })
    setTimeout(() => navigate(`/app/course/${ride.id}`), 500)
  }

  return (
    <div className="relative h-[calc(100dvh-68px)] lg:h-[calc(100dvh-65px)]">
      <Map
        center={[pickup.lat, pickup.lng]}
        zoom={14}
        markers={markers}
        polyline={route?.geometry}
        fitToContent={!!route}
      />

      {/* Carte de commande flottante */}
      <div className="absolute left-3 top-3 z-[500] w-[calc(100%-24px)] max-w-[380px] rounded-3xl border border-slate-100 bg-white/95 p-5 shadow-2xl backdrop-blur sm:left-5 sm:top-5">
        <h2 className="text-lg font-extrabold tracking-tight">Où allez-vous ?</h2>

        <div className="mt-4 space-y-3.5">
          <div className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-emerald-500" />
            <div className="min-w-0 flex-1">
              <p className="text-xs text-slate-400">Point de départ</p>
              <p className="flex items-center gap-1.5 truncate text-sm font-semibold">
                {locating ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin text-violet-500" />
                    Localisation…
                  </>
                ) : (
                  pickup.address
                )}
              </p>
            </div>
            <button
              onClick={locate}
              title="Recentrer sur ma position"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-violet-50 hover:text-violet-600"
            >
              <Crosshair className="h-4 w-4" />
            </button>
          </div>

          <div className="flex items-center gap-2.5 border-t border-slate-100 pt-3.5">
            <div className="min-w-0 flex-1">
              <AddressAutocomplete
                placeholder="Saisissez votre destination"
                value={destText}
                onChange={(t) => {
                  setDestText(t)
                  setDest(null)
                }}
                onSelect={(p) => {
                  setDest(p)
                  setDestText(p.address)
                }}
                near={pickup}
                dotColor="#f43f5e"
              />
            </div>
            <ArrowUpDown className="h-4 w-4 shrink-0 text-slate-300" />
          </div>
        </div>

        <p className="mb-2.5 mt-5 text-sm font-bold">Choisissez un service</p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { value: 'taxi' as VehicleType, icon: CarFront, title: 'Taxi', sub: '4 places' },
            { value: 'moto' as VehicleType, icon: Bike, title: 'Moto', sub: '1 passager' },
          ].map((s) => (
            <button
              key={s.value}
              onClick={() => setService(s.value)}
              className={cn(
                'relative flex items-center gap-3 rounded-2xl border-2 p-3.5 text-left transition-all',
                service === s.value
                  ? 'border-violet-500 bg-violet-50'
                  : 'border-slate-100 hover:border-slate-200',
              )}
            >
              <span
                className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-xl transition-colors',
                  service === s.value ? 'bg-violet-600 text-white' : 'bg-slate-100 text-slate-500',
                )}
              >
                <s.icon className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-sm font-bold">{s.title}</span>
                <span className="block text-[11px] text-slate-400">{s.sub}</span>
              </span>
              {service === s.value && (
                <span className="absolute right-2.5 top-2.5 h-2.5 w-2.5 rounded-full bg-violet-600" />
              )}
            </button>
          ))}
        </div>

        {dest && (
          <div className="mt-5 border-t border-slate-100 pt-4">
            <p className="text-xs font-medium text-slate-400">Estimation du prix</p>
            {routeLoading ? (
              <p className="mt-1 flex items-center gap-2 text-sm text-slate-400">
                <Loader2 className="h-4 w-4 animate-spin text-violet-500" /> Calcul de l’itinéraire…
              </p>
            ) : route && price !== null ? (
              <>
                <p className="text-2xl font-extrabold tracking-tight text-slate-900">
                  {formatGdes(price)}
                </p>
                <p className="mt-0.5 text-xs text-slate-400">
                  {formatKm(route.distanceKm)} • {formatMin(route.durationMin)}
                </p>
              </>
            ) : (
              <p className="mt-1 text-sm text-slate-400">Itinéraire indisponible pour cette destination.</p>
            )}
          </div>
        )}

        <Button
          onClick={order}
          disabled={!dest || !route || routeLoading || ordering || !user}
          className="mt-5 h-12 w-full rounded-xl bg-violet-600 text-base font-semibold text-white shadow-lg shadow-violet-600/25 hover:bg-violet-700"
        >
          {ordering ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Recherche d’un chauffeur…
            </>
          ) : (
            'Commander maintenant'
          )}
        </Button>
      </div>

      {/* Légende chauffeurs proches */}
      <div className="absolute bottom-5 left-3 z-[500] hidden rounded-2xl border border-slate-100 bg-white/95 px-4 py-3 shadow-lg backdrop-blur sm:left-5 sm:block">
        <p className="flex items-center gap-2 text-xs font-semibold text-slate-600">
          <span className="h-2 w-2 rounded-full bg-emerald-500" />
          {drivers.length} chauffeur{drivers.length > 1 ? 's' : ''} à proximité
        </p>
      </div>
    </div>
  )
}
