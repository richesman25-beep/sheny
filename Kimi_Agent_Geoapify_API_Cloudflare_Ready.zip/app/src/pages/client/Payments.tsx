// Paiements du client : espèces (MVP) + méthodes à venir + historique
import { Banknote, CreditCard, Smartphone, Wallet } from 'lucide-react'
import { PageHeader, formatDateTime } from '@/components/ui-kit'
import { useAuth } from '@/contexts/AuthContext'
import { useStore } from '@/hooks/useStore'
import { ridesForUser } from '@/services/demo'
import { formatGdes } from '@/services/pricing'
import { cn } from '@/lib/utils'

const METHODS = [
  {
    icon: Banknote,
    name: 'Espèces',
    desc: 'Payez le chauffeur en gourdes à l’arrivée',
    active: true,
  },
  { icon: Smartphone, name: 'MonCash', desc: 'Paiement mobile Digicel', active: false },
  { icon: Smartphone, name: 'NatCash', desc: 'Paiement mobile Natcom', active: false },
  { icon: CreditCard, name: 'Carte bancaire', desc: 'Visa / Mastercard', active: false },
]

export default function Payments() {
  const { user } = useAuth()
  useStore()
  const rides = ridesForUser(user?.id ?? '').filter((r) => r.status === 'completed')
  const total = rides.reduce((s, r) => s + r.price, 0)

  return (
    <div className="space-y-6 p-4 sm:p-6">
      <PageHeader title="Paiements" subtitle="Vos méthodes de paiement et votre historique" />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {METHODS.map((m) => (
          <div
            key={m.name}
            className={cn(
              'rounded-2xl border p-5',
              m.active
                ? 'border-violet-500 bg-violet-50/50 shadow-lg shadow-violet-100'
                : 'border-slate-100 bg-white opacity-80',
            )}
          >
            <div className="flex items-center justify-between">
              <span
                className={cn(
                  'flex h-11 w-11 items-center justify-center rounded-xl',
                  m.active ? 'bg-violet-600 text-white' : 'bg-slate-100 text-slate-400',
                )}
              >
                <m.icon className="h-5.5 w-5.5" />
              </span>
              {m.active ? (
                <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold text-emerald-700">
                  Par défaut
                </span>
              ) : (
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-500">
                  Bientôt
                </span>
              )}
            </div>
            <p className="mt-3 font-bold">{m.name}</p>
            <p className="mt-0.5 text-xs text-slate-500">{m.desc}</p>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-slate-100 bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-extrabold">Historique des paiements</h3>
          <span className="flex items-center gap-2 rounded-xl bg-violet-50 px-4 py-2 text-sm font-bold text-violet-700">
            <Wallet className="h-4 w-4" /> Total : {formatGdes(total)}
          </span>
        </div>
        {rides.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-400">Aucun paiement pour le moment.</p>
        ) : (
          <div className="divide-y divide-slate-50">
            {rides.slice(0, 10).map((r) => (
              <div key={r.id} className="flex items-center justify-between py-3 text-sm">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600">
                    <Banknote className="h-4.5 w-4.5" />
                  </span>
                  <div>
                    <p className="font-semibold">
                      {r.pickup.address.split(',')[0]} → {r.dropoff.address.split(',')[0]}
                    </p>
                    <p className="text-xs text-slate-400">{formatDateTime(r.createdAt)} • Espèces</p>
                  </div>
                </div>
                <p className="font-extrabold">{formatGdes(r.price)}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
