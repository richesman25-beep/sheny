// Adresses favorites du client
import { useEffect, useState } from 'react'
import { Heart, MapPin, Trash2 } from 'lucide-react'
import { PageHeader, EmptyState } from '@/components/ui-kit'
import { AddressAutocomplete } from '@/components/AddressAutocomplete'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import type { GeoPoint } from '@/types'

const key = (uid: string) => `taxipaw_favorites_${uid}`

export default function Favorites() {
  const { user } = useAuth()
  const [favorites, setFavorites] = useState<GeoPoint[]>([])
  const [text, setText] = useState('')

  useEffect(() => {
    if (!user) return
    try {
      setFavorites(JSON.parse(localStorage.getItem(key(user.id)) ?? '[]') as GeoPoint[])
    } catch {
      setFavorites([])
    }
  }, [user])

  const save = (list: GeoPoint[]) => {
    setFavorites(list)
    if (user) localStorage.setItem(key(user.id), JSON.stringify(list))
  }

  const add = (place: GeoPoint) => {
    if (favorites.some((f) => f.address === place.address)) return
    save([place, ...favorites])
    setText('')
  }

  return (
    <div className="p-4 sm:p-6">
      <PageHeader title="Favoris" subtitle="Vos adresses enregistrées pour commander plus vite" />

      <div className="mb-6 max-w-xl rounded-2xl border border-slate-100 bg-white p-4">
        <p className="mb-2 text-sm font-bold">Ajouter une adresse</p>
        <AddressAutocomplete
          placeholder="Ex : Place Saint-Pierre, Pétion-Ville"
          value={text}
          onChange={setText}
          onSelect={add}
        />
      </div>

      {favorites.length === 0 ? (
        <EmptyState
          icon={Heart}
          title="Aucun favori"
          text="Enregistrez vos adresses fréquentes (maison, travail, église…) pour les retrouver en un geste."
        />
      ) : (
        <div className="grid max-w-xl gap-3">
          {favorites.map((f) => (
            <div
              key={f.address}
              className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-white p-4"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-100 text-rose-500">
                <MapPin className="h-5 w-5" />
              </span>
              <p className="min-w-0 flex-1 truncate text-sm font-semibold">{f.address}</p>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => save(favorites.filter((x) => x.address !== f.address))}
                className="h-9 w-9 rounded-xl p-0 text-slate-400 hover:bg-rose-50 hover:text-rose-500"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
