// Suivi de course en temps réel (client)
import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import {
  ArrowLeft,
  MessageSquare,
  Navigation,
  Phone,
  Share2,
  Star,
  XCircle,
} from 'lucide-react'
import { toast } from 'sonner'
import { Map } from '@/components/Map'
import type { MapMarker } from '@/components/Map'
import { Avatar } from '@/components/Avatar'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useStore } from '@/hooks/useStore'
import { planRoute } from '@/lib/geoapify'
import { cancelRide, rateRide } from '@/services/demo'
import { formatGdes } from '@/services/pricing'
import type { RideStatus } from '@/types'
import { cn } from '@/lib/utils'

const HEADLINES: Record<RideStatus, string> = {
  pending: 'Recherche d’un chauffeur…',
  driver_found: 'Chauffeur trouvé !',
  driver_en_route: 'Votre chauffeur est en route',
  driver_arrived: 'Votre chauffeur est arrivé',
  started: 'Course en cours',
  completed: 'Course terminée',
  cancelled: 'Course annulée',
}

const PROGRESS: Record<RideStatus, number> = {
  pending: 8,
  driver_found: 25,
  driver_en_route: 50,
  driver_arrived: 68,
  started: 85,
  completed: 100,
  cancelled: 100,
}

export default function RideTracking() {
  const { rideId } = useParams<{ rideId: string }>()
  const navigate = useNavigate()
  const db = useStore()
  const ride = db.rides.find((r) => r.id === rideId)
  const driverUser = ride?.driverId ? db.users.find((u) => u.id === ride.driverId) : undefined
  const driverInfo = ride?.driverId ? db.drivers.find((d) => d.userId === ride.driverId) : undefined

  const [geometry, setGeometry] = useState<[number, number][]>([])
  const [ratingOpen, setRatingOpen] = useState(false)
  const [rating, setRating] = useState(5)
  const [rated, setRated] = useState(false)

  // Tracé de l'itinéraire de la course
  useEffect(() => {
    if (!ride) return
    let cancelled = false
    void planRoute(ride.pickup, ride.dropoff).then((r) => {
      if (!cancelled && r) setGeometry(r.geometry)
    })
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rideId])

  // Ouverture de la notation à la fin de la course
  useEffect(() => {
    if (ride?.status === 'completed' && !rated && ride.rating === undefined) {
      setRatingOpen(true)
    }
  }, [ride?.status, rated, ride?.rating])

  const markers: MapMarker[] = useMemo(() => {
    if (!ride) return []
    const list: MapMarker[] = [
      { id: 'pickup', lat: ride.pickup.lat, lng: ride.pickup.lng, kind: 'pickup', label: 'Départ' },
      { id: 'dropoff', lat: ride.dropoff.lat, lng: ride.dropoff.lng, kind: 'dropoff', label: 'Destination' },
    ]
    const dLat = ride.driverLat ?? driverInfo?.latitude
    const dLng = ride.driverLng ?? driverInfo?.longitude
    if (ride.driverId && dLat !== undefined && dLng !== undefined) {
      list.push({
        id: 'driver',
        lat: dLat,
        lng: dLng,
        kind: ride.vehicleType === 'taxi' ? 'car' : 'moto',
        label: driverUser?.fullname ?? 'Chauffeur',
      })
    }
    return list
  }, [ride, driverInfo, driverUser])

  if (!ride) {
    return (
      <div className="flex h-[calc(100dvh-68px)] flex-col items-center justify-center gap-4">
        <p className="text-slate-500">Course introuvable.</p>
        <Button onClick={() => navigate('/app')} className="rounded-xl bg-violet-600 text-white">
          Retour à l’accueil
        </Button>
      </div>
    )
  }

  const eta = ride.etaMin ?? Math.max(1, Math.round(ride.durationMin / 3))
  const showEta = ['driver_en_route', 'started'].includes(ride.status)

  const share = async () => {
    const url = `${window.location.origin}/app/course/${ride.id}`
    try {
      await navigator.clipboard.writeText(url)
      toast.success('Lien de suivi copié !')
    } catch {
      toast.info(url)
    }
  }

  return (
    <div className="flex h-[calc(100dvh-68px)] flex-col lg:h-[calc(100dvh-65px)] lg:flex-row">
      {/* Panneau latéral */}
      <div className="order-2 flex max-h-[55%] w-full flex-col gap-4 overflow-auto border-t border-slate-100 bg-white p-5 lg:order-1 lg:max-h-none lg:w-[390px] lg:border-r lg:border-t-0">
        <div className="flex items-center gap-3">
          <Link
            to="/app"
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50"
          >
            <ArrowLeft className="h-4.5 w-4.5" />
          </Link>
          <h1 className="text-base font-extrabold tracking-tight">Course en cours</h1>
          <span className="ml-auto rounded-full bg-violet-50 px-3 py-1 text-xs font-bold text-violet-700">
            #{ride.id}
          </span>
        </div>

        {ride.status === 'cancelled' ? (
          <div className="rounded-2xl bg-rose-50 p-5 text-center">
            <XCircle className="mx-auto h-8 w-8 text-rose-500" />
            <p className="mt-2 font-bold text-rose-700">Course annulée</p>
            <p className="mt-1 text-xs text-rose-500">Aucun montant ne vous sera demandé.</p>
            <Button
              onClick={() => navigate('/app')}
              className="mt-4 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
            >
              Commander une nouvelle course
            </Button>
          </div>
        ) : (
          <>
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">{HEADLINES[ride.status]}</h2>
              {showEta && (
                <p className="mt-1 text-sm text-slate-500">
                  {ride.status === 'started' ? 'Arrivée à destination dans' : 'Arrivée dans'}{' '}
                  <span className="text-lg font-extrabold text-slate-900">{eta} min</span>
                </p>
              )}
              <Progress
                value={PROGRESS[ride.status]}
                className="mt-3 h-2 bg-slate-100 [&>div]:bg-violet-600"
              />
            </div>

            {/* Carte chauffeur */}
            {driverUser && driverInfo ? (
              <div className="rounded-2xl border border-slate-100 p-4">
                <div className="flex items-center gap-3">
                  <Avatar name={driverUser.fullname} size="lg" />
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1.5 font-bold">
                      {driverUser.fullname}
                      <span className="flex items-center gap-0.5 text-xs font-semibold text-amber-500">
                        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                        {driverInfo.rating.toFixed(1)}
                      </span>
                    </p>
                    <p className="truncate text-xs text-slate-500">
                      {driverInfo.brand} {driverInfo.model} — {driverInfo.color}
                    </p>
                    <p className="text-xs font-bold tracking-wide text-slate-700">
                      {driverInfo.plate}
                    </p>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2.5">
                  <a href={`tel:${driverUser.phone.replace(/\s/g, '')}`}>
                    <Button variant="outline" className="h-10 w-full rounded-xl text-sm font-semibold">
                      <Phone className="mr-2 h-4 w-4 text-violet-600" /> Appeler
                    </Button>
                  </a>
                  <Button
                    variant="outline"
                    onClick={() => navigate('/app/messages')}
                    className="h-10 w-full rounded-xl text-sm font-semibold"
                  >
                    <MessageSquare className="mr-2 h-4 w-4 text-violet-600" /> Message
                  </Button>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-200 p-5 text-center">
                <div className="mx-auto h-8 w-8 animate-ping rounded-full bg-violet-200" />
                <p className="mt-3 text-sm font-semibold text-slate-600">
                  Recherche d’un chauffeur à proximité…
                </p>
              </div>
            )}

            {['pending', 'driver_found', 'driver_en_route', 'driver_arrived'].includes(
              ride.status,
            ) && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="h-11 rounded-xl border-rose-200 text-sm font-semibold text-rose-600 hover:bg-rose-50 hover:text-rose-700"
                  >
                    Annuler la course
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="rounded-2xl">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Annuler cette course ?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Le chauffeur sera immédiatement notifié. Cette action est définitive.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="rounded-xl">Garder ma course</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => cancelRide(ride.id)}
                      className="rounded-xl bg-rose-600 text-white hover:bg-rose-700"
                    >
                      Oui, annuler
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}

            {ride.status === 'completed' && (
              <Button
                onClick={() => navigate('/app')}
                className="h-11 rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
              >
                Commander une nouvelle course
              </Button>
            )}
          </>
        )}

        {/* Infos course */}
        <div className="mt-auto grid gap-3">
          <div className="flex items-center gap-3 rounded-2xl border border-slate-100 p-4">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-violet-100 text-violet-600">
              <Navigation className="h-4.5 w-4.5" />
            </span>
            <div className="min-w-0">
              <p className="text-xs text-slate-400">Destination</p>
              <p className="truncate text-sm font-bold">{ride.dropoff.address}</p>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-2xl border border-slate-100 p-4">
            <div>
              <p className="text-xs text-slate-400">Prix de la course</p>
              <p className="text-sm font-bold">Espèces à l’arrivée</p>
            </div>
            <p className="text-lg font-extrabold text-violet-600">{formatGdes(ride.price)}</p>
          </div>
        </div>
      </div>

      {/* Carte */}
      <div className="relative order-1 flex-1 lg:order-2">
        <Map
          center={[ride.pickup.lat, ride.pickup.lng]}
          markers={markers}
          polyline={geometry.length >= 2 ? geometry : [[ride.pickup.lat, ride.pickup.lng], [ride.dropoff.lat, ride.dropoff.lng]]}
          fitToContent
        />
        <button
          onClick={share}
          className="absolute right-4 top-4 z-[500] flex items-center gap-2 rounded-xl border border-slate-100 bg-white/95 px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-lg backdrop-blur transition-colors hover:text-violet-700"
        >
          <Share2 className="h-4 w-4" /> Partager ma course
        </button>
      </div>

      {/* Notation */}
      <Dialog open={ratingOpen} onOpenChange={setRatingOpen}>
        <DialogContent className="rounded-2xl text-center">
          <DialogHeader>
            <DialogTitle className="text-center">Notez votre chauffeur</DialogTitle>
            <DialogDescription className="text-center">
              Comment s’est passée votre course avec {driverUser?.fullname ?? 'votre chauffeur'} ?
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center gap-2 py-2">
            {[1, 2, 3, 4, 5].map((s) => (
              <button key={s} onClick={() => setRating(s)} aria-label={`${s} étoiles`}>
                <Star
                  className={cn(
                    'h-9 w-9 transition-colors',
                    s <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200',
                  )}
                />
              </button>
            ))}
          </div>
          <Button
            onClick={() => {
              rateRide(ride.id, rating)
              setRated(true)
              setRatingOpen(false)
              toast.success('Merci pour votre évaluation !')
            }}
            className="h-11 w-full rounded-xl bg-violet-600 font-semibold text-white hover:bg-violet-700"
          >
            Envoyer
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  )
}
