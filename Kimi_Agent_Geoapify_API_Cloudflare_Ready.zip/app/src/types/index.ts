// Types principaux de TaxiPa'w (conformes au cahier des charges)

export type Role = 'client' | 'driver' | 'admin'
export type VehicleType = 'taxi' | 'moto'

export type RideStatus =
  | 'pending' // En attente
  | 'driver_found' // Chauffeur trouvé
  | 'driver_en_route' // Chauffeur en route
  | 'driver_arrived' // Chauffeur arrivé
  | 'started' // Course commencée
  | 'completed' // Course terminée
  | 'cancelled' // Annulée

export type PaymentMethod = 'cash' | 'moncash' | 'natcash' | 'card'

export interface User {
  id: string
  fullname: string
  phone: string
  email: string
  role: Role
  avatar?: string
  status: 'active' | 'suspended' | 'pending'
  createdAt: number
}

export interface Driver {
  userId: string
  vehicleType: VehicleType
  brand: string
  model: string
  plate: string
  color: string
  cin?: string
  license?: string
  documents?: string[]
  approved: boolean
  online: boolean
  latitude: number
  longitude: number
  rating: number
  totalRides: number
  earnings: number
}

export interface GeoPoint {
  address: string
  lat: number
  lng: number
}

export interface Ride {
  id: string
  clientId: string
  clientName?: string
  driverId?: string
  vehicleType: VehicleType
  pickup: GeoPoint
  dropoff: GeoPoint
  distanceKm: number
  durationMin: number
  price: number
  status: RideStatus
  payment: PaymentMethod
  rating?: number
  // Suivi temps réel (position du chauffeur pendant la course)
  driverLat?: number
  driverLng?: number
  etaMin?: number
  createdAt: number
  updatedAt: number
}

export interface AppNotification {
  id: string
  userId: string
  title: string
  message: string
  read: boolean
  createdAt: number
}

export interface Promotion {
  id: string
  code: string
  description: string
  discountPct: number
  active: boolean
  uses: number
  createdAt: number
}

export interface PlaceResult {
  address: string
  lat: number
  lng: number
}

export interface RouteResult {
  distanceKm: number
  durationMin: number
  geometry: [number, number][] // [lat, lng][]
}

export const RIDE_STATUS_LABELS: Record<RideStatus, string> = {
  pending: 'En attente',
  driver_found: 'Chauffeur trouvé',
  driver_en_route: 'Chauffeur en route',
  driver_arrived: 'Chauffeur arrivé',
  started: 'Course commencée',
  completed: 'Course terminée',
  cancelled: 'Annulée',
}
