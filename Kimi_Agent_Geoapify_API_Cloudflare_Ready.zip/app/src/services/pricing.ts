// Tarification TaxiPa'w en gourdes (HTG)
import type { VehicleType } from '@/types'

export interface Tariff {
  base: number // prise en charge
  perKm: number
  perMin: number
  minimum: number
}

export const TARIFFS: Record<VehicleType, Tariff> = {
  taxi: { base: 150, perKm: 75, perMin: 3, minimum: 200 },
  moto: { base: 100, perKm: 45, perMin: 2, minimum: 120 },
}

export const COMMISSION_RATE = 0.15 // 15 % de commission plateforme

export function estimatePrice(
  vehicleType: VehicleType,
  distanceKm: number,
  durationMin: number,
): number {
  const t = TARIFFS[vehicleType]
  const raw = t.base + distanceKm * t.perKm + durationMin * t.perMin
  const rounded = Math.round(raw / 5) * 5 // arrondi à 5 Gdes
  return Math.max(t.minimum, rounded)
}

export function formatGdes(amount: number): string {
  return `${amount.toLocaleString('fr-HT')} Gdes`
}

export function formatKm(km: number): string {
  return `${km.toFixed(1)} km`
}

export function formatMin(min: number): string {
  return `${Math.max(1, Math.round(min))} min`
}
