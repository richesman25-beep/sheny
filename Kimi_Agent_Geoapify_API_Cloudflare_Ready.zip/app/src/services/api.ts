// Façade de services : utilise Firebase lorsque la configuration est
// renseignée, sinon le mode démo local (mêmes signatures).
import {
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
} from 'firebase/auth'
import { doc, getDoc, setDoc } from 'firebase/firestore'
import { auth, db, isFirebaseConfigured } from '@/firebase/firebase'
import type { User } from '@/types'
import * as demo from './demo'
import type { RegisterInput } from './demo'

export { isFirebaseConfigured }

async function firebaseProfile(uid: string): Promise<User | null> {
  if (!db) return null
  const snap = await getDoc(doc(db, 'users', uid))
  return snap.exists() ? ({ id: uid, ...snap.data() } as User) : null
}

export async function apiLogin(email: string, password: string): Promise<User> {
  if (isFirebaseConfigured && auth) {
    const cred = await signInWithEmailAndPassword(auth, email, password)
    const profile = await firebaseProfile(cred.user.uid)
    if (!profile) throw new Error('Profil utilisateur introuvable.')
    return profile
  }
  return demo.login(email, password)
}

export async function apiRegister(input: RegisterInput): Promise<User> {
  if (isFirebaseConfigured && auth && db) {
    const cred = await createUserWithEmailAndPassword(auth, input.email, input.password)
    const profile: User = {
      id: cred.user.uid,
      fullname: input.fullname,
      phone: input.phone,
      email: input.email,
      role: input.role,
      status: input.role === 'driver' ? 'pending' : 'active',
      createdAt: Date.now(),
    }
    await setDoc(doc(db, 'users', cred.user.uid), profile)
    if (input.role === 'driver' && input.driver) {
      await setDoc(doc(db, 'drivers', cred.user.uid), {
        userId: cred.user.uid,
        ...input.driver,
        approved: false,
        online: false,
        rating: 5,
        totalRides: 0,
        earnings: 0,
      })
    }
    return profile
  }
  return demo.register(input)
}

export async function apiLogout(): Promise<void> {
  if (isFirebaseConfigured && auth) {
    await signOut(auth)
    return
  }
  demo.logout()
}

export async function apiResetPassword(email: string): Promise<void> {
  if (isFirebaseConfigured && auth) {
    await sendPasswordResetEmail(auth, email)
    return
  }
  // Démo : toujours résolu (message affiché côté UI)
  demo.resetPassword(email)
}
