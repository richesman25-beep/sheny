// Mode démo TaxiPa'w : base de données locale + moteur temps réel simulé.
// Utilisé automatiquement tant que Firebase n'est pas configuré.
// Les mêmes fonctions existent côté Firebase (voir api.ts).
import type {
  AppNotification,
  Driver,
  GeoPoint,
  Promotion,
  Ride,
  RideStatus,
  User,
  VehicleType,
} from '@/types'
import { haversineKm, matchToRoads, planRoute } from '@/lib/geoapify'
import { COMMISSION_RATE } from './pricing'

// ---------------------------------------------------------------------------
// Persistance locale
// ---------------------------------------------------------------------------

interface StoredUser extends User {
  password: string
}

interface Db {
  users: StoredUser[]
  drivers: Driver[]
  rides: Ride[]
  notifications: AppNotification[]
  promotions: Promotion[]
  sessionUserId: string | null
}

const DB_KEY = 'taxipaw_db_v2'

export const id = () =>
  `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`.toUpperCase()

const now = () => Date.now()
const day = 24 * 60 * 60 * 1000

// Adresses réalistes de Port-au-Prince et environs
const PLACES: GeoPoint[] = [
  { address: 'Rue Oswald Durand, Delmas', lat: 18.5529, lng: -72.2915 },
  { address: 'Rue Capois, Pétion-Ville', lat: 18.5125, lng: -72.2853 },
  { address: 'Avenue John Brown, Port-au-Prince', lat: 18.5562, lng: -72.3274 },
  { address: 'Place Saint-Pierre, Pétion-Ville', lat: 18.513, lng: -72.286 },
  { address: 'Boulevard Toussaint Louverture, Port-au-Prince', lat: 18.5755, lng: -72.2977 },
  { address: 'Carrefour, Port-au-Prince', lat: 18.5407, lng: -72.3989 },
  { address: 'Canapé-Vert, Port-au-Prince', lat: 18.5431, lng: -72.3025 },
  { address: 'Turgeau, Port-au-Prince', lat: 18.5372, lng: -72.3185 },
  { address: 'Delmas 33, Delmas', lat: 18.5608, lng: -72.2786 },
  { address: 'Tabarre, Port-au-Prince', lat: 18.5833, lng: -72.2667 },
  { address: 'Musseau, Port-au-Prince', lat: 18.5618, lng: -72.3096 },
  { address: 'Route de Frères, Pétion-Ville', lat: 18.5215, lng: -72.2812 },
]

function rand(min: number, max: number) {
  return min + Math.random() * (max - min)
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function jitter(base: number, amount = 0.03) {
  return base + rand(-amount, amount)
}

// ---------------------------------------------------------------------------
// Données de départ
// ---------------------------------------------------------------------------

function seed(): Db {
  const t = now()
  const users: StoredUser[] = [
    {
      id: 'ADMIN01',
      fullname: 'Administrateur TaxiPa’w',
      phone: '+509 3400 0000',
      email: 'admin@taxipaw.ht',
      password: 'admin123',
      role: 'admin',
      status: 'active',
      createdAt: t - 90 * day,
    },
    {
      id: 'CLIENT01',
      fullname: 'Marie Jean',
      phone: '+509 3712 4567',
      email: 'client@taxipaw.ht',
      password: 'demo1234',
      role: 'client',
      status: 'active',
      createdAt: t - 30 * day,
    },
    {
      id: 'DRIVER01',
      fullname: 'James Pierre',
      phone: '+509 3821 7890',
      email: 'chauffeur@taxipaw.ht',
      password: 'demo1234',
      role: 'driver',
      status: 'active',
      createdAt: t - 60 * day,
    },
    // Chauffeurs en attente de validation (visibles dans l'admin)
    {
      id: 'DRV-PEND1',
      fullname: 'Jean Baptiste',
      phone: '+509 3654 1122',
      email: 'jean.baptiste@mail.ht',
      password: 'demo1234',
      role: 'driver',
      status: 'pending',
      createdAt: t - 2 * day,
    },
    {
      id: 'DRV-PEND2',
      fullname: 'Michel Joseph',
      phone: '+509 3498 7766',
      email: 'michel.joseph@mail.ht',
      password: 'demo1234',
      role: 'driver',
      status: 'pending',
      createdAt: t - 1 * day,
    },
    {
      id: 'DRV-PEND3',
      fullname: 'Wendy Laurent',
      phone: '+509 3777 8899',
      email: 'wendy.laurent@mail.ht',
      password: 'demo1234',
      role: 'driver',
      status: 'pending',
      createdAt: t - 12 * 60 * 60 * 1000,
    },
    // Autres chauffeurs actifs
    ...(['Wisly Charles', 'Fedner Alcide', 'Rosemond Sajous', 'Kettia Moïse', 'Dieujuste Paul'].map(
      (fullname, i) => ({
        id: `DRV-ACT${i + 1}`,
        fullname,
        phone: `+509 35${10 + i} ${2000 + i * 111}`,
        email: `chauffeur${i + 2}@mail.ht`,
        password: 'demo1234',
        role: 'driver' as const,
        status: 'active' as const,
        createdAt: t - (20 + i * 5) * day,
      }),
    )),
    // Clients supplémentaires
    ...(['Marc Antoine', 'Nadia Fils-Aimé', 'Jean-Ronald Étienne', 'Sabine Durocher'].map(
      (fullname, i) => ({
        id: `CLI-${i + 2}`,
        fullname,
        phone: `+509 36${20 + i} ${3100 + i * 137}`,
        email: `client${i + 2}@mail.ht`,
        password: 'demo1234',
        role: 'client' as const,
        status: 'active' as const,
        createdAt: t - (10 + i * 7) * day,
      }),
    )),
  ]

  const driverSpecs: Array<[string, VehicleType, string, string, string, string, boolean]> = [
    ['DRIVER01', 'taxi', 'Toyota', 'Corolla', 'AA-12345', 'Noir', true],
    ['DRV-PEND1', 'taxi', 'Toyota', 'Corolla', 'AA-12345', 'Blanc', false],
    ['DRV-PEND2', 'moto', 'Yamaha', 'YBR 125', 'MB-56789', 'Rouge', false],
    ['DRV-PEND3', 'taxi', 'Hyundai', 'Accent', 'BB-98765', 'Gris', false],
    ['DRV-ACT1', 'taxi', 'Honda', 'Civic', 'AC-45678', 'Bleu', true],
    ['DRV-ACT2', 'moto', 'Haojue', 'HJ150', 'MC-11223', 'Noir', true],
    ['DRV-ACT3', 'moto', 'Suzuki', 'GN125', 'MD-33445', 'Rouge', true],
    ['DRV-ACT4', 'taxi', 'Nissan', 'Sentra', 'AE-77889', 'Blanc', true],
    ['DRV-ACT5', 'moto', 'Yamaha', 'FZ150', 'MF-99001', 'Bleu', true],
  ]

  const drivers: Driver[] = driverSpecs.map(
    ([userId, vehicleType, brand, model, plate, color, approved], i) => ({
      userId,
      vehicleType,
      brand,
      model,
      plate,
      color,
      cin: `${1000 + i}-2000-3000-0${i}`,
      license: vehicleType === 'taxi' ? `PERMIS-${7000 + i}` : undefined,
      approved,
      online: approved && i % 3 !== 2,
      latitude: jitter(18.5944, 0.055),
      longitude: jitter(-72.3074, 0.055),
      rating: Math.round(rand(4.2, 5) * 10) / 10,
      totalRides: Math.round(rand(80, 900)),
      earnings: Math.round(rand(4000, 90000)),
    }),
  )

  // Historique des 7 derniers jours pour les statistiques admin
  const dailyCounts = [42, 65, 58, 80, 95, 88, 128]
  const clientIds = users.filter((u) => u.role === 'client').map((u) => u.id)
  const approvedDrivers = drivers.filter((d) => d.approved)
  const rides: Ride[] = []
  const todayStart = new Date(t).setHours(0, 0, 0, 0)
  dailyCounts.forEach((count, dayIndex) => {
    const sod = todayStart - (6 - dayIndex) * day // minuit du jour concerné
    for (let i = 0; i < count; i++) {
      const pickup = pick(PLACES)
      let dropoff = pick(PLACES)
      while (dropoff.address === pickup.address) dropoff = pick(PLACES)
      const vehicleType: VehicleType = Math.random() > 0.35 ? 'taxi' : 'moto'
      const distanceKm = rand(1.5, 14)
      const durationMin = distanceKm * rand(2.6, 4)
      const price =
        Math.round(
          (vehicleType === 'taxi' ? 150 + distanceKm * 75 : 100 + distanceKm * 45) / 5,
        ) * 5
      const status: RideStatus =
        Math.random() > 0.08 ? 'completed' : Math.random() > 0.5 ? 'cancelled' : 'completed'
      const driver = pick(approvedDrivers)
      // Répartition dans la journée (entre 5h et 23h59), sans dépasser « maintenant »
      const createdAt = Math.min(sod + rand(5 * 3600 * 1000, 24 * 3600 * 1000 - 1), t)
      rides.push({
        id: `C${1256 - rides.length}`,
        clientId: pick(clientIds),
        driverId: driver.userId,
        vehicleType,
        pickup,
        dropoff,
        distanceKm: Math.round(distanceKm * 10) / 10,
        durationMin: Math.round(durationMin),
        price,
        status,
        payment: 'cash',
        createdAt,
        updatedAt: createdAt,
      })
    }
  })

  const notifications: AppNotification[] = [
    {
      id: id(),
      userId: 'CLIENT01',
      title: 'Bienvenue sur TaxiPa’w',
      message: 'Commandez votre premier taxi ou moto en quelques secondes.',
      read: false,
      createdAt: t - 2 * 60 * 60 * 1000,
    },
    {
      id: id(),
      userId: 'DRIVER01',
      title: 'Compte approuvé',
      message: 'Félicitations ! Votre compte chauffeur a été validé.',
      read: false,
      createdAt: t - 5 * 60 * 60 * 1000,
    },
  ]

  const promotions: Promotion[] = [
    {
      id: id(),
      code: 'BYENVENI10',
      description: '10 % de réduction sur la première course',
      discountPct: 10,
      active: true,
      uses: 34,
      createdAt: t - 15 * day,
    },
    {
      id: id(),
      code: 'FETE20',
      description: 'Promotion fête patronale — 20 %',
      discountPct: 20,
      active: false,
      uses: 112,
      createdAt: t - 45 * day,
    },
  ]

  return { users, drivers, rides, notifications, promotions, sessionUserId: null }
}

// ---------------------------------------------------------------------------
// Store + émetteur d'événements (temps réel simulé)
// ---------------------------------------------------------------------------

type Listener = () => void
const listeners = new Set<Listener>()

let db: Db = load()

function load(): Db {
  try {
    const raw = localStorage.getItem(DB_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as Db
      if (parsed.users && parsed.drivers) return parsed
    }
  } catch {
    // ignore
  }
  const fresh = seed()
  localStorage.setItem(DB_KEY, JSON.stringify(fresh))
  return fresh
}

function save() {
  localStorage.setItem(DB_KEY, JSON.stringify(db))
}

function emit() {
  save()
  listeners.forEach((l) => l())
}

export function subscribe(listener: Listener): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

export function getDb(): Db {
  return db
}

export function resetDemo() {
  localStorage.removeItem(DB_KEY)
  db = seed()
  emit()
}

// ---------------------------------------------------------------------------
// Authentification (démo)
// ---------------------------------------------------------------------------

export class AuthError extends Error {}

export function currentUser(): StoredUser | null {
  if (!db.sessionUserId) return null
  return db.users.find((u) => u.id === db.sessionUserId) ?? null
}

export function login(email: string, password: string): User {
  const user = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase())
  if (!user) throw new AuthError('Aucun compte trouvé avec cet email.')
  if (user.password !== password) throw new AuthError('Mot de passe incorrect.')
  db.sessionUserId = user.id
  emit()
  return user
}

export interface RegisterInput {
  fullname: string
  phone: string
  email: string
  password: string
  role: 'client' | 'driver'
  driver?: {
    vehicleType: VehicleType
    brand: string
    model: string
    color: string
    plate: string
    cin: string
    license?: string
  }
}

export function register(input: RegisterInput): User {
  const email = input.email.trim().toLowerCase()
  if (db.users.some((u) => u.email.toLowerCase() === email)) {
    throw new AuthError('Un compte existe déjà avec cet email.')
  }
  const user: StoredUser = {
    id: id(),
    fullname: input.fullname.trim(),
    phone: input.phone.trim(),
    email,
    password: input.password,
    role: input.role,
    status: input.role === 'driver' ? 'pending' : 'active',
    createdAt: now(),
  }
  db.users.push(user)
  if (input.role === 'driver' && input.driver) {
    db.drivers.push({
      userId: user.id,
      vehicleType: input.driver.vehicleType,
      brand: input.driver.brand,
      model: input.driver.model,
      color: input.driver.color,
      plate: input.driver.plate,
      cin: input.driver.cin,
      license: input.driver.license,
      approved: false,
      online: false,
      latitude: jitter(18.5944),
      longitude: jitter(-72.3074),
      rating: 5,
      totalRides: 0,
      earnings: 0,
    })
    notify(user.id, 'Dossier reçu', 'Votre demande chauffeur est en attente de validation.')
  } else {
    notify(user.id, 'Bienvenue sur TaxiPa’w', 'Votre compte a été créé avec succès.')
  }
  db.sessionUserId = user.id
  emit()
  return user
}

export function logout() {
  db.sessionUserId = null
  emit()
}

export function resetPassword(email: string): boolean {
  return db.users.some((u) => u.email.toLowerCase() === email.trim().toLowerCase())
}

export function updateUser(userId: string, patch: Partial<User>) {
  const u = db.users.find((x) => x.id === userId)
  if (!u) return
  Object.assign(u, patch)
  emit()
}

export function changePassword(userId: string, current: string, next: string): boolean {
  const u = db.users.find((x) => x.id === userId)
  if (!u || u.password !== current) return false
  u.password = next
  emit()
  return true
}

// ---------------------------------------------------------------------------
// Chauffeurs
// ---------------------------------------------------------------------------

export function getDriver(userId: string): Driver | undefined {
  return db.drivers.find((d) => d.userId === userId)
}

export function updateDriver(userId: string, patch: Partial<Driver>) {
  const d = getDriver(userId)
  if (!d) return
  Object.assign(d, patch)
  emit()
}

export function nearbyDrivers(center: { lat: number; lng: number }, vehicleType?: VehicleType) {
  return db.drivers
    .filter((d) => d.approved && d.online)
    .filter((d) => !vehicleType || d.vehicleType === vehicleType)
    .map((d) => ({
      ...d,
      distanceKm: haversineKm(center, { lat: d.latitude, lng: d.longitude }),
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm)
}

export function setDriverOnline(userId: string, online: boolean) {
  const d = getDriver(userId)
  if (!d) return
  d.online = online
  emit()
  if (online) scheduleDriverRequest(userId, 5000 + Math.random() * 6000)
}

export function approveDriver(userId: string, approved: boolean) {
  const d = getDriver(userId)
  if (!d) return
  d.approved = approved
  const u = db.users.find((x) => x.id === userId)
  if (u) u.status = approved ? 'active' : 'suspended'
  notify(
    userId,
    approved ? 'Compte approuvé' : 'Compte refusé',
    approved
      ? 'Votre compte chauffeur a été validé. Vous pouvez vous mettre en ligne.'
      : 'Votre dossier chauffeur a été refusé. Contactez le support.',
  )
  emit()
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

export function notify(userId: string, title: string, message: string) {
  db.notifications.unshift({ id: id(), userId, title, message, read: false, createdAt: now() })
  save()
}

export function markNotificationRead(notifId: string) {
  const n = db.notifications.find((x) => x.id === notifId)
  if (n) {
    n.read = true
    emit()
  }
}

export function markAllNotificationsRead(userId: string) {
  db.notifications.forEach((n) => {
    if (n.userId === userId) n.read = true
  })
  emit()
}

// ---------------------------------------------------------------------------
// Courses — cycle de vie simulé
// ---------------------------------------------------------------------------

const timers = new Map<string, ReturnType<typeof setTimeout>[]>()
const intervals = new Map<string, ReturnType<typeof setInterval>>()

function later(rideId: string, ms: number, fn: () => void) {
  const list = timers.get(rideId) ?? []
  list.push(setTimeout(fn, ms))
  timers.set(rideId, list)
}

function clearSimulation(rideId: string) {
  ;(timers.get(rideId) ?? []).forEach(clearTimeout)
  timers.delete(rideId)
  const iv = intervals.get(rideId)
  if (iv) clearInterval(iv)
  intervals.delete(rideId)
}

export function getRide(rideId: string): Ride | undefined {
  return db.rides.find((r) => r.id === rideId)
}

export function ridesForUser(userId: string): Ride[] {
  return db.rides
    .filter((r) => r.clientId === userId || r.driverId === userId)
    .sort((a, b) => b.createdAt - a.createdAt)
}

export function activeRideFor(userId: string): Ride | undefined {
  return db.rides.find(
    (r) =>
      (r.clientId === userId || r.driverId === userId) &&
      !['completed', 'cancelled'].includes(r.status),
  )
}

// Anime la position d'un chauffeur le long d'un chemin (points [lat,lng])
function animateAlong(rideId: string, driverId: string, path: [number, number][], totalMs: number) {
  if (path.length < 2) return
  const started = now()
  const totalSegments = path.length - 1
  const nominalMin = totalMs / 60000
  const iv = setInterval(() => {
    const elapsed = now() - started
    const frac = Math.min(1, elapsed / totalMs)
    const segFloat = frac * totalSegments
    const segIdx = Math.min(totalSegments - 1, Math.floor(segFloat))
    const segFrac = segFloat - segIdx
    const a = path[segIdx]
    const b = path[segIdx + 1]
    const lat = a[0] + (b[0] - a[0]) * segFrac
    const lng = a[1] + (b[1] - a[1]) * segFrac
    const d = getDriver(driverId)
    if (d) {
      d.latitude = lat
      d.longitude = lng
    }
    const ride = getRide(rideId)
    if (ride) {
      ride.driverLat = lat
      ride.driverLng = lng
      ride.etaMin = Math.max(1, Math.ceil((1 - frac) * nominalMin))
      ride.updatedAt = now()
    }
    if (frac >= 1 && intervals.get(rideId)) {
      clearInterval(intervals.get(rideId)!)
      intervals.delete(rideId)
    }
    emit()
  }, 700)
  intervals.set(rideId, iv)
}

async function routePath(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
): Promise<[number, number][]> {
  try {
    const route = await planRoute(from, to)
    if (route && route.geometry.length >= 2) {
      // Recale le tracé sur la route via map matching (meilleure qualité visuelle)
      const matched = await matchToRoads(route.geometry.filter((_, i) => i % 4 === 0))
      return matched.length >= 2 ? matched : route.geometry
    }
  } catch {
    // ignore
  }
  // Repli : interpolation en ligne droite
  const steps = 24
  const out: [number, number][] = []
  for (let i = 0; i <= steps; i++) {
    out.push([from.lat + ((to.lat - from.lat) * i) / steps, from.lng + ((to.lng - from.lng) * i) / steps])
  }
  return out
}

function setRideStatus(rideId: string, status: RideStatus) {
  const ride = getRide(rideId)
  if (!ride) return
  ride.status = status
  ride.updatedAt = now()
  emit()
}

export interface RequestRideInput {
  clientId: string
  vehicleType: VehicleType
  pickup: GeoPoint
  dropoff: GeoPoint
  distanceKm: number
  durationMin: number
  price: number
}

// Le client commande une course → attribution du chauffeur le plus proche,
// puis progression simulée (chauffeur en route → arrivé → course → terminée).
export function requestRide(input: RequestRideInput): Ride {
  const client = db.users.find((u) => u.id === input.clientId)
  const candidates = nearbyDrivers(input.pickup, input.vehicleType)
  const fallback = nearbyDrivers(input.pickup)
  const driver = candidates[0] ?? fallback[0]

  const ride: Ride = {
    id: `C${Math.floor(1000 + Math.random() * 9000)}`,
    clientId: input.clientId,
    clientName: client?.fullname,
    driverId: driver?.userId,
    vehicleType: input.vehicleType,
    pickup: input.pickup,
    dropoff: input.dropoff,
    distanceKm: input.distanceKm,
    durationMin: input.durationMin,
    price: input.price,
    status: 'pending',
    payment: 'cash',
    createdAt: now(),
    updatedAt: now(),
  }
  db.rides.unshift(ride)
  notify(input.clientId, 'Course demandée', 'Recherche d’un chauffeur à proximité…')
  if (driver) {
    notify(
      driver.userId,
      'Nouvelle demande',
      `${input.pickup.address} → ${input.dropoff.address}`,
    )
  }
  emit()

  if (!driver) {
    later(ride.id, 3000, () => {
      setRideStatus(ride.id, 'cancelled')
      notify(input.clientId, 'Aucun chauffeur', 'Aucun chauffeur disponible pour le moment.')
    })
    return ride
  }

  // 1. Chauffeur trouvé
  later(ride.id, 2200, () => {
    setRideStatus(ride.id, 'driver_found')
    notify(input.clientId, 'Chauffeur trouvé', 'Votre chauffeur a accepté la course.')
  })

  // 2. Chauffeur en route vers le point de départ
  later(ride.id, 3200, async () => {
    setRideStatus(ride.id, 'driver_en_route')
    const d = getDriver(driver.userId)
    if (!d) return
    const path = await routePath(
      { lat: d.latitude, lng: d.longitude },
      { lat: ride.pickup.lat, lng: ride.pickup.lng },
    )
    animateAlong(ride.id, driver.userId, path, 18000)

    // 3. Arrivée du chauffeur
    later(ride.id, 19000, () => {
      setRideStatus(ride.id, 'driver_arrived')
      notify(input.clientId, 'Chauffeur arrivé', 'Votre chauffeur vous attend.')

      // 4. Début de la course
      later(ride.id, 5000, async () => {
        setRideStatus(ride.id, 'started')
        const tripPath = await routePath(
          { lat: ride.pickup.lat, lng: ride.pickup.lng },
          { lat: ride.dropoff.lat, lng: ride.dropoff.lng },
        )
        animateAlong(ride.id, driver.userId, tripPath, 22000)

        // 5. Fin de la course
        later(ride.id, 23000, () => completeRide(ride.id))
      })
    })
  })

  return ride
}

export function completeRide(rideId: string) {
  const ride = getRide(rideId)
  if (!ride || ride.status === 'completed') return
  clearSimulation(rideId)
  ride.status = 'completed'
  ride.updatedAt = now()
  const d = ride.driverId ? getDriver(ride.driverId) : undefined
  if (d) {
    d.totalRides += 1
    d.earnings += Math.round(ride.price * (1 - COMMISSION_RATE))
  }
  notify(ride.clientId, 'Course terminée', `Merci d’avoir utilisé TaxiPa’w ! Montant : ${ride.price} Gdes.`)
  if (ride.driverId) notify(ride.driverId, 'Course terminée', `Vous avez gagné ${Math.round(ride.price * (1 - COMMISSION_RATE))} Gdes.`)
  emit()
}

export function cancelRide(rideId: string) {
  const ride = getRide(rideId)
  if (!ride) return
  clearSimulation(rideId)
  ride.status = 'cancelled'
  ride.updatedAt = now()
  notify(ride.clientId, 'Course annulée', 'Votre course a été annulée.')
  if (ride.driverId) notify(ride.driverId, 'Course annulée', 'Le client a annulé la course.')
  emit()
}

export function rateRide(rideId: string, rating: number) {
  const ride = getRide(rideId)
  if (!ride) return
  ride.rating = rating
  const d = ride.driverId ? getDriver(ride.driverId) : undefined
  if (d) {
    d.rating = Math.round(((d.rating * d.totalRides + rating) / (d.totalRides + 1)) * 10) / 10
  }
  emit()
}

// ---------------------------------------------------------------------------
// Demandes simulées côté chauffeur
// ---------------------------------------------------------------------------

const driverRequestTimers = new Map<string, ReturnType<typeof setTimeout>>()

function scheduleDriverRequest(driverId: string, delayMs: number) {
  const existing = driverRequestTimers.get(driverId)
  if (existing) clearTimeout(existing)
  const timer = setTimeout(() => createDriverRequest(driverId), delayMs)
  driverRequestTimers.set(driverId, timer)
}

function createDriverRequest(driverId: string) {
  const d = getDriver(driverId)
  if (!d || !d.online) return
  if (activeRideFor(driverId)) return // déjà occupé
  if (db.rides.some((r) => r.status === 'pending' && r.driverId === driverId)) return

  // Point de départ parmi les plus proches du chauffeur (demande réaliste)
  const near = [...PLACES]
    .sort(
      (a, b) =>
        haversineKm({ lat: d.latitude, lng: d.longitude }, a) -
        haversineKm({ lat: d.latitude, lng: d.longitude }, b),
    )
    .slice(0, 4)
  const pickup = pick(near)
  let dropoff = pick(PLACES)
  while (dropoff.address === pickup.address) dropoff = pick(PLACES)
  const client = pick(db.users.filter((u) => u.role === 'client'))
  const dist = haversineKm({ lat: d.latitude, lng: d.longitude }, pickup)
  const distanceKm = Math.max(1, Math.round(dist * 10) / 10 + rand(1, 3))
  const price =
    Math.round((d.vehicleType === 'taxi' ? 150 + distanceKm * 75 : 100 + distanceKm * 45) / 5) * 5

  const ride: Ride = {
    id: `C${Math.floor(1000 + Math.random() * 9000)}`,
    clientId: client.id,
    clientName: client.fullname,
    driverId,
    vehicleType: d.vehicleType,
    pickup,
    dropoff,
    distanceKm: Math.round(distanceKm * 10) / 10,
    durationMin: Math.round(distanceKm * rand(2.8, 3.6)),
    price,
    status: 'pending',
    payment: 'cash',
    createdAt: now(),
    updatedAt: now(),
  }
  db.rides.unshift(ride)
  notify(driverId, 'Nouvelle demande', `${pickup.address} → ${dropoff.address}`)
  emit()

  // Expiration automatique de la demande après 20 s
  later(ride.id, 20000, () => {
    const r = getRide(ride.id)
    if (r && r.status === 'pending') {
      db.rides = db.rides.filter((x) => x.id !== ride.id)
      emit()
      scheduleDriverRequest(driverId, 9000 + Math.random() * 12000)
    }
  })
}

export function driverPendingRide(driverId: string): Ride | undefined {
  return db.rides.find((r) => r.status === 'pending' && r.driverId === driverId)
}

export function driverAcceptRide(rideId: string) {
  const ride = getRide(rideId)
  if (!ride || !ride.driverId) return
  clearSimulation(rideId)
  ride.status = 'driver_en_route'
  ride.updatedAt = now()
  notify(ride.clientId, 'Chauffeur trouvé', 'Votre chauffeur est en route vers vous.')
  emit()
  const d = getDriver(ride.driverId)
  if (!d) return
  void routePath({ lat: d.latitude, lng: d.longitude }, ride.pickup).then((path) =>
    animateAlong(rideId, ride.driverId!, path, 15000),
  )
}

export function driverRefuseRide(rideId: string) {
  const ride = getRide(rideId)
  if (!ride || !ride.driverId) return
  const driverId = ride.driverId
  clearSimulation(rideId)
  db.rides = db.rides.filter((x) => x.id !== rideId)
  emit()
  scheduleDriverRequest(driverId, 6000 + Math.random() * 9000)
}

export function driverMarkArrived(rideId: string) {
  clearSimulation(rideId)
  setRideStatus(rideId, 'driver_arrived')
  const ride = getRide(rideId)
  if (ride) notify(ride.clientId, 'Chauffeur arrivé', 'Votre chauffeur vous attend.')
}

export function driverStartRide(rideId: string) {
  const ride = getRide(rideId)
  if (!ride || !ride.driverId) return
  setRideStatus(rideId, 'started')
  notify(ride.clientId, 'Course commencée', 'Bon voyage avec TaxiPa’w !')
  void routePath(ride.pickup, ride.dropoff).then((path) =>
    animateAlong(rideId, ride.driverId!, path, 20000),
  )
}

// ---------------------------------------------------------------------------
// Promotions & administration
// ---------------------------------------------------------------------------

export function savePromotion(promo: Omit<Promotion, 'id' | 'uses' | 'createdAt'> & { id?: string }) {
  if (promo.id) {
    const p = db.promotions.find((x) => x.id === promo.id)
    if (p) Object.assign(p, promo)
  } else {
    db.promotions.unshift({ ...promo, id: id(), uses: 0, createdAt: now() })
  }
  emit()
}

export function deletePromotion(promoId: string) {
  db.promotions = db.promotions.filter((p) => p.id !== promoId)
  emit()
}

export interface AdminStats {
  ridesToday: number
  driversActive: number
  clientsActive: number
  revenueToday: number
  commissionToday: number
  weeklySeries: { day: string; rides: number }[]
}

export function adminStats(): AdminStats {
  const today = new Date().setHours(0, 0, 0, 0)
  const todayRides = db.rides.filter((r) => r.createdAt >= today)
  const completed = todayRides.filter((r) => r.status === 'completed')
  const revenueToday = completed.reduce((s, r) => s + r.price, 0)
  const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
  const weeklySeries = Array.from({ length: 7 }, (_, i) => {
    const start = today - (6 - i) * day
    const end = start + day
    const count = db.rides.filter((r) => r.createdAt >= start && r.createdAt < end).length
    return { day: dayNames[new Date(start).getDay()], rides: count }
  })
  return {
    ridesToday: todayRides.length,
    driversActive: db.drivers.filter((d) => d.approved && d.online).length,
    clientsActive: db.users.filter((u) => u.role === 'client' && u.status === 'active').length,
    revenueToday,
    commissionToday: Math.round(revenueToday * COMMISSION_RATE),
    weeklySeries,
  }
}
