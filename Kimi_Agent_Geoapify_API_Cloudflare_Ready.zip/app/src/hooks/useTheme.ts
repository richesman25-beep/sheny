import { useEffect, useState } from 'react'

export function useTheme() {
  const [dark, setDark] = useState(
    () => typeof window !== 'undefined' && localStorage.getItem('taxipaw_theme') === 'dark',
  )
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
    localStorage.setItem('taxipaw_theme', dark ? 'dark' : 'light')
  }, [dark])
  return { dark, toggle: () => setDark((d) => !d) }
}
