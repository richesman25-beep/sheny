// Hook réactif sur la base démo (ré-affiche le composant à chaque changement)
import { useEffect, useReducer } from 'react'
import { getDb, subscribe } from '@/services/demo'

export function useStore() {
  const [, force] = useReducer((x: number) => x + 1, 0)
  useEffect(() => subscribe(force), [])
  return getDb()
}
